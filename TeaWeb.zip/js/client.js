/// <reference path="../declarations/imports_shared.d.ts"/>
var ppt;
(function (ppt) {
    let key_listener = [];
    function listener_key(type, event) {
        const key_event = {
            type: type,
            key: event.key,
            key_code: event.code,
            key_ctrl: event.ctrlKey,
            key_shift: event.shiftKey,
            key_alt: event.altKey,
            key_windows: event.metaKey,
            canceled: event.defaultPrevented
        };
        //console.debug("Trigger key event %o", key_event);
        for (const listener of key_listener)
            listener(key_event);
        if (key_event.canceled)
            event.preventDefault();
    }
    const proxy_key_press = event => listener_key(ppt.EventType.KEY_PRESS, event);
    const proxy_key_release = event => listener_key(ppt.EventType.KEY_RELEASE, event);
    const proxy_key_typed = event => listener_key(ppt.EventType.KEY_TYPED, event);
    function initialize() {
        document.addEventListener('keypress', proxy_key_typed);
        document.addEventListener('keydown', proxy_key_press);
        document.addEventListener('keyup', proxy_key_release);
        register_key_listener(listener_hook);
        return Promise.resolve();
    }
    ppt.initialize = initialize;
    function finalize() {
        document.removeEventListener("keypress", proxy_key_typed);
        document.removeEventListener("keydown", proxy_key_press);
        document.removeEventListener("keyup", proxy_key_release);
        unregister_key_listener(listener_hook);
    }
    ppt.finalize = finalize;
    function register_key_listener(listener) {
        key_listener.push(listener);
    }
    ppt.register_key_listener = register_key_listener;
    function unregister_key_listener(listener) {
        key_listener.remove(listener);
    }
    ppt.unregister_key_listener = unregister_key_listener;
    let key_hooks = [];
    let current_state = {
        special: []
    };
    let key_hooks_active = [];
    function listener_hook(event) {
        if (event.type == ppt.EventType.KEY_TYPED)
            return;
        let old_hooks = [...key_hooks_active];
        let new_hooks = [];
        current_state.special[ppt.SpecialKey.ALT] = event.key_alt;
        current_state.special[ppt.SpecialKey.CTRL] = event.key_ctrl;
        current_state.special[ppt.SpecialKey.SHIFT] = event.key_shift;
        current_state.special[ppt.SpecialKey.WINDOWS] = event.key_windows;
        current_state.code = undefined;
        current_state.event = undefined;
        if (event.type == ppt.EventType.KEY_PRESS) {
            current_state.event = event;
            current_state.code = event.key_code;
            for (const hook of key_hooks) {
                if (hook.key_code != event.key_code)
                    continue;
                if (hook.key_alt != event.key_alt)
                    continue;
                if (hook.key_ctrl != event.key_ctrl)
                    continue;
                if (hook.key_shift != event.key_shift)
                    continue;
                if (hook.key_windows != event.key_windows)
                    continue;
                new_hooks.push(hook);
                if (!old_hooks.remove(hook) && hook.callback_press) {
                    hook.callback_press();
                    console.debug("Trigger key press for %o!", hook);
                }
            }
        }
        //We have a new situation
        for (const hook of old_hooks)
            if (hook.callback_release) {
                hook.callback_release();
                console.debug("Trigger key release for %o!", hook);
            }
        key_hooks_active = new_hooks;
    }
    function register_key_hook(hook) {
        key_hooks.push(hook);
    }
    ppt.register_key_hook = register_key_hook;
    function unregister_key_hook(hook) {
        key_hooks.remove(hook);
    }
    ppt.unregister_key_hook = unregister_key_hook;
    function key_pressed(code) {
        if (typeof (code) === 'string')
            return current_state.code == code;
        return current_state.special[code];
    }
    ppt.key_pressed = key_pressed;
})(ppt || (ppt = {}));
var audio;
(function (audio) {
    var player;
    (function (player) {
        let _globalContext;
        let _globalContextPromise;
        let _initialized_listener = [];
        function initialize() {
            context();
            return true;
        }
        player.initialize = initialize;
        function initialized() {
            return !!_globalContext && _globalContext.state === 'running';
        }
        player.initialized = initialized;
        function fire_initialized() {
            console.log("Fire initialized: %o", _initialized_listener);
            while (_initialized_listener.length > 0)
                _initialized_listener.pop_front()();
        }
        function context() {
            if (_globalContext && _globalContext.state != "suspended")
                return _globalContext;
            if (!_globalContext)
                _globalContext = new (window.webkitAudioContext || window.AudioContext)();
            if (_globalContext.state == "suspended") {
                if (!_globalContextPromise) {
                    (_globalContextPromise = _globalContext.resume()).then(() => {
                        fire_initialized();
                    }).catch(error => {
                        displayCriticalError("Failed to initialize global audio context! (" + error + ")");
                    });
                }
                _globalContext.resume(); //We already have our listener
                return undefined;
            }
            if (_globalContext.state == "running") {
                fire_initialized();
                return _globalContext;
            }
            return undefined;
        }
        player.context = context;
        function destination() {
            return context().destination;
        }
        player.destination = destination;
        function on_ready(cb) {
            if (initialized())
                cb();
            else
                _initialized_listener.push(cb);
        }
        player.on_ready = on_ready;
        player.WEB_DEVICE = { device_id: "", name: "default playback" };
        function available_devices() {
            return Promise.resolve([player.WEB_DEVICE]);
        }
        player.available_devices = available_devices;
        function set_device(device_id) {
            return Promise.resolve();
        }
        player.set_device = set_device;
        function current_device() {
            return player.WEB_DEVICE;
        }
        player.current_device = current_device;
        function initializeFromGesture() {
            context();
        }
        player.initializeFromGesture = initializeFromGesture;
    })(player = audio.player || (audio.player = {}));
})(audio || (audio = {}));
/// <reference path="../../declarations/imports_shared.d.ts"/>
var audio;
(function (audio) {
    var codec;
    (function (codec) {
        function new_instance(type) {
            return new CodecWrapperWorker(type);
        }
        codec.new_instance = new_instance;
        function supported(type) {
            return type == CodecType.OPUS_MUSIC || type == CodecType.OPUS_VOICE;
        }
        codec.supported = supported;
    })(codec = audio.codec || (audio.codec = {}));
})(audio || (audio = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["45ad9eef549096a422d80b29e95a7ebc859f5d44cdbf3487c6706d17d29f6778"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["45ad9eef549096a422d80b29e95a7ebc859f5d44cdbf3487c6706d17d29f6778"] = "45ad9eef549096a422d80b29e95a7ebc859f5d44cdbf3487c6706d17d29f6778";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var LogCategory;
(function (LogCategory) {
    LogCategory[LogCategory["CHANNEL"] = 0] = "CHANNEL";
    LogCategory[LogCategory["CLIENT"] = 1] = "CLIENT";
    LogCategory[LogCategory["SERVER"] = 2] = "SERVER";
    LogCategory[LogCategory["PERMISSIONS"] = 3] = "PERMISSIONS";
    LogCategory[LogCategory["GENERAL"] = 4] = "GENERAL";
    LogCategory[LogCategory["NETWORKING"] = 5] = "NETWORKING";
    LogCategory[LogCategory["VOICE"] = 6] = "VOICE";
    LogCategory[LogCategory["I18N"] = 7] = "I18N";
})(LogCategory || (LogCategory = {}));
var log;
(function (log_1) {
    let LogType;
    (function (LogType) {
        LogType[LogType["TRACE"] = 0] = "TRACE";
        LogType[LogType["DEBUG"] = 1] = "DEBUG";
        LogType[LogType["INFO"] = 2] = "INFO";
        LogType[LogType["WARNING"] = 3] = "WARNING";
        LogType[LogType["ERROR"] = 4] = "ERROR";
    })(LogType = log_1.LogType || (log_1.LogType = {}));
    let category_mapping = new Map([
        [LogCategory.CHANNEL, "Channel    "],
        [LogCategory.CLIENT, "Client     "],
        [LogCategory.SERVER, "Server     "],
        [LogCategory.PERMISSIONS, "Permission "],
        [LogCategory.GENERAL, "General    "],
        [LogCategory.NETWORKING, "Network    "],
        [LogCategory.VOICE, "Voice      "],
        [LogCategory.I18N, "I18N       "]
    ]);
    function logDirect(type, message, ...optionalParams) {
        switch (type) {
            case LogType.TRACE:
            case LogType.DEBUG:
                console.debug(message, ...optionalParams);
                break;
            case LogType.INFO:
                console.log(message, ...optionalParams);
                break;
            case LogType.WARNING:
                console.warn(message, ...optionalParams);
                break;
            case LogType.ERROR:
                console.error(message, ...optionalParams);
                break;
        }
        //console.log("This is %cMy stylish message", "color: yellow; font-style: italic; background-color: blue;padding: 2px");
    }
    function log(type, category, message, ...optionalParams) {
        optionalParams.unshift(category_mapping.get(category));
        message = "[%s] " + message;
        logDirect(type, message, ...optionalParams);
    }
    log_1.log = log;
    function trace(category, message, ...optionalParams) {
        log(LogType.TRACE, category, message, ...optionalParams);
    }
    log_1.trace = trace;
    function debug(category, message, ...optionalParams) {
        log(LogType.DEBUG, category, message, ...optionalParams);
    }
    log_1.debug = debug;
    function info(category, message, ...optionalParams) {
        log(LogType.INFO, category, message, ...optionalParams);
    }
    log_1.info = info;
    function warn(category, message, ...optionalParams) {
        log(LogType.WARNING, category, message, ...optionalParams);
    }
    log_1.warn = warn;
    function error(category, message, ...optionalParams) {
        log(LogType.ERROR, category, message, ...optionalParams);
    }
    log_1.error = error;
    function group(level, category, name, ...optionalParams) {
        name = "[%s] " + name;
        optionalParams.unshift(category_mapping.get(category));
        return new Group(level, category, name, optionalParams);
    }
    log_1.group = group;
    class Group {
        constructor(level, category, name, optionalParams, owner = undefined) {
            this.owner = undefined;
            this._collapsed = true;
            this.initialized = false;
            this.level = level;
            this.category = category;
            this.name = name;
            this.optionalParams = optionalParams;
        }
        group(level, name, ...optionalParams) {
            return new Group(level, this.category, name, optionalParams, this);
        }
        collapsed(flag = true) {
            this._collapsed = flag;
            return this;
        }
        log(message, ...optionalParams) {
            if (!this.initialized) {
                if (this._collapsed && console.groupCollapsed)
                    console.groupCollapsed(this.name, ...this.optionalParams);
                else
                    console.group(this.name, ...this.optionalParams);
                this.initialized = true;
            }
            logDirect(this.level, message, ...optionalParams);
            return this;
        }
        end() {
            if (this.initialized)
                console.groupEnd();
        }
    }
    log_1.Group = Group;
})(log || (log = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["2ac348e27bdb757e760626d300b62949481e6162c708c66ef8c6ac4527c33538"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["2ac348e27bdb757e760626d300b62949481e6162c708c66ef8c6ac4527c33538"] = "2ac348e27bdb757e760626d300b62949481e6162c708c66ef8c6ac4527c33538";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "qH0LSMwr", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (17,26)" }, { name: "pNpRUqbx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (19,25)" }, { name: "JKRsCeAw", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (108,26)" }, { name: "AGqphmky", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (112,26)" }, { name: "YmhPgfF1", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (116,26)" }, { name: "lFRCsghU", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (121,25)" }, { name: "EBxffkxU", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (137,33)" }, { name: "GeMOpQQi", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (141,37)" }, { name: "wWM5onju", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (156,29)" }, { name: "rQtnx4HN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (199,34)" }, { name: "hmh0mFRt", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioController.ts (214,34)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var PlayerState;
(function (PlayerState) {
    PlayerState[PlayerState["PREBUFFERING"] = 0] = "PREBUFFERING";
    PlayerState[PlayerState["PLAYING"] = 1] = "PLAYING";
    PlayerState[PlayerState["BUFFERING"] = 2] = "BUFFERING";
    PlayerState[PlayerState["STOPPING"] = 3] = "STOPPING";
    PlayerState[PlayerState["STOPPED"] = 4] = "STOPPED";
})(PlayerState || (PlayerState = {}));
class AudioController {
    constructor() {
        this.playerState = PlayerState.STOPPED;
        this.audioCache = [];
        this.playingAudioCache = [];
        this._volume = 1;
        this._codecCache = [];
        this._timeIndex = 0;
        this._latencyBufferLength = 3;
        this.allowBuffering = true;
        audio.player.on_ready(() => this.speakerContext = audio.player.context());
        this.onSpeaking = function () { };
        this.onSilence = function () { };
    }
    static initializeAudioController() {
        if (!audio.player.initialize())
            console.warn(_translations.qH0LSMwr || (_translations.qH0LSMwr = tr("Failed to initialize audio controller!")));
        sound.initialize().then(() => {
            console.log(_translations.pNpRUqbx || (_translations.pNpRUqbx = tr("Sounds initialitzed")));
        });
        //this._globalReplayScheduler = setInterval(() => { AudioController.invokeNextReplay(); }, 20); //Fix me
    }
    initialize() {
        AudioController._audioInstances.push(this);
    }
    close() {
        AudioController._audioInstances.remove(this);
    }
    playBuffer(buffer) {
        if (!buffer) {
            console.warn(_translations.JKRsCeAw || (_translations.JKRsCeAw = tr("[AudioController] Got empty or undefined buffer! Dropping it")));
            return;
        }
        if (!this.speakerContext) {
            console.warn(_translations.AGqphmky || (_translations.AGqphmky = tr("[AudioController] Failed to replay audio. Global audio context not initialized yet!")));
            return;
        }
        if (buffer.sampleRate != this.speakerContext.sampleRate)
            console.warn(_translations.YmhPgfF1 || (_translations.YmhPgfF1 = tr("[AudioController] Source sample rate isn't equal to playback sample rate! (%o | %o)")), buffer.sampleRate, this.speakerContext.sampleRate);
        this.applyVolume(buffer);
        this.audioCache.push(buffer);
        if (this.playerState == PlayerState.STOPPED || this.playerState == PlayerState.STOPPING) {
            console.log(_translations.lFRCsghU || (_translations.lFRCsghU = tr("[Audio] Starting new playback")));
            this.playerState = PlayerState.PREBUFFERING;
            //New audio
        }
        switch (this.playerState) {
            case PlayerState.PREBUFFERING:
            case PlayerState.BUFFERING:
                this.reset_buffer_timeout(true); //Reset timeout, we got a new buffer
                if (this.audioCache.length <= this._latencyBufferLength) {
                    if (this.playerState == PlayerState.BUFFERING) {
                        if (this.allowBuffering)
                            break;
                    }
                    else
                        break;
                }
                if (this.playerState == PlayerState.PREBUFFERING) {
                    console.log(_translations.EBxffkxU || (_translations.EBxffkxU = tr("[Audio] Prebuffering succeeded (Replaying now)")));
                    this.onSpeaking();
                }
                else {
                    if (this.allowBuffering)
                        console.log(_translations.GeMOpQQi || (_translations.GeMOpQQi = tr("[Audio] Buffering succeeded (Replaying now)")));
                }
                this.playerState = PlayerState.PLAYING;
            case PlayerState.PLAYING:
                this.playQueue();
                break;
            default:
                break;
        }
    }
    playQueue() {
        let buffer;
        while (buffer = this.audioCache.pop_front()) {
            if (this.playingAudioCache.length >= this._latencyBufferLength * 1.5 + 3) {
                console.log(_translations.wWM5onju || (_translations.wWM5onju = tr("Dropping buffer because playing queue grows to much")));
                continue; /* drop the data (we're behind) */
            }
            if (this._timeIndex < this.speakerContext.currentTime)
                this._timeIndex = this.speakerContext.currentTime;
            let player = this.speakerContext.createBufferSource();
            player.buffer = buffer;
            player.onended = () => this.removeNode(player);
            this.playingAudioCache.push(player);
            player.connect(audio.player.destination());
            player.start(this._timeIndex);
            this._timeIndex += buffer.duration;
        }
    }
    removeNode(node) {
        this.playingAudioCache.remove(node);
        this.testBufferQueue();
    }
    stopAudio(now = false) {
        this.playerState = PlayerState.STOPPING;
        if (now) {
            this.playerState = PlayerState.STOPPED;
            this.audioCache = [];
            for (let entry of this.playingAudioCache)
                entry.stop(0);
            this.playingAudioCache = [];
        }
        this.testBufferQueue();
        this.playQueue(); //Flush queue
    }
    testBufferQueue() {
        if (this.audioCache.length == 0 && this.playingAudioCache.length == 0) {
            if (this.playerState != PlayerState.STOPPING && this.playerState != PlayerState.STOPPED) {
                if (this.playerState == PlayerState.BUFFERING)
                    return; //We're already buffering
                this.playerState = PlayerState.BUFFERING;
                if (!this.allowBuffering)
                    console.warn(_translations.rQtnx4HN || (_translations.rQtnx4HN = tr("[Audio] Detected a buffer underflow!")));
                this.reset_buffer_timeout(true);
            }
            else {
                this.playerState = PlayerState.STOPPED;
                this.onSilence();
            }
        }
    }
    reset_buffer_timeout(restart) {
        if (this._buffer_timeout)
            clearTimeout(this._buffer_timeout);
        if (restart)
            this._buffer_timeout = setTimeout(() => {
                if (this.playerState == PlayerState.PREBUFFERING || this.playerState == PlayerState.BUFFERING) {
                    console.warn(_translations.hmh0mFRt || (_translations.hmh0mFRt = tr("[Audio] Buffering exceeded timeout. Flushing and stopping replay")));
                    this.stopAudio();
                }
                this._buffer_timeout = undefined;
            }, 1000);
    }
    get volume() { return this._volume; }
    set volume(val) {
        if (this._volume == val)
            return;
        this._volume = val;
        for (let buffer of this.audioCache)
            this.applyVolume(buffer);
    }
    applyVolume(buffer) {
        if (this._volume == 1)
            return;
        for (let channel = 0; channel < buffer.numberOfChannels; channel++) {
            let data = buffer.getChannelData(channel);
            for (let sample = 0; sample < data.length; sample++) {
                let lane = data[sample];
                lane *= this._volume;
                data[sample] = lane;
            }
        }
    }
    codecCache(codec) {
        while (this._codecCache.length <= codec)
            this._codecCache.push(new CodecClientCache());
        return this._codecCache[codec];
    }
}
AudioController._audioInstances = [];
AudioController._timeIndex = 0;
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["a0e0b37e09718c2846efd83cb4cbd5ead40537275cf7922581b67ae75d378926"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["a0e0b37e09718c2846efd83cb4cbd5ead40537275cf7922581b67ae75d378926"] = "a0e0b37e09718c2846efd83cb4cbd5ead40537275cf7922581b67ae75d378926";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "MlLUvNyu", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/proto.ts (49,31)" }, { name: "tX8TiDgM", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/proto.ts (53,31)" }, { name: "dRtcLsVp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/proto.ts (72,27)" }, { name: "m7yzx_gq", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/proto.ts (172,33)" }, { name: "Lc_rvEsz", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/proto.ts (174,32)" }, { name: "HTQzodAL", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/proto.ts (176,33)" }, { name: "pzlKFDSj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/proto.ts (178,35)" }, { name: "SCMW_Ksq", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/proto.ts (180,35)" }, { name: "hz5cly26", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/proto.ts (182,18)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
if (!JSON.map_to) {
    JSON.map_to = function (object, json, variables, validator, variable_direction) {
        if (!validator)
            validator = (a, b) => true;
        if (!variables) {
            variables = [];
            if (!variable_direction || variable_direction == 0) {
                for (let field in json)
                    variables.push(field);
            }
            else if (variable_direction == 1) {
                for (let field in object)
                    variables.push(field);
            }
        }
        else if (!Array.isArray(variables)) {
            variables = [variables];
        }
        for (let field of variables) {
            if (!json[field]) {
                console.trace(_translations.MlLUvNyu || (_translations.MlLUvNyu = tr("Json does not contains %s")), field);
                continue;
            }
            if (!validator(field, json[field])) {
                console.trace(_translations.tX8TiDgM || (_translations.tX8TiDgM = tr("Validator results in false for %s")), field);
                continue;
            }
            JSON.map_field_to(object, json[field], field);
        }
        return object;
    };
}
if (!JSON.map_field_to) {
    JSON.map_field_to = function (object, value, field) {
        let field_type = typeof (object[field]);
        if (field_type == "string" || field_type == "object" || field_type == "undefined")
            object[field] = value;
        else if (field_type == "number")
            object[field] = parseFloat(value);
        else if (field_type == "boolean")
            object[field] = value == "1" || value == "true";
        else
            console.warn(_translations.dRtcLsVp || (_translations.dRtcLsVp = tr("Invalid object type %s for entry %s")), field_type, field);
        return object;
    };
}
if (!Array.prototype.remove) {
    Array.prototype.remove = function (elem) {
        const index = this.indexOf(elem, 0);
        if (index > -1) {
            this.splice(index, 1);
            return true;
        }
        return false;
    };
}
if (!Array.prototype.pop_front) {
    Array.prototype.pop_front = function () {
        if (this.length == 0)
            return undefined;
        return this.splice(0, 1)[0];
    };
}
if (!Array.prototype.last) {
    Array.prototype.last = function () {
        if (this.length == 0)
            return undefined;
        return this[this.length - 1];
    };
}
if (typeof ($) !== "undefined") {
    if (!$.spawn) {
        $.spawn = function (tagName) {
            return $(document.createElement(tagName));
        };
    }
    if (!$.fn.renderTag) {
        $.fn.renderTag = function (values) {
            let result;
            if (this.render) {
                result = $(this.render(values));
            }
            else {
                const template = window.jsrender.render[this.attr("id")];
                /*
                result = window.jsrender.templates("tmpl_permission_entry", $("#tmpl_permission_entry").html());
                result = window.jsrender.templates("xxx", this.html());
                */
                result = template(values);
                result = $(result);
            }
            result.find("node").each((index, element) => {
                $(element).replaceWith(values[$(element).attr("key")] || (values[0] || [])[$(element).attr("key")]);
            });
            return result;
        };
    }
    if (!$.fn.hasScrollBar)
        $.fn.hasScrollBar = function () {
            return this.get(0).scrollHeight > this.height();
        };
}
if (!String.prototype.format) {
    String.prototype.format = function () {
        const args = arguments;
        let array = args.length == 1 && $.isArray(args[0]);
        return this.replace(/\{\{|\}\}|\{(\d+)\}/g, function (m, n) {
            if (m == "{{") {
                return "{";
            }
            if (m == "}}") {
                return "}";
            }
            return array ? args[0][n] : args[n];
        });
    };
}
function concatenate(resultConstructor, ...arrays) {
    let totalLength = 0;
    for (const arr of arrays) {
        totalLength += arr.length;
    }
    const result = new resultConstructor(totalLength);
    let offset = 0;
    for (const arr of arrays) {
        result.set(arr, offset);
        offset += arr.length;
    }
    return result;
}
function formatDate(secs) {
    let years = Math.floor(secs / (60 * 60 * 24 * 365));
    let days = Math.floor(secs / (60 * 60 * 24)) % 365;
    let hours = Math.floor(secs / (60 * 60)) % 24;
    let minutes = Math.floor(secs / 60) % 60;
    let seconds = Math.floor(secs % 60);
    let result = "";
    if (years > 0)
        result += years + " " + (_translations.m7yzx_gq || (_translations.m7yzx_gq = tr("years"))) + " ";
    if (years > 0 || days > 0)
        result += days + " " + (_translations.Lc_rvEsz || (_translations.Lc_rvEsz = tr("days"))) + " ";
    if (years > 0 || days > 0 || hours > 0)
        result += hours + " " + (_translations.HTQzodAL || (_translations.HTQzodAL = tr("hours"))) + " ";
    if (years > 0 || days > 0 || hours > 0 || minutes > 0)
        result += minutes + " " + (_translations.pzlKFDSj || (_translations.pzlKFDSj = tr("minutes"))) + " ";
    if (years > 0 || days > 0 || hours > 0 || minutes > 0 || seconds > 0)
        result += seconds + " " + (_translations.SCMW_Ksq || (_translations.SCMW_Ksq = tr("seconds"))) + " ";
    else
        result = (_translations.hz5cly26 || (_translations.hz5cly26 = tr("now"))) + " ";
    return result.substr(0, result.length - 1);
}
function calculate_width(text) {
    let element = $.spawn("div");
    element.text(text)
        .css("display", "none")
        .css("margin", 0);
    $("body").append(element);
    let size = element.width();
    element.detach();
    return size;
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["b5e33b13ef93bbcb543b839caebc4b861cf0ff796d5bdb26c5e386d39dd0edd9"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["b5e33b13ef93bbcb543b839caebc4b861cf0ff796d5bdb26c5e386d39dd0edd9"] = "b5e33b13ef93bbcb543b839caebc4b861cf0ff796d5bdb26c5e386d39dd0edd9";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var CodecType;
(function (CodecType) {
    CodecType[CodecType["OPUS_VOICE"] = 0] = "OPUS_VOICE";
    CodecType[CodecType["OPUS_MUSIC"] = 1] = "OPUS_MUSIC";
    CodecType[CodecType["SPEEX_NARROWBAND"] = 2] = "SPEEX_NARROWBAND";
    CodecType[CodecType["SPEEX_WIDEBAND"] = 3] = "SPEEX_WIDEBAND";
    CodecType[CodecType["SPEEX_ULTRA_WIDEBAND"] = 4] = "SPEEX_ULTRA_WIDEBAND";
    CodecType[CodecType["CELT_MONO"] = 5] = "CELT_MONO";
})(CodecType || (CodecType = {}));
class BufferChunk {
    constructor(buffer) {
        this.buffer = buffer;
        this.index = 0;
    }
    copyRangeTo(target, maxLength, offset) {
        let copy = Math.min(this.buffer.length - this.index, maxLength);
        //TODO may warning if channel counts are not queal?
        for (let channel = 0; channel < Math.min(target.numberOfChannels, this.buffer.numberOfChannels); channel++) {
            target.getChannelData(channel).set(this.buffer.getChannelData(channel).subarray(this.index, this.index + copy), offset);
        }
        return copy;
    }
}
class CodecClientCache {
    constructor() {
        this._chunks = [];
    }
    bufferedSamples(max = 0) {
        let value = 0;
        for (let i = 0; i < this._chunks.length && value < max; i++)
            value += this._chunks[i].buffer.length - this._chunks[i].index;
        return value;
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["24155675f2d0dcf00504efe2d29268d5c1514e69b259190cf3b983170339a3de"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["24155675f2d0dcf00504efe2d29268d5c1514e69b259190cf3b983170339a3de"] = "24155675f2d0dcf00504efe2d29268d5c1514e69b259190cf3b983170339a3de";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "VVvaIQNx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/utils/modal.ts (26,30)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
$(document).on("mousedown", function (e) {
    if ($(e.target).parents("#contextMenu").length == 0 && $(e.target).parents(".modal").length == 0) {
        $(".modal:visible").last().find(".close").trigger("click");
    }
});
const ModalFunctions = {
    divify: function (val) {
        if (val.length > 1)
            return $.spawn("div").append(val);
        return val;
    },
    jqueriefy: function (val) {
        if ($.isFunction(val))
            val = val();
        if ($.isArray(val)) {
            let result = $.spawn("div");
            for (let element of val)
                this.jqueriefy(element).appendTo(result);
            return result;
        }
        switch (typeof val) {
            case "string": return $("<div>" + val + "</div>");
            case "object": return val;
            case "undefined":
                console.warn(_translations.VVvaIQNx || (_translations.VVvaIQNx = tr("Got undefined type!")));
                return $.spawn("div");
            default:
                console.error(("Invalid type %o"), typeof val);
                return $();
        }
    },
    warpProperties(data) {
        if (data instanceof ModalProperties)
            return data;
        else {
            let props = new ModalProperties();
            for (let key in data)
                props[key] = data[key];
            return props;
        }
    }
};
class ModalProperties {
    constructor() {
        this.header = () => "HEADER";
        this.body = () => "BODY";
        this.footer = () => "FOOTER";
        this.closeListener = () => { };
        this.width = "60%";
        this.height = "auto";
        this.closeable = true;
    }
    registerCloseListener(listener) {
        if (this.closeListener) {
            if ($.isArray(this.closeListener))
                this.closeListener.push(listener);
            else
                this.closeListener = [this.closeListener, listener];
        }
        else
            this.closeListener = listener;
        return this;
    }
    triggerClose() {
        if ($.isArray(this.closeListener))
            for (let listener of this.closeListener)
                listener();
        else
            this.closeListener();
    }
}
class Modal {
    constructor(props) {
        this.close_listener = [];
        this.properties = props;
        this.shown = false;
    }
    get htmlTag() {
        if (!this._htmlTag)
            this._create();
        return this._htmlTag;
    }
    _create() {
        let modal = $.spawn("div");
        modal.addClass("modal");
        let content = $.spawn("div");
        content.addClass("modal-content");
        if (this.properties.width)
            content.css("width", this.properties.width);
        if (this.properties.height)
            content.css("height", this.properties.height);
        let header = ModalFunctions.divify(ModalFunctions.jqueriefy(this.properties.header)).addClass("modal-header");
        if (this.properties.closeable)
            header.append("<span class=\"close\">&times;</span>");
        let body = ModalFunctions.divify(ModalFunctions.jqueriefy(this.properties.body)).addClass("modal-body");
        let footer = ModalFunctions.divify(ModalFunctions.jqueriefy(this.properties.footer)).addClass("modal-footer");
        content.append(header);
        content.append(body);
        content.append(footer);
        modal.append(content);
        modal.find(".close").click(function () {
            if (this.properties.closeable)
                this.close();
        }.bind(this));
        this._htmlTag = modal;
    }
    open() {
        this.shown = true;
        this.htmlTag.appendTo($("body"));
        this.htmlTag.show();
    }
    close() {
        if (!this.shown)
            return;
        this.shown = false;
        const _this = this;
        this.htmlTag.animate({ opacity: 0 }, () => {
            _this.htmlTag.detach();
        });
        this.properties.triggerClose();
        for (const listener of this.close_listener)
            listener();
    }
}
function createModal(data) {
    return new Modal(ModalFunctions.warpProperties(data));
}
class InputModalProperties extends ModalProperties {
}
function createInputModal(headMessage, question, validator, callback, props = {}) {
    props = ModalFunctions.warpProperties(props);
    let head = $.spawn("div");
    head.css("border-bottom", "grey solid");
    head.css("border-width", "1px");
    ModalFunctions.jqueriefy(headMessage).appendTo(head);
    let body = $.spawn("div");
    ModalFunctions.divify(ModalFunctions.jqueriefy(question)).appendTo(body);
    let input = $.spawn("input");
    input.css("width", "100%");
    input.appendTo(body);
    console.log(input);
    let footer = $.spawn("div");
    footer.addClass("modal-button-group");
    footer.css("margin-top", "5px");
    let buttonCancel = $.spawn("button");
    buttonCancel.text("Cancel");
    let buttonOk = $.spawn("button");
    buttonOk.text("Ok");
    footer.append(buttonCancel);
    footer.append(buttonOk);
    input.on("keydown", function (event) {
        if (event.keyCode == 13 /* Enter */) {
            buttonOk.trigger("click");
        }
    });
    let updateValidation = function () {
        let text = input.val().toString();
        let flag = (!props.maxLength || text.length <= props.maxLength) && validator(text);
        if (flag) {
            input.removeClass("invalid_input");
            buttonOk.removeAttr("disabled");
        }
        else {
            if (!input.hasClass("invalid_input"))
                input.addClass("invalid_input");
            buttonOk.attr("disabled", "true");
        }
    };
    input.on("keyup", updateValidation);
    let callbackCalled = false;
    let wrappedCallback = function (flag) {
        if (callbackCalled)
            return;
        callbackCalled = true;
        callback(flag);
    };
    let modal;
    buttonOk.on("click", () => {
        wrappedCallback(input.val().toString());
        modal.close();
    });
    buttonCancel.on("click", () => {
        wrappedCallback(false);
        modal.close();
    });
    props.header = head;
    props.body = body;
    props.footer = footer;
    props.closeListener = () => wrappedCallback(false);
    modal = createModal(props);
    return modal;
}
function createErrorModal(header, message, props = { footer: "" }) {
    props = ModalFunctions.warpProperties(props);
    let head = $.spawn("div");
    head.addClass("modal-head-error");
    ModalFunctions.divify(ModalFunctions.jqueriefy(header)).appendTo(head);
    props.header = head;
    props.body = $.spawn("div").append(ModalFunctions.divify(ModalFunctions.jqueriefy(message)));
    props.footer = ModalFunctions.divify(ModalFunctions.jqueriefy(""));
    return createModal(props);
}
function createInfoModal(header, message, props = { footer: "" }) {
    props = ModalFunctions.warpProperties(props);
    let head = $.spawn("div");
    head.addClass("modal-head-info");
    ModalFunctions.divify(ModalFunctions.jqueriefy(header)).appendTo(head);
    props.header = head;
    props.body = ModalFunctions.divify(ModalFunctions.jqueriefy(message));
    props.footer = ModalFunctions.divify(ModalFunctions.jqueriefy(""));
    return createModal(props);
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["7023dd9d5411be65ab0535bcbd35d2dfbac18310295a9811d5a007991256d5c2"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["7023dd9d5411be65ab0535bcbd35d2dfbac18310295a9811d5a007991256d5c2"] = "7023dd9d5411be65ab0535bcbd35d2dfbac18310295a9811d5a007991256d5c2";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "lvLtCog5", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceRecorder.ts (125,34)" }, { name: "NfQ_ihQJ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceRecorder.ts (125,54)" }, { name: "g3I_9wEe", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceRecorder.ts (159,26)" }, { name: "nOEBHgFj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceRecorder.ts (208,21)" }, { name: "tWQFZYV5", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceRecorder.ts (220,30)" }, { name: "ojbzWOjp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceRecorder.ts (220,67)" }, { name: "pjoAug6Y", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceRecorder.ts (221,27)" }, { name: "dj6BkHvV", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceRecorder.ts (227,21)" }, { name: "htdQIgn5", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceRecorder.ts (253,25)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="VoiceHandler.ts" />
/// <reference path="../utils/modal.ts" />
class VoiceActivityDetector {
    initialise() { }
    finalize() { }
    initialiseNewStream(old, _new) { }
    changeHandle(handle, triggerNewStream) {
        const oldStream = !this.handle ? undefined : this.handle.getMicrophoneStream();
        this.handle = handle;
        if (triggerNewStream)
            this.initialiseNewStream(oldStream, !handle ? undefined : handle.getMicrophoneStream());
    }
}
if (!AudioBuffer.prototype.copyToChannel) { //Webkit does not implement this function
    AudioBuffer.prototype.copyToChannel = function (source, channelNumber, startInChannel) {
        if (!startInChannel)
            startInChannel = 0;
        let destination = this.getChannelData(channelNumber);
        for (let index = 0; index < source.length; index++)
            if (destination.length < index + startInChannel)
                destination[index + startInChannel] = source[index];
    };
}
class VoiceRecorder {
    constructor(handle) {
        this.on_data = undefined;
        this._recording = false;
        this.microphoneStream = undefined;
        this.mediaStream = undefined;
        this._chunkCount = 0;
        this.handle = handle;
        this._deviceId = settings.global("microphone_device_id", "default");
        this._deviceGroup = settings.global("microphone_device_group", "default");
        audio.player.on_ready(() => {
            this.audioContext = audio.player.context();
            this.processor = this.audioContext.createScriptProcessor(VoiceRecorder.BUFFER_SIZE, VoiceRecorder.CHANNELS, VoiceRecorder.CHANNELS);
            const empty_buffer = this.audioContext.createBuffer(VoiceRecorder.CHANNELS, VoiceRecorder.BUFFER_SIZE, 48000);
            this.processor.addEventListener('audioprocess', ev => {
                if (this.microphoneStream && this.vadHandler.shouldRecord(ev.inputBuffer)) {
                    if (this._chunkCount == 0 && this.on_start)
                        this.on_start();
                    if (this.on_data)
                        this.on_data(ev.inputBuffer, this._chunkCount == 0);
                    else {
                        for (let channel = 0; channel < ev.inputBuffer.numberOfChannels; channel++)
                            ev.outputBuffer.copyToChannel(ev.inputBuffer.getChannelData(channel), channel);
                    }
                    this._chunkCount++;
                }
                else {
                    if (this._chunkCount != 0 && this.on_end)
                        this.on_end();
                    this._chunkCount = 0;
                    for (let channel = 0; channel < ev.inputBuffer.numberOfChannels; channel++)
                        ev.outputBuffer.copyToChannel(empty_buffer.getChannelData(channel), channel);
                }
            });
            this.processor.connect(this.audioContext.destination);
            if (this.vadHandler)
                this.vadHandler.initialise();
            this.on_microphone(this.mediaStream);
        });
        this.setVADHandler(new PassThroughVAD());
    }
    get_output_stream() { return this.processor; }
    available() {
        return !!getUserMediaFunction() && !!getUserMediaFunction();
    }
    recording() {
        return this._recording;
    }
    getMediaStream() {
        return this.mediaStream;
    }
    getMicrophoneStream() {
        return this.microphoneStream;
    }
    reinitialiseVAD() {
        let type = settings.global("vad_type", "vad");
        if (type == "ppt") {
            if (settings.global('vad_ppt_key', undefined)) {
                //TODO remove that because its legacy shit
                createErrorModal(_translations.lvLtCog5 || (_translations.lvLtCog5 = tr("VAD changed!")), _translations.NfQ_ihQJ || (_translations.NfQ_ihQJ = tr("VAD key detection changed.<br>Please reset your PPT key!"))).open();
            }
            let ppt_settings = settings.global('vad_ppt_settings', undefined);
            ppt_settings = ppt_settings ? JSON.parse(ppt_settings) : {};
            if (ppt_settings.version === undefined)
                ppt_settings.version = 1;
            if (ppt_settings.key_code === undefined)
                ppt_settings.key_code = "KeyT";
            if (ppt_settings.key_ctrl === undefined)
                ppt_settings.key_ctrl = false;
            if (ppt_settings.key_shift === undefined)
                ppt_settings.key_shift = false;
            if (ppt_settings.key_alt === undefined)
                ppt_settings.key_alt = false;
            if (ppt_settings.key_windows === undefined)
                ppt_settings.key_windows = false;
            if (!(this.getVADHandler() instanceof PushToTalkVAD))
                this.setVADHandler(new PushToTalkVAD(ppt_settings));
            else
                this.getVADHandler().key = ppt_settings;
        }
        else if (type == "pt") {
            if (!(this.getVADHandler() instanceof PassThroughVAD))
                this.setVADHandler(new PassThroughVAD());
        }
        else if (type == "vad") {
            if (!(this.getVADHandler() instanceof VoiceActivityDetectorVAD))
                this.setVADHandler(new VoiceActivityDetectorVAD());
            this.getVADHandler().percentageThreshold = settings.global("vad_threshold", 50);
        }
        else {
            console.warn(_translations.g3I_9wEe || (_translations.g3I_9wEe = tr("Invalid VAD (Voice activation detector) handler! (%o)")), type);
        }
    }
    setVADHandler(handler) {
        if (this.vadHandler) {
            this.vadHandler.changeHandle(null, true);
            this.vadHandler.finalize();
        }
        this.vadHandler = handler;
        this.vadHandler.changeHandle(this, false);
        if (this.audioContext) {
            this.vadHandler.initialise();
            if (this.microphoneStream)
                this.vadHandler.initialiseNewStream(undefined, this.microphoneStream);
        }
    }
    getVADHandler() {
        return this.vadHandler;
    }
    update(flag) {
        if (this._recording == flag)
            return;
        if (flag)
            this.start(this._deviceId, this._deviceGroup);
        else
            this.stop();
    }
    device_group_id() { return this._deviceGroup; }
    device_id() { return this._deviceId; }
    change_device(device, group) {
        if (this._deviceId == device && this._deviceGroup == group)
            return;
        this._deviceId = device;
        this._deviceGroup = group;
        settings.changeGlobal("microphone_device_id", device);
        settings.changeGlobal("microphone_device_group", group);
        if (this._recording) {
            this.stop();
            this.start(device, group);
        }
    }
    start(device, groupId) {
        this._deviceId = device;
        this._deviceGroup = groupId;
        console.log(_translations.nOEBHgFj || (_translations.nOEBHgFj = tr("[VoiceRecorder] Start recording! (Device: %o | Group: %o)")), device, groupId);
        this._recording = true;
        //FIXME Implement that here for thew client as well
        getUserMediaFunction()({
            audio: {
                deviceId: device,
                groupId: groupId,
                echoCancellation: true,
                echoCancellationType: 'browser'
            }
        }, this.on_microphone.bind(this), error => {
            createErrorModal(_translations.tWQFZYV5 || (_translations.tWQFZYV5 = tr("Could not resolve microphone!")), (_translations.ojbzWOjp || (_translations.ojbzWOjp = tr("Could not resolve microphone!<br>Message: "))) + error).open();
            console.error(_translations.pjoAug6Y || (_translations.pjoAug6Y = tr("Could not get microphone!")));
            console.error(error);
        });
    }
    stop(stop_media_stream = true) {
        console.log(_translations.dj6BkHvV || (_translations.dj6BkHvV = tr("Stop recording!")));
        this._recording = false;
        if (this.microphoneStream)
            this.microphoneStream.disconnect();
        this.microphoneStream = undefined;
        if (stop_media_stream && this.mediaStream) {
            if (this.mediaStream.stop)
                this.mediaStream.stop();
            else
                this.mediaStream.getTracks().forEach(value => {
                    value.stop();
                });
            this.mediaStream = undefined;
        }
    }
    on_microphone(stream) {
        const old_microphone_stream = this.microphoneStream;
        if (old_microphone_stream)
            this.stop(this.mediaStream != stream); //Disconnect old stream
        this.mediaStream = stream;
        if (!this.mediaStream)
            return;
        if (!this.audioContext) {
            console.log(_translations.htdQIgn5 || (_translations.htdQIgn5 = tr("[VoiceRecorder] Got microphone stream, but havn't a audio context. Waiting until its initialized")));
            return;
        }
        this.microphoneStream = this.audioContext.createMediaStreamSource(stream);
        this.microphoneStream.connect(this.processor);
        if (this.vadHandler)
            this.vadHandler.initialiseNewStream(old_microphone_stream, this.microphoneStream);
    }
}
VoiceRecorder.CHANNEL = 0;
VoiceRecorder.CHANNELS = 2;
VoiceRecorder.BUFFER_SIZE = 1024 * 4;
class MuteVAD extends VoiceActivityDetector {
    shouldRecord(buffer) {
        return false;
    }
}
class PassThroughVAD extends VoiceActivityDetector {
    shouldRecord(buffer) {
        return true;
    }
}
class VoiceActivityDetectorVAD extends VoiceActivityDetector {
    constructor() {
        super(...arguments);
        this.continuesCount = 0;
        this.maxContinuesCount = 12;
        this.percentageThreshold = 50;
        this.percentage_listener = ($) => { };
    }
    initialise() {
        this.analyzer = audio.player.context().createAnalyser();
        this.analyzer.smoothingTimeConstant = 1; //TODO test
        this.buffer = new Uint8Array(this.analyzer.fftSize);
        return super.initialise();
    }
    initialiseNewStream(old, _new) {
        if (this.analyzer)
            this.analyzer.disconnect();
        if (_new)
            _new.connect(this.analyzer);
    }
    shouldRecord(buffer) {
        let usage = this.calculateUsage();
        if ($.isFunction(this.percentage_listener))
            this.percentage_listener(usage);
        if (usage >= this.percentageThreshold) {
            this.continuesCount = 0;
        }
        else
            this.continuesCount++;
        return this.continuesCount < this.maxContinuesCount;
    }
    calculateUsage() {
        let total = 0, float, rms;
        this.analyzer.getByteTimeDomainData(this.buffer);
        for (let index = 0; index < this.analyzer.fftSize; index++) {
            float = (this.buffer[index++] / 0x7f) - 1;
            total += (float * float);
        }
        rms = Math.sqrt(total / this.analyzer.fftSize);
        let db = 20 * (Math.log(rms) / Math.log(10));
        // sanity check
        db = Math.max(-192, Math.min(db, 0));
        let percentage = 100 + (db * 1.92);
        return percentage;
    }
}
class PushToTalkVAD extends VoiceActivityDetector {
    constructor(key) {
        super();
        this._pushed = false;
        this._key = key;
        this._key_hook = {
            callback_release: () => this._pushed = false,
            callback_press: () => this._pushed = true,
            cancel: false
        };
        Object.assign(this._key_hook, this._key);
    }
    initialise() {
        ppt.register_key_hook(this._key_hook);
        return super.initialise();
    }
    finalize() {
        ppt.unregister_key_hook(this._key_hook);
        return super.finalize();
    }
    set pushed(flag) {
        this._pushed = flag;
    }
    set key(key) {
        ppt.unregister_key_hook(this._key_hook);
        Object.assign(this._key, key);
        Object.assign(this._key_hook, key);
        this._pushed = false;
        ppt.register_key_hook(this._key_hook);
    }
    shouldRecord(buffer) {
        return this._pushed;
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["dec1cd1126150474fea3d533bee6f74bdb7e3099481fdcb5ee37325f03b9d030"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["dec1cd1126150474fea3d533bee6f74bdb7e3099481fdcb5ee37325f03b9d030"] = "dec1cd1126150474fea3d533bee6f74bdb7e3099481fdcb5ee37325f03b9d030";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "OI1Sk0YD", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (26,29)" }, { name: "j4nse78H", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (29,30)" }, { name: "kQ_AeHlf", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (31,38)" }, { name: "S76uBNmK", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (31,73)" }, { name: "IYIYw0rU", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (44,24)" }, { name: "hy_PpV8f", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (58,43)" }, { name: "RJirYXUP", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (59,36)" }, { name: "phYfX5XB", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (132,30)" }, { name: "IyzHImYm", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (133,30)" }, { name: "Wj46g4c8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (134,30)" }, { name: "zwJmUNWx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (135,30)" }, { name: "monpgBxF", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (136,30)" }, { name: "BbN62wK_", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (137,30)" }, { name: "WRhL6zKt", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (153,41)" }, { name: "qzx2HJxi", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (193,37)" }, { name: "OhXV_Kjv", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (195,41)" }, { name: "TT4bBVdd", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (270,26)" }, { name: "PQSBv5JI", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (303,25)" }, { name: "R_ieorWh", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (306,27)" }, { name: "JqpZZJEC", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (320,25)" }, { name: "kC_xy7jf", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (322,29)" }, { name: "gxaXNyGN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (327,33)" }, { name: "aRTSL3Lh", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (332,29)" }, { name: "rt3O6Uo7", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (334,33)" }, { name: "Q0l9jzUk", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (337,29)" }, { name: "bV2oK3VW", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (342,47)" }, { name: "PATPjgc1", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (343,51)" }, { name: "g37VwgxM", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (354,21)" }, { name: "RAYXu4pp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (373,21)" }, { name: "zQF8qDJl", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (375,25)" }, { name: "cBrOv9iU", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (379,21)" }, { name: "hAUHhp_T", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (384,21)" }, { name: "uFjQb1IJ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (398,27)" }, { name: "cqDbdgt8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (404,27)" }, { name: "eCvCB5hz", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (420,35)" }, { name: "ZKCR_tr9", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (453,21)" }, { name: "MPzgSHpf", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/VoiceHandler.ts (460,21)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../client.ts" />
/// <reference path="../codec/Codec.ts" />
/// <reference path="VoiceRecorder.ts" />
class CodecPoolEntry {
}
class CodecPool {
    constructor(handle, index, name, type) {
        this.entries = [];
        this.maxInstances = 2;
        this._supported = true;
        this.handle = handle;
        this.codecIndex = index;
        this.name = name;
        this.type = type;
        this._supported = this.type !== undefined && audio.codec.supported(this.type);
    }
    initialize(cached) {
        for (let i = 0; i < cached; i++)
            this.ownCodec(i + 1).then(codec => {
                console.log(_translations.OI1Sk0YD || (_translations.OI1Sk0YD = tr("Release again! (%o)")), codec);
                this.releaseCodec(i + 1);
            }).catch(error => {
                console.warn(_translations.j4nse78H || (_translations.j4nse78H = tr("Disabling codec support for ")), this.name);
                if (this._supported) {
                    createErrorModal(_translations.kQ_AeHlf || (_translations.kQ_AeHlf = tr("Could not load codec driver")), (_translations.S76uBNmK || (_translations.S76uBNmK = tr("Could not load or initialize codec "))) + this.name + "<br>" +
                        "Error: <code>" + JSON.stringify(error) + "</code>").open();
                }
                this._supported = false;
                console.error(error);
            });
    }
    supported() { return this._supported; }
    ownCodec(clientId, create = true) {
        return new Promise((resolve, reject) => {
            if (!this._supported) {
                reject(_translations.IYIYw0rU || (_translations.IYIYw0rU = tr("unsupported codec!")));
                return;
            }
            let freeSlot = 0;
            for (let index = 0; index < this.entries.length; index++) {
                if (this.entries[index].owner == clientId) {
                    this.entries[index].last_access = new Date().getTime();
                    if (this.entries[index].instance.initialized())
                        resolve(this.entries[index].instance);
                    else {
                        this.entries[index].instance.initialise().then((flag) => {
                            //TODO test success flag
                            this.ownCodec(clientId, false).then(resolve).catch(reject);
                        }).catch(error => {
                            console.error(_translations.hy_PpV8f || (_translations.hy_PpV8f = tr("Could not initialize codec!\nError: %o")), error);
                            reject(_translations.RJirYXUP || (_translations.RJirYXUP = tr("Could not initialize codec!")));
                        });
                    }
                    return;
                }
                else if (freeSlot == 0 && this.entries[index].owner == 0) {
                    freeSlot = index;
                }
            }
            if (!create) {
                resolve(undefined);
                return;
            }
            if (freeSlot == 0) {
                freeSlot = this.entries.length;
                let entry = new CodecPoolEntry();
                entry.instance = audio.codec.new_instance(this.type);
                entry.instance.on_encoded_data = buffer => this.handle.handleEncodedVoicePacket(buffer, this.codecIndex);
                this.entries.push(entry);
            }
            this.entries[freeSlot].owner = clientId;
            this.entries[freeSlot].last_access = new Date().getTime();
            if (this.entries[freeSlot].instance.initialized())
                this.entries[freeSlot].instance.reset();
            else {
                this.ownCodec(clientId, false).then(resolve).catch(reject);
                return;
            }
            resolve(this.entries[freeSlot].instance);
        });
    }
    releaseCodec(clientId) {
        for (let index = 0; index < this.entries.length; index++)
            if (this.entries[index].owner == clientId)
                this.entries[index].owner = 0;
    }
}
var VoiceConnectionType;
(function (VoiceConnectionType) {
    VoiceConnectionType[VoiceConnectionType["JS_ENCODE"] = 0] = "JS_ENCODE";
    VoiceConnectionType[VoiceConnectionType["NATIVE_ENCODE"] = 1] = "NATIVE_ENCODE";
})(VoiceConnectionType || (VoiceConnectionType = {}));
class VoiceConnection {
    constructor(client) {
        this._type = VoiceConnectionType.NATIVE_ENCODE;
        this.codec_pool = [
            new CodecPool(this, 0, _translations.phYfX5XB || (_translations.phYfX5XB = tr("Speex Narrowband")), CodecType.SPEEX_NARROWBAND),
            new CodecPool(this, 1, _translations.IyzHImYm || (_translations.IyzHImYm = tr("Speex Wideband")), CodecType.SPEEX_WIDEBAND),
            new CodecPool(this, 2, _translations.Wj46g4c8 || (_translations.Wj46g4c8 = tr("Speex Ultra Wideband")), CodecType.SPEEX_ULTRA_WIDEBAND),
            new CodecPool(this, 3, _translations.zwJmUNWx || (_translations.zwJmUNWx = tr("CELT Mono")), CodecType.CELT_MONO),
            new CodecPool(this, 4, _translations.monpgBxF || (_translations.monpgBxF = tr("Opus Voice")), CodecType.OPUS_VOICE),
            new CodecPool(this, 5, _translations.BbN62wK_ || (_translations.BbN62wK_ = tr("Opus Music")), CodecType.OPUS_MUSIC)
        ];
        this.vpacketId = 0;
        this.chunkVPacketId = 0;
        this.voice_send_queue = [];
        this._ice_use_cache = true;
        this._ice_cache = [];
        this.client = client;
        this._type = settings.static_global("voice_connection_type", this._type);
        this.voiceRecorder = new VoiceRecorder(this);
        this.voiceRecorder.on_end = this.handleVoiceEnded.bind(this);
        this.voiceRecorder.on_start = this.handleVoiceStarted.bind(this);
        this.voiceRecorder.reinitialiseVAD();
        audio.player.on_ready(() => {
            log.info(LogCategory.VOICE, _translations.WRhL6zKt || (_translations.WRhL6zKt = tr("Initializing voice handler after AudioController has been initialized!")));
            if (native_client) {
                this.codec_pool[0].initialize(2);
                this.codec_pool[1].initialize(2);
                this.codec_pool[2].initialize(2);
                this.codec_pool[3].initialize(2);
            }
            this.codec_pool[4].initialize(2);
            this.codec_pool[5].initialize(2);
            if (this.type == VoiceConnectionType.NATIVE_ENCODE)
                this.setup_native();
            else
                this.setup_js();
        });
        this.send_task = setInterval(this.sendNextVoicePacket.bind(this), 20);
    }
    native_encoding_supported() {
        if (!(window.webkitAudioContext || window.AudioContext || { prototype: {} }).prototype.createMediaStreamDestination)
            return false; //Required, but not available within edge
        return true;
    }
    javascript_encoding_supported() {
        if (!(window.RTCPeerConnection || { prototype: {} }).prototype.createDataChannel)
            return false;
        return true;
    }
    current_encoding_supported() {
        switch (this._type) {
            case VoiceConnectionType.JS_ENCODE:
                return this.javascript_encoding_supported();
            case VoiceConnectionType.NATIVE_ENCODE:
                return this.native_encoding_supported();
        }
        return false;
    }
    setup_native() {
        log.info(LogCategory.VOICE, _translations.qzx2HJxi || (_translations.qzx2HJxi = tr("Setting up native voice stream!")));
        if (!this.native_encoding_supported()) {
            log.warn(LogCategory.VOICE, _translations.OhXV_Kjv || (_translations.OhXV_Kjv = tr("Native codec isnt supported!")));
            return;
        }
        this.voiceRecorder.on_data = undefined;
        let stream = this.voiceRecorder.get_output_stream();
        stream.disconnect();
        if (!this.local_audio_stream)
            this.local_audio_stream = audio.player.context().createMediaStreamDestination();
        stream.connect(this.local_audio_stream);
    }
    setup_js() {
        if (!this.javascript_encoding_supported())
            return;
        this.voiceRecorder.on_data = this.handleVoiceData.bind(this);
    }
    get type() { return this._type; }
    set type(target) {
        if (target == this.type)
            return;
        this._type = target;
        if (this.type == VoiceConnectionType.NATIVE_ENCODE)
            this.setup_native();
        else
            this.setup_js();
        this.createSession();
    }
    codecSupported(type) {
        return this.codec_pool.length > type && this.codec_pool[type].supported();
    }
    voice_playback_support() {
        return this.dataChannel && this.dataChannel.readyState == "open";
    }
    voice_send_support() {
        if (this.type == VoiceConnectionType.NATIVE_ENCODE)
            return this.native_encoding_supported() && this.rtcPeerConnection.getLocalStreams().length > 0;
        else
            return this.voice_playback_support();
    }
    handleEncodedVoicePacket(data, codec) {
        this.voice_send_queue.push({ data: data, codec: codec });
    }
    sendNextVoicePacket() {
        let buffer = this.voice_send_queue.pop_front();
        if (!buffer)
            return;
        this.sendVoicePacket(buffer.data, buffer.codec);
    }
    sendVoicePacket(data, codec) {
        if (this.dataChannel) {
            this.vpacketId++;
            if (this.vpacketId > 65535)
                this.vpacketId = 0;
            let packet = new Uint8Array(data.byteLength + 2 + 3);
            packet[0] = this.chunkVPacketId++ < 5 ? 1 : 0; //Flag header
            packet[1] = 0; //Flag fragmented
            packet[2] = (this.vpacketId >> 8) & 0xFF; //HIGHT (voiceID)
            packet[3] = (this.vpacketId >> 0) & 0xFF; //LOW   (voiceID)
            packet[4] = codec; //Codec
            packet.set(data, 5);
            try {
                this.dataChannel.send(packet);
            }
            catch (e) {
                //TODO may handle error?
            }
        }
        else {
            console.warn(_translations.TT4bBVdd || (_translations.TT4bBVdd = tr("Could not transfer audio (not connected)")));
        }
    }
    createSession() {
        if (!this.current_encoding_supported())
            return false;
        if (this.rtcPeerConnection) {
            this.dropSession();
        }
        this._ice_use_cache = true;
        let config = {};
        config.iceServers = [];
        config.iceServers.push({ urls: 'stun:stun.l.google.com:19302' });
        this.rtcPeerConnection = new RTCPeerConnection(config);
        const dataChannelConfig = { ordered: true, maxRetransmits: 0 };
        this.dataChannel = this.rtcPeerConnection.createDataChannel('main', dataChannelConfig);
        this.dataChannel.onmessage = this.onDataChannelMessage.bind(this);
        this.dataChannel.onopen = this.onDataChannelOpen.bind(this);
        this.dataChannel.binaryType = "arraybuffer";
        let sdpConstraints = {};
        sdpConstraints.offerToReceiveAudio = this._type == VoiceConnectionType.NATIVE_ENCODE;
        sdpConstraints.offerToReceiveVideo = false;
        this.rtcPeerConnection.onicecandidate = this.onIceCandidate.bind(this);
        if (this.local_audio_stream) { //May a typecheck?
            this.rtcPeerConnection.addStream(this.local_audio_stream.stream);
            console.log(_translations.PQSBv5JI || (_translations.PQSBv5JI = tr("Adding stream (%o)!")), this.local_audio_stream.stream);
        }
        this.rtcPeerConnection.createOffer(this.onOfferCreated.bind(this), () => {
            console.error(_translations.R_ieorWh || (_translations.R_ieorWh = tr("Could not create ice offer!")));
        }, sdpConstraints);
    }
    dropSession() {
        if (this.dataChannel)
            this.dataChannel.close();
        if (this.rtcPeerConnection)
            this.rtcPeerConnection.close();
        //TODO here!
    }
    handleControlPacket(json) {
        if (json["request"] === "answer") {
            console.log(_translations.JqpZZJEC || (_translations.JqpZZJEC = tr("Set remote sdp! (%o)")), json["msg"]);
            this.rtcPeerConnection.setRemoteDescription(new RTCSessionDescription(json["msg"])).catch(error => {
                console.log(_translations.kC_xy7jf || (_translations.kC_xy7jf = tr("Failed to apply remote description: %o")), error); //FIXME error handling!
            });
            this._ice_use_cache = false;
            for (let msg of this._ice_cache) {
                this.rtcPeerConnection.addIceCandidate(new RTCIceCandidate(msg)).catch(error => {
                    console.log(_translations.gxaXNyGN || (_translations.gxaXNyGN = tr("Failed to add remote cached ice candidate %s: %o")), msg, error);
                });
            }
        }
        else if (json["request"] === "ice") {
            if (!this._ice_use_cache) {
                console.log(_translations.aRTSL3Lh || (_translations.aRTSL3Lh = tr("Add remote ice! (%s | %o)")), json["msg"], json);
                this.rtcPeerConnection.addIceCandidate(new RTCIceCandidate(json["msg"])).catch(error => {
                    console.log(_translations.rt3O6Uo7 || (_translations.rt3O6Uo7 = tr("Failed to add remote ice candidate %s: %o")), json["msg"], error);
                });
            }
            else {
                console.log(_translations.Q0l9jzUk || (_translations.Q0l9jzUk = tr("Cache remote ice! (%s | %o)")), json["msg"], json);
                this._ice_cache.push(json["msg"]);
            }
        }
        else if (json["request"] == "status") {
            if (json["state"] == "failed") {
                chat.serverChat().appendError(_translations.bV2oK3VW || (_translations.bV2oK3VW = tr("Failed to setup voice bridge ({}). Allow reconnect: {}")), json["reason"], json["allow_reconnect"]);
                log.error(LogCategory.NETWORKING, _translations.PATPjgc1 || (_translations.PATPjgc1 = tr("Failed to setup voice bridge (%s). Allow reconnect: %s")), json["reason"], json["allow_reconnect"]);
                if (json["allow_reconnect"] == true) {
                    this.createSession();
                }
                //TODO handle fail specially when its not allowed to reconnect
            }
        }
    }
    //Listeners
    onIceCandidate(event) {
        console.log(_translations.g37VwgxM || (_translations.g37VwgxM = tr("Got ice candidate! Event:")));
        console.log(event);
        if (event) {
            if (event.candidate)
                this.client.serverConnection.sendData(JSON.stringify({
                    type: 'WebRTC',
                    request: "ice",
                    msg: event.candidate,
                }));
            else {
                this.client.serverConnection.sendData(JSON.stringify({
                    type: 'WebRTC',
                    request: "ice_finish"
                }));
            }
        }
    }
    onOfferCreated(localSession) {
        console.log(_translations.RAYXu4pp || (_translations.RAYXu4pp = tr("Offer created and accepted")));
        this.rtcPeerConnection.setLocalDescription(localSession).catch(error => {
            console.log(_translations.zQF8qDJl || (_translations.zQF8qDJl = tr("Failed to apply local description: %o")), error);
            //FIXME error handling
        });
        console.log(_translations.cBrOv9iU || (_translations.cBrOv9iU = tr("Send offer: %o")), localSession);
        this.client.serverConnection.sendData(JSON.stringify({ type: 'WebRTC', request: "create", msg: localSession }));
    }
    onDataChannelOpen(channel) {
        console.log(_translations.hAUHhp_T || (_translations.hAUHhp_T = tr("Got new data channel! (%s)")), this.dataChannel.readyState);
        this.client.controlBar.updateVoice();
    }
    onDataChannelMessage(message) {
        if (this.client.controlBar.muteOutput)
            return;
        let bin = new Uint8Array(message.data);
        let clientId = bin[2] << 8 | bin[3];
        let packetId = bin[0] << 8 | bin[1];
        let codec = bin[4];
        //console.log("Client id " + clientId + " PacketID " + packetId + " Codec: " + codec);
        let client = this.client.channelTree.findClient(clientId);
        if (!client) {
            console.error(_translations.uFjQb1IJ || (_translations.uFjQb1IJ = tr("Having  voice from unknown client? (ClientID: %o)")), clientId);
            return;
        }
        let codecPool = this.codec_pool[codec];
        if (!codecPool) {
            console.error(_translations.cqDbdgt8 || (_translations.cqDbdgt8 = tr("Could not playback codec %o")), codec);
            return;
        }
        let encodedData;
        if (message.data.subarray)
            encodedData = message.data.subarray(5);
        else
            encodedData = new Uint8Array(message.data, 5);
        if (encodedData.length == 0) {
            client.getAudioController().stopAudio();
            codecPool.releaseCodec(clientId);
        }
        else {
            codecPool.ownCodec(clientId)
                .then(decoder => decoder.decodeSamples(client.getAudioController().codecCache(codec), encodedData))
                .then(buffer => client.getAudioController().playBuffer(buffer)).catch(error => {
                console.error(_translations.eCvCB5hz || (_translations.eCvCB5hz = tr("Could not playback client's (%o) audio (%o)")), clientId, error);
                if (error instanceof Error)
                    console.error(error.stack);
            });
        }
    }
    current_channel_codec() {
        return (this.client.getClient().currentChannel() || { properties: { channel_codec: 4 } }).properties.channel_codec;
    }
    handleVoiceData(data, head) {
        if (!this.voiceRecorder)
            return;
        if (!this.client.connected)
            return false;
        if (this.client.controlBar.muteInput)
            return;
        if (head) {
            this.chunkVPacketId = 0;
            this.client.getClient().speaking = true;
        }
        //TODO Use channel codec!
        const codec = this.current_channel_codec();
        this.codec_pool[codec].ownCodec(this.client.getClientId())
            .then(encoder => encoder.encodeSamples(this.client.getClient().getAudioController().codecCache(codec), data));
    }
    handleVoiceEnded() {
        if (this.client && this.client.getClient())
            this.client.getClient().speaking = false;
        if (!this.voiceRecorder)
            return;
        if (!this.client.connected)
            return;
        console.log(_translations.ZKCR_tr9 || (_translations.ZKCR_tr9 = tr("Local voice ended")));
        if (this.dataChannel)
            this.sendVoicePacket(new Uint8Array(0), this.current_channel_codec()); //TODO Use channel codec!
    }
    handleVoiceStarted() {
        console.log(_translations.MPzgSHpf || (_translations.MPzgSHpf = tr("Local voice started")));
        if (this.client && this.client.getClient())
            this.client.getClient().speaking = true;
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["b1e318eb2775a2f0cc8a6ed8cab1e92661ad334d14656c9b9ca896ca13c6989c"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["b1e318eb2775a2f0cc8a6ed8cab1e92661ad334d14656c9b9ca896ca13c6989c"] = "b1e318eb2775a2f0cc8a6ed8cab1e92661ad334d14656c9b9ca896ca13c6989c";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
$(document).bind("mousedown", function (e) {
    if ($(e.target).parents(".context-menu").length == 0) {
        despawn_context_menu();
    }
});
let contextMenuCloseFn = undefined;
function despawn_context_menu() {
    let menu = $(".context-menu");
    if (!menu.is(":visible"))
        return;
    menu.hide(100);
    if (contextMenuCloseFn)
        contextMenuCloseFn();
}
var MenuEntryType;
(function (MenuEntryType) {
    MenuEntryType[MenuEntryType["CLOSE"] = 0] = "CLOSE";
    MenuEntryType[MenuEntryType["ENTRY"] = 1] = "ENTRY";
    MenuEntryType[MenuEntryType["HR"] = 2] = "HR";
    MenuEntryType[MenuEntryType["SUB_MENU"] = 3] = "SUB_MENU";
})(MenuEntryType || (MenuEntryType = {}));
class MenuEntry {
    static HR() {
        return {
            callback: () => { },
            type: MenuEntryType.HR,
            name: "",
            icon: ""
        };
    }
    ;
    static CLOSE(callback) {
        return {
            callback: callback,
            type: MenuEntryType.CLOSE,
            name: "",
            icon: ""
        };
    }
}
function generate_tag(entry) {
    if (entry.type == MenuEntryType.HR) {
        return $.spawn("hr");
    }
    else if (entry.type == MenuEntryType.ENTRY) {
        console.log(entry.icon);
        let icon = $.isFunction(entry.icon) ? entry.icon() : entry.icon;
        if (typeof (icon) === "string") {
            if (!icon || icon.length == 0)
                icon = "icon_empty";
            else
                icon = "icon " + icon;
        }
        let tag = $.spawn("div").addClass("entry");
        tag.append(typeof (icon) === "string" ? $.spawn("div").addClass(icon) : icon);
        tag.append($.spawn("div").html($.isFunction(entry.name) ? entry.name() : entry.name));
        if (entry.disabled || entry.invalidPermission)
            tag.addClass("disabled");
        else {
            tag.click(function () {
                if ($.isFunction(entry.callback))
                    entry.callback();
                despawn_context_menu();
            });
        }
        return tag;
    }
    else if (entry.type == MenuEntryType.SUB_MENU) {
        let icon = $.isFunction(entry.icon) ? entry.icon() : entry.icon;
        if (typeof (icon) === "string") {
            if (!icon || icon.length == 0)
                icon = "icon_empty";
            else
                icon = "icon " + icon;
        }
        let tag = $.spawn("div").addClass("entry").addClass("sub-container");
        tag.append(typeof (icon) === "string" ? $.spawn("div").addClass(icon) : icon);
        tag.append($.spawn("div").html($.isFunction(entry.name) ? entry.name() : entry.name));
        tag.append($.spawn("div").addClass("arrow right"));
        if (entry.disabled || entry.invalidPermission)
            tag.addClass("disabled");
        else {
            let menu = $.spawn("div").addClass("sub-menu").addClass("context-menu");
            for (let e of entry.sub_menu)
                menu.append(generate_tag(e));
            menu.appendTo(tag);
        }
        return tag;
    }
    return $.spawn("div").text("undefined");
}
function spawn_context_menu(x, y, ...entries) {
    const menu = $("#contextMenu").finish().empty();
    contextMenuCloseFn = undefined;
    for (let entry of entries) {
        if (entry.type == MenuEntryType.CLOSE) {
            contextMenuCloseFn = entry.callback;
        }
        else
            menu.append(generate_tag(entry));
    }
    menu.show(100);
    // In the right position (the mouse)
    menu.css({
        "top": y + "px",
        "left": x + "px"
    });
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["ee7e6f032bc6e9c264f4f802beffd5f41a0007d91d0fe3cbe35a3fdb3bff0b2f"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["ee7e6f032bc6e9c264f4f802beffd5f41a0007d91d0fe3cbe35a3fdb3bff0b2f"] = "ee7e6f032bc6e9c264f4f802beffd5f41a0007d91d0fe3cbe35a3fdb3bff0b2f";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var sha;
(function (sha) {
    /*
     * [js-sha1]{@link https://github.com/emn178/js-sha1}
     *
     * @version 0.6.0
     * @author Chen, Yi-Cyuan [emn178@gmail.com]
     * @copyright Chen, Yi-Cyuan 2014-2017
     * @license MIT
     */
    /*jslint bitwise: true */
    (function () {
        'use strict';
        let root = typeof window === 'object' ? window : {};
        let NODE_JS = !root.JS_SHA1_NO_NODE_JS && typeof process === 'object' && process.versions && process.versions.node;
        if (NODE_JS) {
            root = global;
        }
        let COMMON_JS = !root.JS_SHA1_NO_COMMON_JS && typeof module === 'object' && module.exports;
        let AMD = typeof define === 'function' && define.amd;
        let HEX_CHARS = '0123456789abcdef'.split('');
        let EXTRA = [-2147483648, 8388608, 32768, 128];
        let SHIFT = [24, 16, 8, 0];
        let OUTPUT_TYPES = ['hex', 'array', 'digest', 'arrayBuffer'];
        let blocks = [];
        let createOutputMethod = function (outputType) {
            return function (message) {
                return new Sha1(true).update(message)[outputType]();
            };
        };
        let createMethod = function () {
            let method = createOutputMethod('hex');
            if (NODE_JS) {
                method = nodeWrap(method);
            }
            method.create = function () {
                return new Sha1();
            };
            method.update = function (message) {
                return method.create().update(message);
            };
            for (var i = 0; i < OUTPUT_TYPES.length; ++i) {
                var type = OUTPUT_TYPES[i];
                method[type] = createOutputMethod(type);
            }
            return method;
        };
        var nodeWrap = function (method) {
            var crypto = eval("require('crypto')");
            var Buffer = eval("require('buffer').Buffer");
            var nodeMethod = function (message) {
                if (typeof message === 'string') {
                    return crypto.createHash('sha1').update(message, 'utf8').digest('hex');
                }
                else if (message.constructor === ArrayBuffer) {
                    message = new Uint8Array(message);
                }
                else if (message.length === undefined) {
                    return method(message);
                }
                return crypto.createHash('sha1').update(new Buffer(message)).digest('hex');
            };
            return nodeMethod;
        };
        function Sha1(sharedMemory) {
            if (sharedMemory) {
                blocks[0] = blocks[16] = blocks[1] = blocks[2] = blocks[3] =
                    blocks[4] = blocks[5] = blocks[6] = blocks[7] =
                        blocks[8] = blocks[9] = blocks[10] = blocks[11] =
                            blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
                this.blocks = blocks;
            }
            else {
                this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            }
            this.h0 = 0x67452301;
            this.h1 = 0xEFCDAB89;
            this.h2 = 0x98BADCFE;
            this.h3 = 0x10325476;
            this.h4 = 0xC3D2E1F0;
            this.block = this.start = this.bytes = this.hBytes = 0;
            this.finalized = this.hashed = false;
            this.first = true;
        }
        Sha1.prototype.update = function (message) {
            if (this.finalized) {
                return;
            }
            var notString = typeof (message) !== 'string';
            if (notString && message.constructor === root.ArrayBuffer) {
                message = new Uint8Array(message);
            }
            var code, index = 0, i, length = message.length || 0, blocks = this.blocks;
            while (index < length) {
                if (this.hashed) {
                    this.hashed = false;
                    blocks[0] = this.block;
                    blocks[16] = blocks[1] = blocks[2] = blocks[3] =
                        blocks[4] = blocks[5] = blocks[6] = blocks[7] =
                            blocks[8] = blocks[9] = blocks[10] = blocks[11] =
                                blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
                }
                if (notString) {
                    for (i = this.start; index < length && i < 64; ++index) {
                        blocks[i >> 2] |= message[index] << SHIFT[i++ & 3];
                    }
                }
                else {
                    for (i = this.start; index < length && i < 64; ++index) {
                        code = message.charCodeAt(index);
                        if (code < 0x80) {
                            blocks[i >> 2] |= code << SHIFT[i++ & 3];
                        }
                        else if (code < 0x800) {
                            blocks[i >> 2] |= (0xc0 | (code >> 6)) << SHIFT[i++ & 3];
                            blocks[i >> 2] |= (0x80 | (code & 0x3f)) << SHIFT[i++ & 3];
                        }
                        else if (code < 0xd800 || code >= 0xe000) {
                            blocks[i >> 2] |= (0xe0 | (code >> 12)) << SHIFT[i++ & 3];
                            blocks[i >> 2] |= (0x80 | ((code >> 6) & 0x3f)) << SHIFT[i++ & 3];
                            blocks[i >> 2] |= (0x80 | (code & 0x3f)) << SHIFT[i++ & 3];
                        }
                        else {
                            code = 0x10000 + (((code & 0x3ff) << 10) | (message.charCodeAt(++index) & 0x3ff));
                            blocks[i >> 2] |= (0xf0 | (code >> 18)) << SHIFT[i++ & 3];
                            blocks[i >> 2] |= (0x80 | ((code >> 12) & 0x3f)) << SHIFT[i++ & 3];
                            blocks[i >> 2] |= (0x80 | ((code >> 6) & 0x3f)) << SHIFT[i++ & 3];
                            blocks[i >> 2] |= (0x80 | (code & 0x3f)) << SHIFT[i++ & 3];
                        }
                    }
                }
                this.lastByteIndex = i;
                this.bytes += i - this.start;
                if (i >= 64) {
                    this.block = blocks[16];
                    this.start = i - 64;
                    this.hash();
                    this.hashed = true;
                }
                else {
                    this.start = i;
                }
            }
            if (this.bytes > 4294967295) {
                this.hBytes += this.bytes / 4294967296 << 0;
                this.bytes = this.bytes % 4294967296;
            }
            return this;
        };
        Sha1.prototype.finalize = function () {
            if (this.finalized) {
                return;
            }
            this.finalized = true;
            var blocks = this.blocks, i = this.lastByteIndex;
            blocks[16] = this.block;
            blocks[i >> 2] |= EXTRA[i & 3];
            this.block = blocks[16];
            if (i >= 56) {
                if (!this.hashed) {
                    this.hash();
                }
                blocks[0] = this.block;
                blocks[16] = blocks[1] = blocks[2] = blocks[3] =
                    blocks[4] = blocks[5] = blocks[6] = blocks[7] =
                        blocks[8] = blocks[9] = blocks[10] = blocks[11] =
                            blocks[12] = blocks[13] = blocks[14] = blocks[15] = 0;
            }
            blocks[14] = this.hBytes << 3 | this.bytes >>> 29;
            blocks[15] = this.bytes << 3;
            this.hash();
        };
        Sha1.prototype.hash = function () {
            var a = this.h0, b = this.h1, c = this.h2, d = this.h3, e = this.h4;
            var f, j, t, blocks = this.blocks;
            for (j = 16; j < 80; ++j) {
                t = blocks[j - 3] ^ blocks[j - 8] ^ blocks[j - 14] ^ blocks[j - 16];
                blocks[j] = (t << 1) | (t >>> 31);
            }
            for (j = 0; j < 20; j += 5) {
                f = (b & c) | ((~b) & d);
                t = (a << 5) | (a >>> 27);
                e = t + f + e + 1518500249 + blocks[j] << 0;
                b = (b << 30) | (b >>> 2);
                f = (a & b) | ((~a) & c);
                t = (e << 5) | (e >>> 27);
                d = t + f + d + 1518500249 + blocks[j + 1] << 0;
                a = (a << 30) | (a >>> 2);
                f = (e & a) | ((~e) & b);
                t = (d << 5) | (d >>> 27);
                c = t + f + c + 1518500249 + blocks[j + 2] << 0;
                e = (e << 30) | (e >>> 2);
                f = (d & e) | ((~d) & a);
                t = (c << 5) | (c >>> 27);
                b = t + f + b + 1518500249 + blocks[j + 3] << 0;
                d = (d << 30) | (d >>> 2);
                f = (c & d) | ((~c) & e);
                t = (b << 5) | (b >>> 27);
                a = t + f + a + 1518500249 + blocks[j + 4] << 0;
                c = (c << 30) | (c >>> 2);
            }
            for (; j < 40; j += 5) {
                f = b ^ c ^ d;
                t = (a << 5) | (a >>> 27);
                e = t + f + e + 1859775393 + blocks[j] << 0;
                b = (b << 30) | (b >>> 2);
                f = a ^ b ^ c;
                t = (e << 5) | (e >>> 27);
                d = t + f + d + 1859775393 + blocks[j + 1] << 0;
                a = (a << 30) | (a >>> 2);
                f = e ^ a ^ b;
                t = (d << 5) | (d >>> 27);
                c = t + f + c + 1859775393 + blocks[j + 2] << 0;
                e = (e << 30) | (e >>> 2);
                f = d ^ e ^ a;
                t = (c << 5) | (c >>> 27);
                b = t + f + b + 1859775393 + blocks[j + 3] << 0;
                d = (d << 30) | (d >>> 2);
                f = c ^ d ^ e;
                t = (b << 5) | (b >>> 27);
                a = t + f + a + 1859775393 + blocks[j + 4] << 0;
                c = (c << 30) | (c >>> 2);
            }
            for (; j < 60; j += 5) {
                f = (b & c) | (b & d) | (c & d);
                t = (a << 5) | (a >>> 27);
                e = t + f + e - 1894007588 + blocks[j] << 0;
                b = (b << 30) | (b >>> 2);
                f = (a & b) | (a & c) | (b & c);
                t = (e << 5) | (e >>> 27);
                d = t + f + d - 1894007588 + blocks[j + 1] << 0;
                a = (a << 30) | (a >>> 2);
                f = (e & a) | (e & b) | (a & b);
                t = (d << 5) | (d >>> 27);
                c = t + f + c - 1894007588 + blocks[j + 2] << 0;
                e = (e << 30) | (e >>> 2);
                f = (d & e) | (d & a) | (e & a);
                t = (c << 5) | (c >>> 27);
                b = t + f + b - 1894007588 + blocks[j + 3] << 0;
                d = (d << 30) | (d >>> 2);
                f = (c & d) | (c & e) | (d & e);
                t = (b << 5) | (b >>> 27);
                a = t + f + a - 1894007588 + blocks[j + 4] << 0;
                c = (c << 30) | (c >>> 2);
            }
            for (; j < 80; j += 5) {
                f = b ^ c ^ d;
                t = (a << 5) | (a >>> 27);
                e = t + f + e - 899497514 + blocks[j] << 0;
                b = (b << 30) | (b >>> 2);
                f = a ^ b ^ c;
                t = (e << 5) | (e >>> 27);
                d = t + f + d - 899497514 + blocks[j + 1] << 0;
                a = (a << 30) | (a >>> 2);
                f = e ^ a ^ b;
                t = (d << 5) | (d >>> 27);
                c = t + f + c - 899497514 + blocks[j + 2] << 0;
                e = (e << 30) | (e >>> 2);
                f = d ^ e ^ a;
                t = (c << 5) | (c >>> 27);
                b = t + f + b - 899497514 + blocks[j + 3] << 0;
                d = (d << 30) | (d >>> 2);
                f = c ^ d ^ e;
                t = (b << 5) | (b >>> 27);
                a = t + f + a - 899497514 + blocks[j + 4] << 0;
                c = (c << 30) | (c >>> 2);
            }
            this.h0 = this.h0 + a << 0;
            this.h1 = this.h1 + b << 0;
            this.h2 = this.h2 + c << 0;
            this.h3 = this.h3 + d << 0;
            this.h4 = this.h4 + e << 0;
        };
        Sha1.prototype.hex = function () {
            this.finalize();
            var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
            return HEX_CHARS[(h0 >> 28) & 0x0F] + HEX_CHARS[(h0 >> 24) & 0x0F] +
                HEX_CHARS[(h0 >> 20) & 0x0F] + HEX_CHARS[(h0 >> 16) & 0x0F] +
                HEX_CHARS[(h0 >> 12) & 0x0F] + HEX_CHARS[(h0 >> 8) & 0x0F] +
                HEX_CHARS[(h0 >> 4) & 0x0F] + HEX_CHARS[h0 & 0x0F] +
                HEX_CHARS[(h1 >> 28) & 0x0F] + HEX_CHARS[(h1 >> 24) & 0x0F] +
                HEX_CHARS[(h1 >> 20) & 0x0F] + HEX_CHARS[(h1 >> 16) & 0x0F] +
                HEX_CHARS[(h1 >> 12) & 0x0F] + HEX_CHARS[(h1 >> 8) & 0x0F] +
                HEX_CHARS[(h1 >> 4) & 0x0F] + HEX_CHARS[h1 & 0x0F] +
                HEX_CHARS[(h2 >> 28) & 0x0F] + HEX_CHARS[(h2 >> 24) & 0x0F] +
                HEX_CHARS[(h2 >> 20) & 0x0F] + HEX_CHARS[(h2 >> 16) & 0x0F] +
                HEX_CHARS[(h2 >> 12) & 0x0F] + HEX_CHARS[(h2 >> 8) & 0x0F] +
                HEX_CHARS[(h2 >> 4) & 0x0F] + HEX_CHARS[h2 & 0x0F] +
                HEX_CHARS[(h3 >> 28) & 0x0F] + HEX_CHARS[(h3 >> 24) & 0x0F] +
                HEX_CHARS[(h3 >> 20) & 0x0F] + HEX_CHARS[(h3 >> 16) & 0x0F] +
                HEX_CHARS[(h3 >> 12) & 0x0F] + HEX_CHARS[(h3 >> 8) & 0x0F] +
                HEX_CHARS[(h3 >> 4) & 0x0F] + HEX_CHARS[h3 & 0x0F] +
                HEX_CHARS[(h4 >> 28) & 0x0F] + HEX_CHARS[(h4 >> 24) & 0x0F] +
                HEX_CHARS[(h4 >> 20) & 0x0F] + HEX_CHARS[(h4 >> 16) & 0x0F] +
                HEX_CHARS[(h4 >> 12) & 0x0F] + HEX_CHARS[(h4 >> 8) & 0x0F] +
                HEX_CHARS[(h4 >> 4) & 0x0F] + HEX_CHARS[h4 & 0x0F];
        };
        Sha1.prototype.toString = Sha1.prototype.hex;
        Sha1.prototype.digest = function () {
            this.finalize();
            var h0 = this.h0, h1 = this.h1, h2 = this.h2, h3 = this.h3, h4 = this.h4;
            return [
                (h0 >> 24) & 0xFF, (h0 >> 16) & 0xFF, (h0 >> 8) & 0xFF, h0 & 0xFF,
                (h1 >> 24) & 0xFF, (h1 >> 16) & 0xFF, (h1 >> 8) & 0xFF, h1 & 0xFF,
                (h2 >> 24) & 0xFF, (h2 >> 16) & 0xFF, (h2 >> 8) & 0xFF, h2 & 0xFF,
                (h3 >> 24) & 0xFF, (h3 >> 16) & 0xFF, (h3 >> 8) & 0xFF, h3 & 0xFF,
                (h4 >> 24) & 0xFF, (h4 >> 16) & 0xFF, (h4 >> 8) & 0xFF, h4 & 0xFF
            ];
        };
        Sha1.prototype.array = Sha1.prototype.digest;
        Sha1.prototype.arrayBuffer = function () {
            this.finalize();
            var buffer = new ArrayBuffer(20);
            var dataView = new DataView(buffer);
            dataView.setUint32(0, this.h0);
            dataView.setUint32(4, this.h1);
            dataView.setUint32(8, this.h2);
            dataView.setUint32(12, this.h3);
            dataView.setUint32(16, this.h4);
            return buffer;
        };
        var exports = createMethod();
        if (COMMON_JS) {
            module.exports = exports;
        }
        else {
            root._sha1 = exports;
            if (AMD) {
                define(function () {
                    return exports;
                });
            }
        }
    })();
    function encode_text(buffer) {
        if (window.TextEncoder) {
            return new TextEncoder().encode(buffer).buffer;
        }
        let utf8 = unescape(encodeURIComponent(buffer));
        let result = new Uint8Array(utf8.length);
        for (let i = 0; i < utf8.length; i++) {
            result[i] = utf8.charCodeAt(i);
        }
        return result.buffer;
    }
    sha.encode_text = encode_text;
    function sha1(message) {
        let buffer = message instanceof ArrayBuffer ? message : encode_text(message);
        if (!crypto || !crypto.subtle || !crypto.subtle.digest || /Edge/.test(navigator.userAgent))
            return new Promise(resolve => {
                resolve(_sha1.arrayBuffer(buffer));
            });
        else
            return crypto.subtle.digest("SHA-1", buffer);
    }
    sha.sha1 = sha1;
})(sha || (sha = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["312d6e784002dab732e606549c0b3d72bd8fb28cf8b3bf876c66287cc393b4c6"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["312d6e784002dab732e606549c0b3d72bd8fb28cf8b3bf876c66287cc393b4c6"] = "312d6e784002dab732e606549c0b3d72bd8fb28cf8b3bf876c66287cc393b4c6";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../crypto/sha.ts" />
var helpers;
(function (helpers) {
    function hashPassword(password) {
        return new Promise((resolve, reject) => {
            sha.sha1(password).then(result => {
                resolve(btoa(String.fromCharCode.apply(null, new Uint8Array(result))));
            });
        });
    }
    helpers.hashPassword = hashPassword;
})(helpers || (helpers = {}));
class LaterPromise extends Promise {
    constructor() {
        super((resolve, reject) => { });
        this._handle = new Promise((resolve, reject) => {
            this._resolve = resolve;
            this._reject = reject;
        });
        this._time = Date.now();
    }
    resolved(object) {
        this._resolve(object);
    }
    rejected(reason) {
        this._reject(reason);
    }
    function_rejected() {
        return error => this.rejected(error);
    }
    time() { return this._time; }
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then(onfulfilled, onrejected) {
        return this._handle.then(onfulfilled, onrejected);
    }
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch(onrejected) {
        return this._handle.then(onrejected);
    }
}
const copy_to_clipboard = str => {
    const el = document.createElement('textarea');
    el.value = str;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    const selected = document.getSelection().rangeCount > 0
        ? document.getSelection().getRangeAt(0)
        : false;
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    if (selected) {
        document.getSelection().removeAllRanges();
        document.getSelection().addRange(selected);
    }
};
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["f6b5f1f50a103b8b21b836f19caa3ecc399b657080d45cf39085e2b49a85f021"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["f6b5f1f50a103b8b21b836f19caa3ecc399b657080d45cf39085e2b49a85f021"] = "f6b5f1f50a103b8b21b836f19caa3ecc399b657080d45cf39085e2b49a85f021";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "xXwsShJh", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (382,23)" }, { name: "uGtVyDSK", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (389,23)" }, { name: "VFrecPBb", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (396,59)" }, { name: "DaenAS9w", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (421,23)" }, { name: "vvpUmPxf", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (433,23)" }, { name: "ccz2ob3Z", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (436,41)" }, { name: "E07z9Q9k", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (436,73)" }, { name: "IQjOVT4E", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (443,42)" }, { name: "k_5gZi6p", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (451,23)" }, { name: "MaMcbjYA", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (457,23)" }, { name: "seHhseZ7", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (480,25)" }, { name: "UKIyCjAj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (489,25)" }, { name: "_TvJoAqS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (512,67)" }, { name: "XvvHZqlT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (519,21)" }, { name: "RZmF8gxm", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (523,71)" }, { name: "HvTmx9HI", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (530,23)" }, { name: "LEv8556x", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (618,30)" }, { name: "YNwzVGiN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/channel.ts (618,54)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="view.ts" />
/// <reference path="../utils/helpers.ts" />
var ChannelType;
(function (ChannelType) {
    ChannelType[ChannelType["PERMANENT"] = 0] = "PERMANENT";
    ChannelType[ChannelType["SEMI_PERMANENT"] = 1] = "SEMI_PERMANENT";
    ChannelType[ChannelType["TEMPORARY"] = 2] = "TEMPORARY";
})(ChannelType || (ChannelType = {}));
(function (ChannelType) {
    function normalize(mode) {
        let value = ChannelType[mode];
        value = value.toLowerCase();
        return value[0].toUpperCase() + value.substr(1);
    }
    ChannelType.normalize = normalize;
})(ChannelType || (ChannelType = {}));
class ChannelProperties {
    constructor() {
        this.channel_order = 0;
        this.channel_name = "";
        this.channel_name_phonetic = "";
        this.channel_topic = "";
        this.channel_password = "";
        this.channel_codec = 4;
        this.channel_codec_quality = 0;
        this.channel_codec_is_unencrypted = false;
        this.channel_maxclients = -1;
        this.channel_maxfamilyclients = -1;
        this.channel_needed_talk_power = 1;
        this.channel_flag_permanent = false;
        this.channel_flag_semi_permanent = false;
        this.channel_flag_default = false;
        this.channel_flag_password = false;
        this.channel_flag_maxclients_unlimited = false;
        this.channel_flag_maxfamilyclients_inherited = false;
        this.channel_flag_maxfamilyclients_unlimited = false;
        this.channel_icon_id = 0;
        this.channel_delete_delay = 0;
        //Only after request
        this.channel_description = "";
    }
}
class ChannelEntry {
    constructor(channelId, channelName, parent = null) {
        this.properties = new ChannelProperties();
        this._family_index = 0;
        this._cached_channel_description = undefined;
        this._cached_channel_description_promise = undefined;
        this._cached_channel_description_promise_resolve = undefined;
        this._cached_channel_description_promise_reject = undefined;
        this.properties = new ChannelProperties();
        this.channelId = channelId;
        this._formatedChannelName = channelName;
        this.parent = parent;
        this.channelTree = null;
        this.initializeTag();
        this.__updateChannelName();
    }
    channelName() {
        return this.properties.channel_name;
    }
    formatedChannelName() {
        return this._formatedChannelName !== undefined ? this._formatedChannelName : this.properties.channel_name;
    }
    getChannelDescription() {
        if (this._cached_channel_description)
            return new Promise(resolve => resolve(this._cached_channel_description));
        if (this._cached_channel_description_promise)
            return this._cached_channel_description_promise;
        this.channelTree.client.serverConnection.sendCommand("channelgetdescription", { cid: this.channelId }).catch(error => {
            this._cached_channel_description_promise_reject(error);
        });
        return this._cached_channel_description_promise = new Promise((resolve, reject) => {
            this._cached_channel_description_promise_resolve = resolve;
            this._cached_channel_description_promise_reject = reject;
        });
    }
    parent_channel() { return this.parent; }
    hasParent() { return this.parent != null; }
    getChannelId() { return this.channelId; }
    channelClass() { return "channel_full"; }
    siblings(deep = false) {
        const result = [];
        if (this.channelTree == null)
            return [];
        const self = this;
        this.channelTree.channels.forEach(function (entry) {
            let current = entry;
            if (deep) {
                while (current) {
                    if (current.parent_channel() == self) {
                        result.push(entry);
                        break;
                    }
                    current = current.parent_channel();
                }
            }
            else if (current.parent_channel() == self)
                result.push(entry);
        });
        return result;
    }
    clients(deep = false) {
        const result = [];
        if (this.channelTree == null)
            return [];
        const self = this;
        this.channelTree.clients.forEach(function (entry) {
            let current = entry.currentChannel();
            if (deep) {
                while (current) {
                    if (current.parent_channel() == self) {
                        result.push(entry);
                        break;
                    }
                    current = current.parent_channel();
                }
            }
            else if (current == self)
                result.push(entry);
        });
        return result;
    }
    clients_ordered() {
        const clients = this.clients(false);
        clients.sort((a, b) => {
            if (a.properties.client_talk_power < b.properties.client_talk_power)
                return 1;
            if (a.properties.client_talk_power > b.properties.client_talk_power)
                return -1;
            if (a.properties.client_nickname > b.properties.client_nickname)
                return 1;
            if (a.properties.client_nickname < b.properties.client_nickname)
                return -1;
            return 0;
        });
        return clients;
    }
    initializeTag() {
        let rootTag = $.spawn("div");
        rootTag.attr("id", "channel_" + this.getChannelId());
        rootTag.addClass("channel");
        //rootTag.append($.spawn("div").addClass("icon_empty"));
        //Tag channel
        this._tag_channel = $.spawn("div");
        this._tag_channel.attr('channel-id', this.channelId);
        this._tag_channel.addClass("channelLine");
        this._tag_channel.addClass(this._channelAlign); //For left
        this._tag_channel.css('z-index', this._family_index);
        let channelType = $.spawn("div");
        channelType.addClass("channel_only_normal channel_type icon client-channel_green_subscribed");
        this._tag_channel.append(channelType);
        this._tag_channel.append($.spawn("div").addClass("channel_name_container").append($.spawn("a").addClass("channel_name").text(this.channelName())));
        //Icons
        let iconTag = $.spawn("span").addClass("icons");
        iconTag.appendTo(this._tag_channel);
        //Default icon (5)
        iconTag.append($.spawn("div").addClass("channel_only_normal").append($.spawn("div").addClass("icon_entry icon_default icon client-channel_default").attr("title", "Default channel")));
        //Password icon (4)
        iconTag.append($.spawn("div").addClass("channel_only_normal").append($.spawn("div").addClass("icon_entry icon_password icon client-register").attr("title", "The channel is password protected")));
        //Music icon (3)
        iconTag.append($.spawn("div").addClass("channel_only_normal").append($.spawn("div").addClass("icon_entry icon_music icon client-music").attr("title", "Music quality")));
        //Channel moderated (2)
        iconTag.append($.spawn("div").addClass("channel_only_normal").append($.spawn("div").addClass("icon_entry icon_moderated icon client-moderated").attr("title", "Channel is moderated")));
        //Channel Icon (1)
        //iconTag.append($.spawn("div").addClass("channel_only_normal").addClass("icon_entry channel_icon").attr("title", "Channel icon"));
        iconTag.append($.spawn("div").addClass("channel_only_normal").append($.spawn("div").addClass("icon_entry channel_icon").attr("title", "Channel icon")));
        //Default no sound (0)
        let container = $.spawn("div");
        let noSound = $.spawn("div").addClass("icon_entry icon_no_sound icon client-conflict-icon").attr("title", "You don't support the channel codec");
        let bg = $.spawn("div")
            .width(10)
            .height(14)
            .css("background", "red")
            .css("position", "absolute")
            .css("top", "1px")
            .css("left", "3px");
        bg.appendTo(container);
        noSound.appendTo(container);
        iconTag.append(container);
        /*
        setInterval(() => {
            let color = (Math.random() * 10000000).toString(16).substr(0, 6);
            bg.css("background", "#" + color);
        }, 150);
        */
        //Build siblings
        this._tag_siblings = $.spawn("div").addClass("siblings");
        let tag_siblings_box = $.spawn("div").css("position", "absolute").css("width", "calc(100% - 16px)").css("margin", "0px");
        this._tag_siblings.appendTo(tag_siblings_box);
        //Build clients
        this._tag_clients = $.spawn("div").addClass("clients");
        let tag_clients_box = $.spawn("div").css("position", "absolute").css("width", "calc(100% - 16px)").css("margin", "0px");
        this._tag_clients.appendTo(tag_clients_box);
        this._tag_root = rootTag;
        tag_clients_box.appendTo(this._tag_root);
        tag_siblings_box.appendTo(this._tag_root);
        this._tag_channel.appendTo(this._tag_root);
    }
    rootTag() {
        return this._tag_root;
    }
    channelTag() {
        return this._tag_channel;
    }
    siblingTag() {
        return this._tag_siblings;
    }
    clientTag() {
        return this._tag_clients;
    }
    reorderClients() {
        let clients = this.clients();
        if (clients.length > 1) {
            clients.sort((a, b) => {
                if (a.properties.client_talk_power < b.properties.client_talk_power)
                    return 1;
                if (a.properties.client_talk_power > b.properties.client_talk_power)
                    return -1;
                if (a.properties.client_nickname > b.properties.client_nickname)
                    return 1;
                if (a.properties.client_nickname < b.properties.client_nickname)
                    return -1;
                return 0;
            });
            clients.reverse();
            for (let index = 0; index + 1 < clients.length; index++)
                clients[index].tag.before(clients[index + 1].tag);
            for (let client of clients) {
                console.log("- %i %s", client.properties.client_talk_power, client.properties.client_nickname);
            }
        }
    }
    adjustSize(parent = true) {
        const size = this.originalHeight;
        let subSize = 0;
        let clientSize = 0;
        const sub = this.siblings(false);
        sub.forEach(function (e) {
            if (e.rootTag().is(":visible"))
                subSize += e.rootTag().outerHeight(true);
        });
        const clients = this.clients(false);
        clients.forEach(function (e) {
            if (e.tag.is(":visible"))
                clientSize += e.tag.outerHeight(true);
        });
        this._tag_root.css({ height: size + subSize + clientSize });
        this._tag_siblings.css("margin-top", (clientSize + 16) + "px");
        this._tag_clients.css({ height: clientSize });
        if (parent && this.parent_channel())
            this.parent_channel().adjustSize(parent);
    }
    initializeListener() {
        const _this = this;
        this.channelTag().click(function () {
            _this.channelTree.onSelect(_this);
        });
        this.channelTag().dblclick(() => {
            if ($.isArray(this.channelTree.currently_selected)) { //Multiselect
                return;
            }
            this.joinChannel();
        });
        if (!settings.static(Settings.KEY_DISABLE_CONTEXT_MENU, false)) {
            this.channelTag().on("contextmenu", (event) => {
                event.preventDefault();
                if ($.isArray(this.channelTree.currently_selected)) { //Multiselect
                    (this.channelTree.currently_selected_context_callback || ((_) => null))(event);
                    return;
                }
                _this.channelTree.onSelect(_this, true);
                _this.showContextMenu(event.pageX, event.pageY, () => {
                    _this.channelTree.onSelect(undefined, true);
                });
            });
        }
    }
    showContextMenu(x, y, on_close = undefined) {
        let channelCreate = this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_TEMPORARY).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_SEMI_PERMANENT).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_PERMANENT).granted(1);
        let channelModify = this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_MAKE_DEFAULT).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_MAKE_PERMANENT).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_MAKE_SEMI_PERMANENT).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_MAKE_TEMPORARY).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_NAME).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_TOPIC).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_DESCRIPTION).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_PASSWORD).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_CODEC).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_CODEC_QUALITY).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_CODEC_LATENCY_FACTOR).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_MAXCLIENTS).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_MAXFAMILYCLIENTS).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_SORTORDER).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_NEEDED_TALK_POWER).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_MAKE_CODEC_ENCRYPTED).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_TEMP_DELETE_DELAY).granted(1) ||
            this.channelTree.client.permissions.neededPermission(PermissionType.B_ICON_MANAGE).granted(1);
        let flagDelete = true;
        if (this.clients(true).length > 0)
            flagDelete = this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_DELETE_FLAG_FORCE).granted(1);
        if (flagDelete) {
            if (this.properties.channel_flag_permanent)
                flagDelete = this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_DELETE_PERMANENT).granted(1);
            else if (this.properties.channel_flag_semi_permanent)
                flagDelete = this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_DELETE_PERMANENT).granted(1);
            else
                flagDelete = this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_DELETE_TEMPORARY).granted(1);
        }
        spawn_context_menu(x, y, {
            type: MenuEntryType.ENTRY,
            icon: "client-channel_switch",
            name: _translations.xXwsShJh || (_translations.xXwsShJh = tr("<b>Switch to channel</b>")),
            callback: () => this.joinChannel()
        }, MenuEntry.HR(), {
            type: MenuEntryType.ENTRY,
            icon: "client-channel_edit",
            name: _translations.uGtVyDSK || (_translations.uGtVyDSK = tr("Edit channel")),
            invalidPermission: !channelModify,
            callback: () => {
                Modals.createChannelModal(this, undefined, this.channelTree.client.permissions, (changes, permissions) => {
                    if (changes) {
                        changes["cid"] = this.channelId;
                        this.channelTree.client.serverConnection.sendCommand("channeledit", changes);
                        log.info(LogCategory.CHANNEL, _translations.VFrecPBb || (_translations.VFrecPBb = tr("Changed channel properties of channel %s: %o")), this.channelName(), changes);
                    }
                    if (permissions && permissions.length > 0) {
                        let perms = [];
                        for (let perm of permissions) {
                            perms.push({
                                permvalue: perm.value,
                                permnegated: false,
                                permskip: false,
                                permid: perm.type.id
                            });
                        }
                        perms[0]["cid"] = this.channelId;
                        this.channelTree.client.serverConnection.sendCommand("channeladdperm", perms, ["continueonerror"]).then(() => {
                            sound.play(Sound.CHANNEL_EDITED_SELF);
                        });
                    }
                });
            }
        }, {
            type: MenuEntryType.ENTRY,
            icon: "client-channel_delete",
            name: _translations.DaenAS9w || (_translations.DaenAS9w = tr("Delete channel")),
            invalidPermission: !flagDelete,
            callback: () => {
                this.channelTree.client.serverConnection.sendCommand("channeldelete", { cid: this.channelId }).then(() => {
                    sound.play(Sound.CHANNEL_DELETED);
                });
            }
        }, MenuEntry.HR(), {
            type: MenuEntryType.ENTRY,
            icon: "client-addon-collection",
            name: _translations.vvpUmPxf || (_translations.vvpUmPxf = tr("Create music bot")),
            callback: () => {
                this.channelTree.client.serverConnection.sendCommand("musicbotcreate", { cid: this.channelId }).then(() => {
                    createInfoModal(_translations.ccz2ob3Z || (_translations.ccz2ob3Z = tr("Bot successfully created")), _translations.E07z9Q9k || (_translations.E07z9Q9k = tr("But has been successfully created."))).open();
                }).catch(error => {
                    if (error instanceof CommandResult) {
                        error = error.extra_message || error.message;
                    }
                    //TODO tr
                    createErrorModal(_translations.IQjOVT4E || (_translations.IQjOVT4E = tr("Failed to create bot")), "Failed to create the music bot:<br>" + error).open();
                });
            }
        }, MenuEntry.HR(), {
            type: MenuEntryType.ENTRY,
            icon: "client-channel_create_sub",
            name: _translations.k_5gZi6p || (_translations.k_5gZi6p = tr("Create sub channel")),
            invalidPermission: !(channelCreate && this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_CHILD).granted(1)),
            callback: () => this.channelTree.spawnCreateChannel(this)
        }, {
            type: MenuEntryType.ENTRY,
            icon: "client-channel_create",
            name: _translations.MaMcbjYA || (_translations.MaMcbjYA = tr("Create channel")),
            invalidPermission: !channelCreate,
            callback: () => this.channelTree.spawnCreateChannel()
        }, MenuEntry.CLOSE(on_close));
    }
    handle_frame_resized() {
        this.__updateChannelName();
    }
    __updateChannelName() {
        this._formatedChannelName = undefined;
        parseType: if (this.parent_channel() == null && this.properties.channel_name.charAt(0) == '[') {
            let end = this.properties.channel_name.indexOf(']');
            if (end == -1)
                break parseType;
            let options = this.properties.channel_name.substr(1, end - 1);
            if (options.indexOf("spacer") == -1)
                break parseType;
            options = options.substr(0, options.indexOf("spacer"));
            console.log(_translations.seHhseZ7 || (_translations.seHhseZ7 = tr("Channel options: '%o'")), options);
            if (options.length == 0)
                options = "l";
            else if (options.length > 1)
                options = options[0];
            if (options == "r" || options == "l" || options == "c" || options == "*")
                this._channelAlign = options;
            else
                break parseType;
            this._formatedChannelName = this.properties.channel_name.substr(end + 1);
            console.log(_translations.UKIyCjAj || (_translations.UKIyCjAj = tr("Got channel name: %o")), this._formatedChannelName);
        }
        let self = this.channelTag();
        let channelName = self.find(".channel_name");
        channelName.text(this.formatedChannelName());
        channelName.parent().removeClass("l r c *"); //Alignments
        (this._formatedChannelName !== undefined ? $.fn.hide : $.fn.show).apply(self.find(".channel_only_normal"));
        if (this._formatedChannelName !== undefined) {
            channelName.parent().addClass(this._channelAlign);
            if (this._channelAlign == "*") {
                let lastSuccess = "";
                let index = 6;
                let name = this.formatedChannelName();
                while (index-- > 0)
                    name = name + name;
                channelName.text(name);
                do {
                    channelName.text(name = name + name);
                } while (channelName.parent().width() >= channelName.width() && ++index < 64);
                if (index == 64)
                    console.warn(LogCategory.CHANNEL, _translations._TvJoAqS || (_translations._TvJoAqS = tr("Repeating spacer took too much repeats!")));
                if (lastSuccess.length > 0) {
                    channelName.text(lastSuccess);
                    self.addClass("c");
                }
            }
        }
        console.log(_translations.XvvHZqlT || (_translations.XvvHZqlT = tr("Align: %s")), this._channelAlign);
    }
    updateVariables(...variables) {
        let group = log.group(log.LogType.DEBUG, LogCategory.CHANNEL, _translations.RZmF8gxm || (_translations.RZmF8gxm = tr("Update properties (%i) of %s (%i)")), variables.length, this.channelName(), this.getChannelId());
        for (let variable of variables) {
            let key = variable.key;
            let value = variable.value;
            JSON.map_field_to(this.properties, value, variable.key);
            group.log(_translations.HvTmx9HI || (_translations.HvTmx9HI = tr("Updating property %s = '%s' -> %o")), key, value, this.properties[key]);
            if (key == "channel_name") {
                this.__updateChannelName();
            }
            else if (key == "channel_order") {
                let order = this.channelTree.findChannel(this.properties.channel_order);
                this.channelTree.moveChannel(this, order, this.parent);
            }
            else if (key == "channel_icon_id") {
                let tag = this.channelTag().find(".icons .channel_icon");
                (this.properties.channel_icon_id > 0 ? $.fn.show : $.fn.hide).apply(tag);
                if (this.properties.channel_icon_id > 0) {
                    tag.children().detach();
                    this.channelTree.client.fileManager.icons.generateTag(this.properties.channel_icon_id).appendTo(tag);
                }
            }
            else if (key == "channel_codec") {
                (this.properties.channel_codec == 5 || this.properties.channel_codec == 3 ? $.fn.show : $.fn.hide).apply(this.channelTag().find(".icons .icon_music"));
                (this.channelTree.client.voiceConnection.codecSupported(this.properties.channel_codec) ? $.fn.hide : $.fn.show).apply(this.channelTag().find(".icons .icon_no_sound"));
            }
            else if (key == "channel_flag_default") {
                (this.properties.channel_flag_default ? $.fn.show : $.fn.hide).apply(this.channelTag().find(".icons .icon_default"));
            }
            else if (key == "channel_flag_password")
                (this.properties.channel_flag_password ? $.fn.show : $.fn.hide).apply(this.channelTag().find(".icons .icon_password"));
            else if (key == "channel_needed_talk_power")
                (this.properties.channel_needed_talk_power > 0 ? $.fn.show : $.fn.hide).apply(this.channelTag().find(".icons .icon_moderated"));
            else if (key == "channel_description") {
                this._cached_channel_description = undefined;
                if (this._cached_channel_description_promise_resolve)
                    this._cached_channel_description_promise_resolve(value);
                this._cached_channel_description_promise = undefined;
                this._cached_channel_description_promise_resolve = undefined;
                this._cached_channel_description_promise_reject = undefined;
            }
            if (key == "channel_maxclients" || key == "channel_maxfamilyclients" || key == "channel_flag_private" || key == "channel_flag_password")
                this.updateChannelTypeIcon();
        }
        group.end();
    }
    updateChannelTypeIcon() {
        let tag = this.channelTag().find(".channel_type");
        tag.removeAttr('class');
        tag.addClass("channel_only_normal channel_type icon");
        let type;
        if (this.properties.channel_flag_password == true && !this._cachedPassword)
            type = "yellow";
        else if ((!this.properties.channel_flag_maxclients_unlimited && this.clients().length >= this.properties.channel_maxclients) ||
            (!this.properties.channel_flag_maxfamilyclients_unlimited && this.properties.channel_maxfamilyclients >= 0 && this.clients(true).length >= this.properties.channel_maxfamilyclients))
            type = "red";
        else
            type = "green";
        tag.addClass("client-channel_" + type + "_subscribed");
    }
    createChatTag(braces = false) {
        let tag = $.spawn("div");
        tag.css("display", "inline-block");
        tag.css("cursor", "pointer");
        tag.css("font-weight", "bold");
        tag.css("color", "darkblue");
        if (braces)
            tag.text("\"" + this.channelName() + "\"");
        else
            tag.text(this.channelName());
        tag.contextmenu(event => {
            if (event.isDefaultPrevented())
                return;
            event.preventDefault();
            this.showContextMenu(event.pageX, event.pageY);
        });
        tag.attr("channelId", this.channelId);
        tag.attr("channelName", this.channelName());
        return tag;
    }
    channelType() {
        if (this.properties.channel_flag_permanent == true)
            return ChannelType.PERMANENT;
        if (this.properties.channel_flag_semi_permanent == true)
            return ChannelType.SEMI_PERMANENT;
        return ChannelType.TEMPORARY;
    }
    joinChannel() {
        if (this.properties.channel_flag_password == true &&
            !this._cachedPassword &&
            !this.channelTree.client.permissions.neededPermission(PermissionType.B_CHANNEL_JOIN_IGNORE_PASSWORD).granted(1)) {
            createInputModal(_translations.LEv8556x || (_translations.LEv8556x = tr("Channel password")), _translations.YNwzVGiN || (_translations.YNwzVGiN = tr("Channel password:")), () => true, text => {
                if (typeof (text) == typeof (true))
                    return;
                helpers.hashPassword(text).then(result => {
                    this._cachedPassword = result;
                    this.joinChannel();
                    this.updateChannelTypeIcon();
                });
            }).open();
        }
        else if (this.channelTree.client.getClient().currentChannel() != this)
            this.channelTree.client.getServerConnection().joinChannel(this, this._cachedPassword).then(() => {
                sound.play(Sound.CHANNEL_JOINED);
            }).catch(error => {
                if (error instanceof CommandResult) {
                    if (error.id == 781) { //Invalid password
                        this._cachedPassword = undefined;
                        this.updateChannelTypeIcon();
                    }
                }
            });
    }
}
//Global functions
function chat_channel_contextmenu(_element, event) {
    event.preventDefault();
    let element = $(_element);
    let chid = Number.parseInt(element.attr("channelId"));
    let channel = globalClient.channelTree.findChannel(chid);
    if (!channel) {
        //TODO
        return;
    }
    channel.showContextMenu(event.pageX, event.pageY);
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["3ad170db2dc5b0037a2477cfb0210c389424d783aeae4c827418d749aad85bd0"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["3ad170db2dc5b0037a2477cfb0210c389424d783aeae4c827418d749aad85bd0"] = "3ad170db2dc5b0037a2477cfb0210c389424d783aeae4c827418d749aad85bd0";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "eS_d4fN8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalChangeVolume.ts (10,29)" }, { name: "zFATLdbu", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalChangeVolume.ts (29,34)" }, { name: "CEgpGu_e", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalChangeVolume.ts (37,35)" }, { name: "s1Rn_vRq", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalChangeVolume.ts (46,31)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
/// <reference path="../../proto.ts" />
var Modals;
(function (Modals) {
    function spawnChangeVolume(current, callback) {
        let updateCallback;
        const connectModal = createModal({
            header: function () {
                let header = $.spawn("div");
                header.text(_translations.eS_d4fN8 || (_translations.eS_d4fN8 = tr("Change volume")));
                return header;
            },
            body: function () {
                let tag = $("#tmpl_change_volume").renderTag();
                tag.find(".volume_slider").on("change", _ => updateCallback(tag.find(".volume_slider").val()));
                tag.find(".volume_slider").on("input", _ => updateCallback(tag.find(".volume_slider").val()));
                //connect_address
                return tag;
            },
            footer: function () {
                let tag = $.spawn("div");
                tag.css("text-align", "right");
                tag.css("margin-top", "3px");
                tag.css("margin-bottom", "6px");
                tag.addClass("modal-button-group");
                let buttonReset = $.spawn("button");
                buttonReset.text(_translations.zFATLdbu || (_translations.zFATLdbu = tr("Reset")));
                buttonReset.on("click", function () {
                    updateCallback(100);
                });
                tag.append(buttonReset);
                let buttonCancel = $.spawn("button");
                buttonCancel.text(_translations.CEgpGu_e || (_translations.CEgpGu_e = tr("Cancel")));
                buttonCancel.on("click", function () {
                    updateCallback(current * 100);
                    connectModal.close();
                });
                tag.append(buttonCancel);
                let buttonOk = $.spawn("button");
                buttonOk.text(_translations.s1Rn_vRq || (_translations.s1Rn_vRq = tr("OK")));
                buttonOk.on("click", function () {
                    connectModal.close();
                });
                tag.append(buttonOk);
                return tag;
            },
            width: 600
        });
        updateCallback = value => {
            connectModal.htmlTag.find(".volume_slider").val(value);
            let display = connectModal.htmlTag.find(".display_volume");
            let number = (value - 100);
            display.html((number == 0 ? "&plusmn;" : number > 0 ? "+" : "") + number + " %");
            callback(value / 100);
        };
        connectModal.open();
        updateCallback(current * 100);
    }
    Modals.spawnChangeVolume = spawnChangeVolume;
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["01346bb95a1c394364a4124ff21dcc586ceb42901581f91c6d31c811c6e0f7fb"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["01346bb95a1c394364a4124ff21dcc586ceb42901581f91c6d31c811c6e0f7fb"] = "01346bb95a1c394364a4124ff21dcc586ceb42901581f91c6d31c811c6e0f7fb";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "DZHowFLQ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalServerGroupDialog.ts (4,21)" }, { name: "zPvWh4OL", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalServerGroupDialog.ts (31,42)" }, { name: "fvgej6l1", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalServerGroupDialog.ts (48,35)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var Modals;
(function (Modals) {
    function createServerGroupAssignmentModal(client, callback) {
        const modal = createModal({
            header: _translations.DZHowFLQ || (_translations.DZHowFLQ = tr("Server Groups")),
            body: () => {
                let tag = {};
                let groups = tag["groups"] = [];
                tag["client_name"] = client.clientNickName();
                for (let group of client.channelTree.client.groups.serverGroups.sort(GroupManager.sorter())) {
                    if (group.type != GroupType.NORMAL)
                        continue;
                    let entry = {};
                    entry["id"] = group.id;
                    entry["name"] = group.name;
                    entry["assigned"] = client.groupAssigned(group);
                    entry["disabled"] = !client.channelTree.client.permissions.neededPermission(PermissionType.I_GROUP_MEMBER_ADD_POWER).granted(group.requiredMemberRemovePower);
                    tag["icon_" + group.id] = client.channelTree.client.fileManager.icons.generateTag(group.properties.iconid);
                    groups.push(entry);
                }
                let template = $("#tmpl_server_group_assignment").renderTag(tag);
                template.find(".group-entry input").each((_idx, _entry) => {
                    let entry = $(_entry);
                    entry.on('change', event => {
                        let group_id = parseInt(entry.attr("group-id"));
                        let group = client.channelTree.client.groups.serverGroup(group_id);
                        if (!group) {
                            console.warn(_translations.zPvWh4OL || (_translations.zPvWh4OL = tr("Could not resolve target group!")));
                            return false;
                        }
                        let target = entry.prop("checked");
                        callback(group, target).then(flag => flag ? Promise.resolve() : Promise.reject()).catch(error => entry.prop("checked", !target));
                    });
                });
                return template;
            },
            footer: () => {
                let footer = $.spawn("div");
                footer.addClass("modal-button-group");
                footer.css("margin", "5px");
                let button_close = $.spawn("button");
                button_close.text(_translations.fvgej6l1 || (_translations.fvgej6l1 = tr("Close"))).addClass("button_close");
                footer.append(button_close);
                return footer;
            },
            width: "max-content"
        });
        modal.htmlTag.find(".button_close").click(() => {
            modal.close();
        });
        modal.open();
    }
    Modals.createServerGroupAssignmentModal = createServerGroupAssignmentModal;
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["e7f4bd6fbec499509d757fd08dffb70c229b946e3a3e23064bd0954937171b5c"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["e7f4bd6fbec499509d757fd08dffb70c229b946e3a3e23064bd0954937171b5c"] = "e7f4bd6fbec499509d757fd08dffb70c229b946e3a3e23064bd0954937171b5c";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "G9aB_Nff", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client_move.ts (28,21)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="client.ts" />
class ClientMover {
    constructor(tree) {
        this._active = false;
        this.origin_point = undefined;
        this.channel_tree = tree;
    }
    activate(client, callback, event) {
        this.finish_listener(undefined);
        this.selected_client = client;
        this.callback = callback;
        console.log(_translations.G9aB_Nff || (_translations.G9aB_Nff = tr("Starting mouse move")));
        ClientMover.listener_root.on('mouseup', this._bound_finish = this.finish_listener.bind(this)).on('mousemove', this._bound_move = this.move_listener.bind(this));
        {
            const content = ClientMover.move_element.find(".container");
            content.empty();
            content.append($.spawn("a").text(client.clientNickName()));
        }
        this.move_listener(event);
    }
    move_listener(event) {
        //console.log("Mouse move: " + event.pageX + " - " + event.pageY);
        if (!event.pageX || !event.pageY)
            return;
        if (!this.origin_point)
            this.origin_point = { x: event.pageX, y: event.pageY };
        ClientMover.move_element.css({
            "top": (event.pageY - 1) + "px",
            "left": (event.pageX + 10) + "px"
        });
        if (!this._active) {
            const d_x = this.origin_point.x - event.pageX;
            const d_y = this.origin_point.y - event.pageY;
            this._active = Math.sqrt(d_x * d_x + d_y * d_y) > 5 * 5;
            if (this._active) {
                ClientMover.move_element.show();
                this.channel_tree.onSelect(this.selected_client, true);
            }
        }
        const elements = document.elementsFromPoint(event.pageX, event.pageY);
        while (elements.length > 0) {
            if (elements[0].classList.contains("channelLine"))
                break;
            elements.pop_front();
        }
        if (this.hovered_channel) {
            this.hovered_channel.classList.remove("move-selected");
            this.hovered_channel = undefined;
        }
        if (elements.length > 0) {
            elements[0].classList.add("move-selected");
            this.hovered_channel = elements[0];
        }
    }
    finish_listener(event) {
        ClientMover.move_element.hide();
        const channel_id = this.hovered_channel ? parseInt(this.hovered_channel.getAttribute("channel-id")) : 0;
        ClientMover.listener_root.unbind('mouseleave', this._bound_finish);
        ClientMover.listener_root.unbind('mouseup', this._bound_finish);
        ClientMover.listener_root.unbind('mousemove', this._bound_move);
        if (this.hovered_channel) {
            this.hovered_channel.classList.remove("move-selected");
            this.hovered_channel = undefined;
        }
        this.origin_point = undefined;
        if (!this._active) {
            this.selected_client = undefined;
            this.callback = undefined;
            return;
        }
        this._active = false;
        if (this.callback) {
            if (!channel_id)
                this.callback(undefined);
            else {
                this.callback(this.channel_tree.findChannel(channel_id));
            }
            this.callback = undefined;
        }
    }
    deactivate() {
        this.callback = undefined;
        this.finish_listener(undefined);
    }
}
ClientMover.listener_root = $(document);
ClientMover.move_element = $("#mouse-move");
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["82cd298375f3c7ac3c2855e990bb25845bfdb228132d07c367e705316aaa2942"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["82cd298375f3c7ac3c2855e990bb25845bfdb228132d07c367e705316aaa2942"] = "82cd298375f3c7ac3c2855e990bb25845bfdb228132d07c367e705316aaa2942";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "md7q_MPd", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (212,19)" }, { name: "_CHkQPOE", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (239,19)" }, { name: "eoy46Zs3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (246,19)" }, { name: "kH4qY4D7", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (259,23)" }, { name: "Cprgyr_V", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (267,23)" }, { name: "UOz9FEBi", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (269,38)" }, { name: "BTjHdznN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (269,57)" }, { name: "p0SqnJIc", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (284,23)" }, { name: "rSzPucQu", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (286,38)" }, { name: "Atux8DVx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (286,71)" }, { name: "dt_cyNoN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (304,23)" }, { name: "YWB34_BO", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (314,23)" }, { name: "WKsEbgMK", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (316,38)" }, { name: "hZZ43AKW", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (316,70)" }, { name: "JmMe45fF", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (332,23)" }, { name: "AuKeyH9f", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (334,38)" }, { name: "IXX0lt86", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (334,69)" }, { name: "bQv4w6sT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (350,23)" }, { name: "eujbHNDG", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (386,23)" }, { name: "DfK8VuJM", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (528,70)" }, { name: "eK_TI9oD", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (744,23)" }, { name: "KEy80hEG", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (749,23)" }, { name: "G8lErIWa", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (752,38)" }, { name: "wQmXisKZ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (752,68)" }, { name: "u6lnuLeP", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (754,41)" }, { name: "LQ6rmzHC", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (812,49)" }, { name: "ERhGr6ue", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (814,47)" }, { name: "gpWHLR2C", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (864,23)" }, { name: "iitgrrBS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (868,38)" }, { name: "htxYG1XR", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (868,72)" }, { name: "eMUoj0tz", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (880,23)" }, { name: "sEPz7X4u", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (884,38)" }, { name: "tJq1GcK3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (884,75)" }, { name: "qjzy0woT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (896,23)" }, { name: "YpJxTc2T", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (902,23)" }, { name: "MrxRYfbX", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (906,38)" }, { name: "udFKYkCe", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (906,66)" }, { name: "HTWcLsYx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (917,50)" }, { name: "hsgS53oj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (929,23)" }, { name: "Ec3EKf54", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (939,23)" }, { name: "PKPzV5Me", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (941,38)" }, { name: "mPyVaqeG", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (941,70)" }, { name: "PL8MpvqT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (943,41)" }, { name: "gozLaEfL", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (957,23)" }, { name: "dyguJnU5", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (969,23)" }, { name: "OCnxnsoS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (973,83)" }, { name: "Fq9frpzi", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/client.ts (974,39)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="channel.ts" />
/// <reference path="modal/ModalChangeVolume.ts" />
/// <reference path="modal/ModalServerGroupDialog.ts" />
/// <reference path="client_move.ts" />
var ClientType;
(function (ClientType) {
    ClientType[ClientType["CLIENT_VOICE"] = 0] = "CLIENT_VOICE";
    ClientType[ClientType["CLIENT_QUERY"] = 1] = "CLIENT_QUERY";
    ClientType[ClientType["CLIENT_INTERNAL"] = 2] = "CLIENT_INTERNAL";
    ClientType[ClientType["CLIENT_WEB"] = 3] = "CLIENT_WEB";
    ClientType[ClientType["CLIENT_MUSIC"] = 4] = "CLIENT_MUSIC";
    ClientType[ClientType["CLIENT_UNDEFINED"] = 5] = "CLIENT_UNDEFINED";
})(ClientType || (ClientType = {}));
class ClientProperties {
    constructor() {
        this.client_type = ClientType.CLIENT_VOICE; //TeamSpeaks type
        this.client_type_exact = ClientType.CLIENT_VOICE;
        this.client_database_id = 0;
        this.client_version = "";
        this.client_platform = "";
        this.client_nickname = "unknown";
        this.client_unique_identifier = "unknown";
        this.client_description = "";
        this.client_servergroups = "";
        this.client_channel_group_id = 0;
        this.client_lastconnected = 0;
        this.client_flag_avatar = "";
        this.client_icon_id = 0;
        this.client_away_message = "";
        this.client_away = false;
        this.client_input_hardware = false;
        this.client_output_hardware = false;
        this.client_input_muted = false;
        this.client_output_muted = false;
        this.client_is_channel_commander = false;
        this.client_teaforum_id = 0;
        this.client_teaforum_name = "";
        this.client_talk_power = 0;
    }
}
class ClientEntry {
    constructor(clientId, clientName, properties = new ClientProperties()) {
        this.lastVariableUpdate = 0;
        this._speaking = false;
        this._properties = properties;
        this._properties.client_nickname = clientName;
        this._clientId = clientId;
        this.channelTree = null;
        this._channel = null;
        this.audioController = new AudioController();
        const _this = this;
        this.audioController.onSpeaking = function () {
            _this.speaking = true;
        };
        this.audioController.onSilence = function () {
            _this.speaking = false;
        };
        this.audioController.initialize();
    }
    get properties() {
        return this._properties;
    }
    currentChannel() { return this._channel; }
    clientNickName() { return this.properties.client_nickname; }
    clientUid() { return this.properties.client_unique_identifier; }
    clientId() { return this._clientId; }
    getAudioController() {
        return this.audioController;
    }
    initializeListener() {
        if (this._listener_initialized)
            return;
        this._listener_initialized = true;
        this.tag.click(event => {
            console.log("Clicked!");
            this.channelTree.onSelect(this);
        });
        if (!(this instanceof LocalClientEntry) && !(this instanceof MusicClientEntry))
            this.tag.dblclick(event => {
                if ($.isArray(this.channelTree.currently_selected)) { //Multiselect
                    return;
                }
                this.chat(true).focus();
            });
        if (!settings.static(Settings.KEY_DISABLE_CONTEXT_MENU, false)) {
            this.tag.on("contextmenu", (event) => {
                event.preventDefault();
                if ($.isArray(this.channelTree.currently_selected)) { //Multiselect
                    (this.channelTree.currently_selected_context_callback || ((_) => null))(event);
                    return;
                }
                this.channelTree.onSelect(this, true);
                this.showContextMenu(event.pageX, event.pageY, () => {
                    this.channelTree.onSelect(undefined, true);
                });
                return false;
            });
        }
        this.tag.mousedown(event => {
            if (event.which != 1)
                return; //Only the left button
            this.channelTree.client_mover.activate(this, target => {
                if (!target)
                    return;
                if (target == this._channel)
                    return;
                const source = this._channel;
                const self = this.channelTree.client.getClient();
                this.channelTree.client.serverConnection.sendCommand("clientmove", {
                    clid: this.clientId(),
                    cid: target.getChannelId()
                }).then(event => {
                    if (this.clientId() == this.channelTree.client.clientId)
                        sound.play(Sound.CHANNEL_JOINED);
                    else if (target !== source && target != self.currentChannel())
                        sound.play(Sound.USER_MOVED);
                });
            }, event);
        });
    }
    assignment_context() {
        let server_groups = [];
        for (let group of this.channelTree.client.groups.serverGroups.sort(GroupManager.sorter())) {
            if (group.type != GroupType.NORMAL)
                continue;
            let entry = {};
            {
                let tag = $.spawn("label").addClass("checkbox");
                $.spawn("input").attr("type", "checkbox").prop("checked", this.groupAssigned(group)).appendTo(tag);
                $.spawn("span").addClass("checkmark").appendTo(tag);
                entry.icon = tag;
            }
            entry.name = group.name + " [" + (group.properties.savedb ? "perm" : "tmp") + "]";
            if (this.groupAssigned(group)) {
                entry.callback = () => {
                    this.channelTree.client.serverConnection.sendCommand("servergroupdelclient", {
                        sgid: group.id,
                        cldbid: this.properties.client_database_id
                    });
                };
                entry.disabled = !this.channelTree.client.permissions.neededPermission(PermissionType.I_GROUP_MEMBER_ADD_POWER).granted(group.requiredMemberRemovePower);
            }
            else {
                entry.callback = () => {
                    this.channelTree.client.serverConnection.sendCommand("servergroupaddclient", {
                        sgid: group.id,
                        cldbid: this.properties.client_database_id
                    });
                };
                entry.disabled = !this.channelTree.client.permissions.neededPermission(PermissionType.I_GROUP_MEMBER_REMOVE_POWER).granted(group.requiredMemberAddPower);
            }
            entry.type = MenuEntryType.ENTRY;
            server_groups.push(entry);
        }
        let channel_groups = [];
        for (let group of this.channelTree.client.groups.channelGroups.sort(GroupManager.sorter())) {
            if (group.type != GroupType.NORMAL)
                continue;
            let entry = {};
            {
                let tag = $.spawn("label").addClass("checkbox");
                $.spawn("input").attr("type", "checkbox").prop("checked", this.assignedChannelGroup() == group.id).appendTo(tag);
                $.spawn("span").addClass("checkmark").appendTo(tag);
                entry.icon = tag;
            }
            entry.name = group.name + " [" + (group.properties.savedb ? "perm" : "tmp") + "]";
            entry.callback = () => {
                this.channelTree.client.serverConnection.sendCommand("setclientchannelgroup", {
                    cldbid: this.properties.client_database_id,
                    cgid: group.id,
                    cid: this.currentChannel().channelId
                });
            };
            entry.disabled = !this.channelTree.client.permissions.neededPermission(PermissionType.I_GROUP_MEMBER_ADD_POWER).granted(group.requiredMemberRemovePower);
            entry.type = MenuEntryType.ENTRY;
            channel_groups.push(entry);
        }
        return [{
                type: MenuEntryType.SUB_MENU,
                icon: "client-permission_server_groups",
                name: _translations.md7q_MPd || (_translations.md7q_MPd = tr("Set server group")),
                sub_menu: [
                    {
                        type: MenuEntryType.ENTRY,
                        icon: "client-permission_server_groups",
                        name: "Server groups dialog",
                        callback: () => {
                            Modals.createServerGroupAssignmentModal(this, (group, flag) => {
                                if (flag) {
                                    return this.channelTree.client.serverConnection.sendCommand("servergroupaddclient", {
                                        sgid: group.id,
                                        cldbid: this.properties.client_database_id
                                    }).then(result => true);
                                }
                                else
                                    return this.channelTree.client.serverConnection.sendCommand("servergroupdelclient", {
                                        sgid: group.id,
                                        cldbid: this.properties.client_database_id
                                    }).then(result => true);
                            });
                        }
                    },
                    MenuEntry.HR(),
                    ...server_groups
                ]
            }, {
                type: MenuEntryType.SUB_MENU,
                icon: "client-permission_channel",
                name: _translations._CHkQPOE || (_translations._CHkQPOE = tr("Set channel group")),
                sub_menu: [
                    ...channel_groups
                ]
            }, {
                type: MenuEntryType.SUB_MENU,
                icon: "client-permission_client",
                name: _translations.eoy46Zs3 || (_translations.eoy46Zs3 = tr("Permissions")),
                disabled: true,
                sub_menu: []
            }];
    }
    showContextMenu(x, y, on_close = undefined) {
        const _this = this;
        spawn_context_menu(x, y, {
            type: MenuEntryType.ENTRY,
            icon: "client-change_nickname",
            name: _translations.kH4qY4D7 || (_translations.kH4qY4D7 = tr("<b>Open text chat</b>")),
            callback: function () {
                chat.activeChat = _this.chat(true);
                chat.focus();
            }
        }, {
            type: MenuEntryType.ENTRY,
            icon: "client-poke",
            name: _translations.Cprgyr_V || (_translations.Cprgyr_V = tr("Poke client")),
            callback: function () {
                createInputModal(_translations.UOz9FEBi || (_translations.UOz9FEBi = tr("Poke client")), _translations.BTjHdznN || (_translations.BTjHdznN = tr("Poke message:<br>")), text => true, result => {
                    if (typeof (result) === "string") {
                        //TODO tr
                        console.log("Poking client " + _this.clientNickName() + " with message " + result);
                        _this.channelTree.client.serverConnection.sendCommand("clientpoke", {
                            clid: _this.clientId(),
                            msg: result
                        });
                    }
                }, { width: 400, maxLength: 512 }).open();
            }
        }, {
            type: MenuEntryType.ENTRY,
            icon: "client-edit",
            name: _translations.p0SqnJIc || (_translations.p0SqnJIc = tr("Change description")),
            callback: function () {
                createInputModal(_translations.rSzPucQu || (_translations.rSzPucQu = tr("Change client description")), _translations.Atux8DVx || (_translations.Atux8DVx = tr("New description:<br>")), text => true, result => {
                    if (typeof (result) === "string") {
                        //TODO tr
                        console.log("Changing " + _this.clientNickName() + "'s description to " + result);
                        _this.channelTree.client.serverConnection.sendCommand("clientedit", {
                            clid: _this.clientId(),
                            client_description: result
                        });
                    }
                }, { width: 400, maxLength: 1024 }).open();
            }
        }, MenuEntry.HR(), ...this.assignment_context(), MenuEntry.HR(), {
            type: MenuEntryType.ENTRY,
            icon: "client-move_client_to_own_channel",
            name: _translations.dt_cyNoN || (_translations.dt_cyNoN = tr("Move client to your channel")),
            callback: () => {
                this.channelTree.client.serverConnection.sendCommand("clientmove", {
                    clid: this.clientId(),
                    cid: this.channelTree.client.getClient().currentChannel().getChannelId()
                });
            }
        }, {
            type: MenuEntryType.ENTRY,
            icon: "client-kick_channel",
            name: _translations.YWB34_BO || (_translations.YWB34_BO = tr("Kick client from channel")),
            callback: () => {
                createInputModal(_translations.WKsEbgMK || (_translations.WKsEbgMK = tr("Kick client from channel")), _translations.hZZ43AKW || (_translations.hZZ43AKW = tr("Kick reason:<br>")), text => true, result => {
                    if (result) {
                        //TODO tr
                        console.log("Kicking client " + _this.clientNickName() + " from channel with reason " + result);
                        _this.channelTree.client.serverConnection.sendCommand("clientkick", {
                            clid: _this.clientId(),
                            reasonid: ViewReasonId.VREASON_CHANNEL_KICK,
                            reasonmsg: result
                        });
                    }
                }, { width: 400, maxLength: 255 }).open();
            }
        }, {
            type: MenuEntryType.ENTRY,
            icon: "client-kick_server",
            name: _translations.JmMe45fF || (_translations.JmMe45fF = tr("Kick client fom server")),
            callback: () => {
                createInputModal(_translations.AuKeyH9f || (_translations.AuKeyH9f = tr("Kick client from server")), _translations.IXX0lt86 || (_translations.IXX0lt86 = tr("Kick reason:<br>")), text => true, result => {
                    if (result) {
                        //TODO tr
                        console.log("Kicking client " + _this.clientNickName() + " from server with reason " + result);
                        _this.channelTree.client.serverConnection.sendCommand("clientkick", {
                            clid: _this.clientId(),
                            reasonid: ViewReasonId.VREASON_SERVER_KICK,
                            reasonmsg: result
                        });
                    }
                }, { width: 400, maxLength: 255 }).open();
            }
        }, {
            type: MenuEntryType.ENTRY,
            icon: "client-ban_client",
            name: _translations.bQv4w6sT || (_translations.bQv4w6sT = tr("Ban client")),
            invalidPermission: !this.channelTree.client.permissions.neededPermission(PermissionType.I_CLIENT_BAN_MAX_BANTIME).granted(1),
            callback: () => {
                Modals.spawnBanClient(this.properties.client_nickname, (data) => {
                    this.channelTree.client.serverConnection.sendCommand("banclient", {
                        uid: this.properties.client_unique_identifier,
                        banreason: data.reason,
                        time: data.length
                    }, [data.no_ip ? "no-ip" : "", data.no_hwid ? "no-hardware-id" : "", data.no_name ? "no-nickname" : ""]).then(() => {
                        sound.play(Sound.USER_BANNED);
                    });
                });
            }
        }, MenuEntry.HR(), 
        /*
        {
            type: MenuEntryType.ENTRY,
            icon: "client-kick_server",
            name: "Add group to client",
            invalidPermission: true, //!this.channelTree.client.permissions.neededPermission(PermissionType.I_CLIENT_BAN_MAX_BANTIME).granted(1),
            callback: () => {
                Modals.spawnBanClient(this.properties.client_nickname, (duration, reason) => {
                    this.channelTree.client.serverConnection.sendCommand("banclient", {
                        uid: this.properties.client_unique_identifier,
                        banreason: reason,
                        time: duration
                    });
                });
            }
        },
        MenuEntry.HR(),
        */
        {
            type: MenuEntryType.ENTRY,
            icon: "client-volume",
            name: _translations.eujbHNDG || (_translations.eujbHNDG = tr("Change Volume")),
            callback: () => {
                Modals.spawnChangeVolume(this.audioController.volume, volume => {
                    settings.changeServer("volume_client_" + this.clientUid(), volume);
                    this.audioController.volume = volume;
                    if (globalClient.selectInfo.currentSelected == this)
                        globalClient.selectInfo.update();
                });
            }
        }, MenuEntry.CLOSE(on_close));
    }
    get tag() {
        if (this._tag)
            return this._tag;
        let tag = $.spawn("div");
        tag.attr("id", "client_" + this.clientId());
        tag.addClass("client");
        tag.append($.spawn("div").addClass("icon_empty"));
        tag.append($.spawn("div").addClass("icon_client_state").attr("title", "Client state"));
        tag.append($.spawn("div").addClass("group_prefix").attr("title", "Server groups prefixes").hide());
        tag.append($.spawn("div").addClass("name").text(this.clientNickName()));
        tag.append($.spawn("div").addClass("group_suffix").attr("title", "Server groups suffix").hide());
        tag.append($.spawn("div").addClass("away").text(this.clientNickName()));
        let clientIcons = $.spawn("span");
        clientIcons.append($.spawn("div").addClass("icon icon_talk_power client-input_muted").hide());
        clientIcons.append($.spawn("span").addClass("group_icons"));
        clientIcons.append($.spawn("span").addClass("client_icon"));
        tag.append(clientIcons);
        this._tag = tag;
        this.initializeListener();
        return this._tag;
    }
    static chatTag(id, name, uid, braces = false) {
        let tag = $.spawn("div");
        tag.css("cursor", "pointer")
            .css("font-weight", "bold")
            .css("color", "darkblue")
            .css("display", "inline-block")
            .css("margin", 0);
        if (braces)
            tag.text("\"" + name + "\"");
        else
            tag.text(name);
        tag.contextmenu(event => {
            if (event.isDefaultPrevented())
                return;
            event.preventDefault();
            let client = globalClient.channelTree.findClient(id);
            if (!client)
                return;
            if (client.properties.client_unique_identifier != uid)
                return;
            client.showContextMenu(event.pageX, event.pageY);
        });
        tag.attr("clientId", id);
        tag.attr("clientUid", uid);
        tag.attr("clientName", name);
        return tag;
    }
    createChatTag(braces = false) {
        return ClientEntry.chatTag(this.clientId(), this.clientNickName(), this.clientUid(), braces);
    }
    set speaking(flag) {
        if (flag == this._speaking)
            return;
        this._speaking = flag;
        this.updateClientSpeakIcon();
    }
    updateClientStatusIcons() {
        let talk_power = this.properties.client_talk_power >= this._channel.properties.channel_needed_talk_power;
        if (talk_power)
            this.tag.find("span").find(".icon_talk_power").hide();
        else
            this.tag.find("span").find(".icon_talk_power").show();
    }
    updateClientSpeakIcon() {
        let icon = "";
        let clicon = "";
        console.error(this.properties.client_nickname + " - " + this.properties.client_type_exact + " - " + this.properties.client_type);
        if (this.properties.client_type_exact == ClientType.CLIENT_QUERY) {
            icon = "client-server_query";
            console.log("Server query!");
        }
        else {
            if (this.properties.client_away) {
                icon = "client-away";
            }
            else if (!this.properties.client_output_hardware) {
                icon = "client-hardware_output_muted";
            }
            else if (this.properties.client_output_muted) {
                icon = "client-output_muted";
            }
            else if (!this.properties.client_input_hardware) {
                icon = "client-hardware_input_muted";
            }
            else if (this.properties.client_input_muted) {
                icon = "client-input_muted";
            }
            else {
                if (this._speaking) {
                    if (this.properties.client_is_channel_commander)
                        clicon = "client_cc_talk";
                    else
                        clicon = "client_talk";
                }
                else {
                    if (this.properties.client_is_channel_commander)
                        clicon = "client_cc_idle";
                    else
                        clicon = "client_idle";
                }
            }
        }
        if (clicon.length > 0)
            this.tag.find(".icon_client_state").attr('class', 'icon_client_state clicon ' + clicon);
        else if (icon.length > 0)
            this.tag.find(".icon_client_state").attr('class', 'icon_client_state icon ' + icon);
        else
            this.tag.find(".icon_client_state").attr('class', 'icon_client_state icon_empty');
    }
    updateAwayMessage() {
        let tag = this.tag.find(".away");
        if (this.properties.client_away == true && this.properties.client_away_message) {
            tag.text("[" + this.properties.client_away_message + "]");
            tag.show();
        }
        else {
            tag.hide();
        }
    }
    updateVariables(...variables) {
        let group = log.group(log.LogType.DEBUG, LogCategory.CLIENT, _translations.DfK8VuJM || (_translations.DfK8VuJM = tr("Update properties (%i) of %s (%i)")), variables.length, this.clientNickName(), this.clientId());
        let update_icon_status = false;
        let update_icon_speech = false;
        let update_away = false;
        let reorder_channel = false;
        for (let variable of variables) {
            JSON.map_field_to(this._properties, variable.value, variable.key);
            //TODO tr
            group.log("Updating client " + this.clientId() + ". Key " + variable.key + " Value: '" + variable.value + "' (" + typeof (this.properties[variable.key]) + ")");
            if (variable.key == "client_nickname") {
                this.tag.find(".name").text(variable.value);
                let chat = this.chat(false);
                if (chat)
                    chat.name = variable.value;
                reorder_channel = true;
            }
            if (variable.key == "client_away" || variable.key == "client_output_muted" || variable.key == "client_input_hardware" || variable.key == "client_input_muted" || variable.key == "client_is_channel_commander") {
                update_icon_speech = true;
            }
            if (variable.key == "client_away_message" || variable.key == "client_away") {
                update_away = true;
            }
            if (variable.key == "client_unique_identifier") {
                this.audioController.volume = parseFloat(settings.server("volume_client_" + this.clientUid(), "1"));
                //TODO tr
                console.error("Updated volume from config " + this.audioController.volume + " - " + "volume_client_" + this.clientUid() + " - " + settings.server("volume_client_" + this.clientUid(), "1"));
                console.log(this.avatarId());
            }
            if (variable.key == "client_talk_power") {
                reorder_channel = true;
                update_icon_status = true;
            }
            if (variable.key == "client_icon_id")
                this.updateClientIcon();
            if (variable.key == "client_channel_group_id" || variable.key == "client_servergroups")
                this.update_displayed_client_groups();
        }
        /* process updates after variables have been set */
        if (this._channel && reorder_channel)
            this._channel.reorderClients();
        if (update_icon_speech)
            this.updateClientSpeakIcon();
        if (update_icon_status)
            this.updateClientStatusIcons();
        if (update_away)
            this.updateAwayMessage();
        group.end();
    }
    update_displayed_client_groups() {
        this.tag.find("span .group_icons").children().detach();
        for (let id of this.assignedServerGroupIds())
            this.updateGroupIcon(this.channelTree.client.groups.serverGroup(id));
        this.updateGroupIcon(this.channelTree.client.groups.channelGroup(this.properties.client_channel_group_id));
        let prefix_groups = [];
        let suffix_groups = [];
        for (const group_id of this.assignedServerGroupIds()) {
            const group = this.channelTree.client.groups.serverGroup(group_id);
            if (!group)
                continue;
            if (group.properties.namemode == 1)
                prefix_groups.push(group.name);
            else if (group.properties.namemode == 2)
                suffix_groups.push(group.name);
        }
        const tag_group_prefix = this.tag.find(".group_prefix");
        const tag_group_suffix = this.tag.find(".group_suffix");
        if (prefix_groups.length > 0) {
            tag_group_prefix.text("[" + prefix_groups.join("][") + "]").show();
        }
        else {
            tag_group_prefix.hide();
        }
        if (suffix_groups.length > 0) {
            tag_group_suffix.text("[" + suffix_groups.join("][") + "]").show();
        }
        else {
            tag_group_suffix.hide();
        }
    }
    updateClientVariables() {
        if (this.lastVariableUpdate == 0 || new Date().getTime() - 10 * 60 * 1000 > this.lastVariableUpdate) { //Cache these only 10 min
            this.lastVariableUpdate = new Date().getTime();
            this.channelTree.client.serverConnection.sendCommand("clientgetvariables", { clid: this.clientId() });
        }
    }
    chat(create = false) {
        let chatName = "client_" + this.clientUid() + ":" + this.clientId();
        let c = chat.findChat(chatName);
        if ((!c) && create) {
            c = chat.createChat(chatName);
            c.closeable = true;
            c.name = this.clientNickName();
            const _this = this;
            c.onMessageSend = function (text) {
                _this.channelTree.client.serverConnection.sendMessage(text, ChatType.CLIENT, _this);
            };
            c.onClose = function () {
                //TODO check online?
                _this.channelTree.client.serverConnection.sendCommand("clientchatclosed", { "clid": _this.clientId() });
                return true;
            };
        }
        return c;
    }
    updateClientIcon() {
        this.tag.find("span .client_icon").children().detach();
        if (this.properties.client_icon_id > 0) {
            this.channelTree.client.fileManager.icons.generateTag(this.properties.client_icon_id).attr("title", "Client icon")
                .appendTo(this.tag.find("span .client_icon"));
        }
    }
    updateGroupIcon(group) {
        if (!group)
            return;
        //TODO group icon order
        this.tag.find(".group_icons .icon_group_" + group.id).detach();
        if (group.properties.iconid > 0) {
            this.tag.find("span .group_icons").append($.spawn("div").addClass("icon_group_" + group.id).append(this.channelTree.client.fileManager.icons.generateTag(group.properties.iconid)).attr("title", group.name));
        }
    }
    assignedServerGroupIds() {
        let result = [];
        for (let id of this.properties.client_servergroups.split(",")) {
            if (id.length == 0)
                continue;
            result.push(Number.parseInt(id));
        }
        return result;
    }
    assignedChannelGroup() {
        return this.properties.client_channel_group_id;
    }
    groupAssigned(group) {
        if (group.target == GroupTarget.SERVER) {
            for (let id of this.assignedServerGroupIds())
                if (id == group.id)
                    return true;
            return false;
        }
        else
            return group.id == this.assignedChannelGroup();
    }
    onDelete() {
        this.audioController.close();
        this.audioController = undefined;
    }
    calculateOnlineTime() {
        return Date.now() / 1000 - this.properties.client_lastconnected;
    }
    avatarId() {
        function str2ab(str) {
            let buf = new ArrayBuffer(str.length); // 2 bytes for each char
            let bufView = new Uint8Array(buf);
            for (let i = 0, strLen = str.length; i < strLen; i++) {
                bufView[i] = str.charCodeAt(i);
            }
            return buf;
        }
        try {
            let raw = atob(this.properties.client_unique_identifier);
            let input = hex.encode(str2ab(raw));
            let result = "";
            for (let index = 0; index < input.length; index++) {
                let c = input.charAt(index);
                let offset = 0;
                if (c >= '0' && c <= '9')
                    offset = c.charCodeAt(0) - '0'.charCodeAt(0);
                else if (c >= 'A' && c <= 'F')
                    offset = c.charCodeAt(0) - 'A'.charCodeAt(0) + 0x0A;
                else if (c >= 'a' && c <= 'f')
                    offset = c.charCodeAt(0) - 'a'.charCodeAt(0) + 0x0A;
                result += String.fromCharCode('a'.charCodeAt(0) + offset);
            }
            return result;
        }
        catch (e) { //invalid base 64 (like music bot etc)
            return undefined;
        }
    }
}
class LocalClientEntry extends ClientEntry {
    constructor(handle) {
        super(0, "local client");
        this.handle = handle;
    }
    showContextMenu(x, y, on_close = undefined) {
        const _self = this;
        spawn_context_menu(x, y, {
            name: _translations.eK_TI9oD || (_translations.eK_TI9oD = tr("<b>Change name</b>")),
            icon: "client-change_nickname",
            callback: () => _self.openRename(),
            type: MenuEntryType.ENTRY
        }, {
            name: _translations.KEy80hEG || (_translations.KEy80hEG = tr("Change description")),
            icon: "client-edit",
            callback: () => {
                createInputModal(_translations.G8lErIWa || (_translations.G8lErIWa = tr("Change own description")), _translations.wQmXisKZ || (_translations.wQmXisKZ = tr("New description:<br>")), text => true, result => {
                    if (result) {
                        console.log(_translations.u6lnuLeP || (_translations.u6lnuLeP = tr("Changing own description to %s")), result);
                        _self.channelTree.client.serverConnection.sendCommand("clientedit", {
                            clid: _self.clientId(),
                            client_description: result
                        });
                    }
                }, { width: 400, maxLength: 1024 }).open();
            },
            type: MenuEntryType.ENTRY
        }, MenuEntry.HR(), ...this.assignment_context(), MenuEntry.CLOSE(on_close));
    }
    initializeListener() {
        super.initializeListener();
        this.tag.find(".name").addClass("own_name");
        this.tag.dblclick(() => {
            if ($.isArray(this.channelTree.currently_selected)) { //Multiselect
                return;
            }
            this.openRename();
        });
    }
    openRename() {
        const _self = this;
        const elm = this.tag.find(".name");
        elm.attr("contenteditable", "true");
        elm.removeClass("own_name");
        elm.css("background-color", "white");
        elm.focus();
        _self.renaming = true;
        elm.keypress(function (e) {
            if (e.keyCode == 13 /* Enter */) {
                $(this).trigger("focusout");
                return false;
            }
        });
        elm.focusout(function (e) {
            if (!_self.renaming)
                return;
            _self.renaming = false;
            elm.css("background-color", "");
            elm.removeAttr("contenteditable");
            elm.addClass("own_name");
            let text = elm.text().toString();
            if (_self.clientNickName() == text)
                return;
            elm.text(_self.clientNickName());
            _self.handle.serverConnection.updateClient("client_nickname", text).then((e) => {
                chat.serverChat().appendMessage(_translations.LQ6rmzHC || (_translations.LQ6rmzHC = tr("Nickname successfully changed")));
            }).catch((e) => {
                chat.serverChat().appendError(_translations.ERhGr6ue || (_translations.ERhGr6ue = tr("Could not change nickname ({})")), e.extra_message);
                _self.openRename();
            });
        });
    }
}
class MusicClientProperties extends ClientProperties {
    constructor() {
        super(...arguments);
        this.player_state = 0;
        this.player_volume = 0;
    }
}
class MusicClientPlayerInfo {
    constructor() {
        this.bot_id = 0;
        this.player_state = 0;
        this.player_buffered_index = 0;
        this.player_replay_index = 0;
        this.player_max_index = 0;
        this.player_seekable = false;
        this.player_title = "";
        this.player_description = "";
        this.song_id = 0;
        this.song_url = "";
        this.song_invoker = 0;
        this.song_loaded = false;
        this.song_title = "";
        this.song_thumbnail = "";
        this.song_length = 0;
    }
}
class MusicClientEntry extends ClientEntry {
    constructor(clientId, clientName) {
        super(clientId, clientName, new MusicClientProperties());
        this._info_promise_age = 0;
    }
    get properties() {
        return this._properties;
    }
    showContextMenu(x, y, on_close = undefined) {
        spawn_context_menu(x, y, {
            name: _translations.gpWHLR2C || (_translations.gpWHLR2C = tr("<b>Change bot name</b>")),
            icon: "client-change_nickname",
            disabled: false,
            callback: () => {
                createInputModal(_translations.iitgrrBS || (_translations.iitgrrBS = tr("Change music bots nickname")), _translations.htxYG1XR || (_translations.htxYG1XR = tr("New nickname:<br>")), text => text.length >= 3 && text.length <= 31, result => {
                    if (result) {
                        this.channelTree.client.serverConnection.sendCommand("clientedit", {
                            clid: this.clientId(),
                            client_nickname: result
                        });
                    }
                }, { width: 400, maxLength: 255 }).open();
            },
            type: MenuEntryType.ENTRY
        }, {
            name: _translations.eMUoj0tz || (_translations.eMUoj0tz = tr("Change bot description")),
            icon: "client-edit",
            disabled: false,
            callback: () => {
                createInputModal(_translations.sEPz7X4u || (_translations.sEPz7X4u = tr("Change music bots description")), _translations.tJq1GcK3 || (_translations.tJq1GcK3 = tr("New description:<br>")), text => true, result => {
                    if (typeof (result) === 'string') {
                        this.channelTree.client.serverConnection.sendCommand("clientedit", {
                            clid: this.clientId(),
                            client_description: result
                        });
                    }
                }, { width: 400, maxLength: 255 }).open();
            },
            type: MenuEntryType.ENTRY
        }, {
            name: _translations.qjzy0woT || (_translations.qjzy0woT = tr("Open music panel")),
            icon: "client-edit",
            disabled: true,
            callback: () => { },
            type: MenuEntryType.ENTRY
        }, {
            name: _translations.YpJxTc2T || (_translations.YpJxTc2T = tr("Quick url replay")),
            icon: "client-edit",
            disabled: false,
            callback: () => {
                createInputModal(_translations.MrxRYfbX || (_translations.MrxRYfbX = tr("Please enter the URL")), _translations.udFKYkCe || (_translations.udFKYkCe = tr("URL:")), text => true, result => {
                    if (result) {
                        this.channelTree.client.serverConnection.sendCommand("musicbotqueueadd", {
                            bot_id: this.properties.client_database_id,
                            type: "yt",
                            url: result
                        }).catch(error => {
                            if (error instanceof CommandResult) {
                                error = error.extra_message || error.message;
                            }
                            //TODO tr
                            createErrorModal(_translations.HTWcLsYx || (_translations.HTWcLsYx = tr("Failed to replay url")), "Failed to enqueue url:<br>" + error).open();
                        });
                    }
                }, { width: 400, maxLength: 255 }).open();
            },
            type: MenuEntryType.ENTRY
        }, MenuEntry.HR(), ...super.assignment_context(), MenuEntry.HR(), {
            type: MenuEntryType.ENTRY,
            icon: "client-move_client_to_own_channel",
            name: _translations.hsgS53oj || (_translations.hsgS53oj = tr("Move client to your channel")),
            callback: () => {
                this.channelTree.client.serverConnection.sendCommand("clientmove", {
                    clid: this.clientId(),
                    cid: this.channelTree.client.getClient().currentChannel().getChannelId()
                });
            }
        }, {
            type: MenuEntryType.ENTRY,
            icon: "client-kick_channel",
            name: _translations.Ec3EKf54 || (_translations.Ec3EKf54 = tr("Kick client from channel")),
            callback: () => {
                createInputModal(_translations.PKPzV5Me || (_translations.PKPzV5Me = tr("Kick client from channel")), _translations.mPyVaqeG || (_translations.mPyVaqeG = tr("Kick reason:<br>")), text => true, result => {
                    if (result) {
                        console.log(_translations.PL8MpvqT || (_translations.PL8MpvqT = tr("Kicking client %o from channel with reason %o")), this.clientNickName(), result);
                        this.channelTree.client.serverConnection.sendCommand("clientkick", {
                            clid: this.clientId(),
                            reasonid: ViewReasonId.VREASON_CHANNEL_KICK,
                            reasonmsg: result
                        });
                    }
                }, { width: 400, maxLength: 255 }).open();
            }
        }, MenuEntry.HR(), {
            type: MenuEntryType.ENTRY,
            icon: "client-volume",
            name: _translations.gozLaEfL || (_translations.gozLaEfL = tr("Change Volume")),
            callback: () => {
                Modals.spawnChangeVolume(this.audioController.volume, volume => {
                    settings.changeServer("volume_client_" + this.clientUid(), volume);
                    this.audioController.volume = volume;
                    if (globalClient.selectInfo.currentSelected == this)
                        globalClient.selectInfo.update();
                });
            }
        }, MenuEntry.HR(), {
            name: _translations.dyguJnU5 || (_translations.dyguJnU5 = tr("Delete bot")),
            icon: "client-delete",
            disabled: false,
            callback: () => {
                const tag = $.spawn("div").append(MessageHelper.formatMessage(_translations.OCnxnsoS || (_translations.OCnxnsoS = tr("Do you really want to delete {0}")), this.createChatTag(false)));
                Modals.spawnYesNo(_translations.Fq9frpzi || (_translations.Fq9frpzi = tr("Are you sure?")), $.spawn("div").append(tag), result => {
                    if (result) {
                        this.channelTree.client.serverConnection.sendCommand("musicbotdelete", {
                            bot_id: this.properties.client_database_id
                        });
                    }
                });
            },
            type: MenuEntryType.ENTRY
        }, MenuEntry.CLOSE(on_close));
    }
    initializeListener() {
        super.initializeListener();
    }
    handlePlayerInfo(json) {
        if (json) {
            let info = JSON.map_to(new MusicClientPlayerInfo(), json);
            if (this._info_promise_resolve)
                this._info_promise_resolve(info);
            this._info_promise_reject = undefined;
        }
        if (this._info_promise) {
            if (this._info_promise_reject)
                this._info_promise_reject("timeout");
            this._info_promise = undefined;
            this._info_promise_age = undefined;
            this._info_promise_reject = undefined;
            this._info_promise_resolve = undefined;
        }
    }
    requestPlayerInfo(max_age = 1000) {
        if (this._info_promise && this._info_promise_age && Date.now() - max_age <= this._info_promise_age)
            return this._info_promise;
        this._info_promise_age = Date.now();
        this._info_promise = new Promise((resolve, reject) => {
            this._info_promise_reject = reject;
            this._info_promise_resolve = resolve;
        });
        this.channelTree.client.serverConnection.sendCommand("musicbotplayerinfo", { bot_id: this.properties.client_database_id });
        return this._info_promise;
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["c9256834f4dd0e6f21c223986766b356a3f9dcaacf0411f568a2bc4479f70f84"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["c9256834f4dd0e6f21c223986766b356a3f9dcaacf0411f568a2bc4479f70f84"] = "c9256834f4dd0e6f21c223986766b356a3f9dcaacf0411f568a2bc4479f70f84";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "NeBQGHok", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalCreateChannel.ts (7,31)" }, { name: "svtScIYg", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalCreateChannel.ts (7,52)" }, { name: "OSVsWpdd", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalCreateChannel.ts (22,35)" }, { name: "Y5KwZGet", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalCreateChannel.ts (25,31)" }, { name: "xcYbUTjO", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalCreateChannel.ts (49,56)" }, { name: "_gd7bMWS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalCreateChannel.ts (56,25)" }, { name: "NRwn_QLj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalCreateChannel.ts (174,25)" }, { name: "zIR4VyQ6", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalCreateChannel.ts (186,56)" }, { name: "cZWPqRim", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalCreateChannel.ts (193,33)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
var Modals;
(function (Modals) {
    function createChannelModal(channel, parent, permissions, callback) {
        let properties = {}; //The changes properties
        const modal = createModal({
            header: channel ? _translations.NeBQGHok || (_translations.NeBQGHok = tr("Edit channel")) : _translations.svtScIYg || (_translations.svtScIYg = tr("Create channel")),
            body: () => {
                let template = $("#tmpl_channel_edit").renderTag(channel ? channel.properties : {
                    channel_flag_maxfamilyclients_unlimited: true,
                    channel_flag_maxclients_unlimited: true
                });
                template = $.spawn("div").append(template);
                return template.tabify();
            },
            footer: () => {
                let footer = $.spawn("div");
                footer.addClass("modal-button-group");
                footer.css("margin", "5px");
                let buttonCancel = $.spawn("button");
                buttonCancel.text(_translations.OSVsWpdd || (_translations.OSVsWpdd = tr("Cancel"))).addClass("button_cancel");
                let buttonOk = $.spawn("button");
                buttonOk.text(_translations.Y5KwZGet || (_translations.Y5KwZGet = tr("Ok"))).addClass("button_ok");
                footer.append(buttonCancel);
                footer.append(buttonOk);
                return footer;
            },
            width: 500
        });
        applyGeneralListener(properties, modal.htmlTag.find(".general_properties"), modal.htmlTag.find(".button_ok"), !channel);
        applyStandardListener(properties, modal.htmlTag.find(".settings_standard"), modal.htmlTag.find(".button_ok"), parent, !channel);
        applyPermissionListener(properties, modal.htmlTag.find(".settings_permissions"), modal.htmlTag.find(".button_ok"), permissions, channel);
        applyAudioListener(properties, modal.htmlTag.find(".settings_audio"), modal.htmlTag.find(".button_ok"), channel);
        applyAdvancedListener(properties, modal.htmlTag.find(".settings_advanced"), modal.htmlTag.find(".button_ok"), channel);
        let updated = [];
        modal.htmlTag.find(".button_ok").click(() => {
            modal.htmlTag.find(".settings_permissions").find("input[permission]").each((index, _element) => {
                let element = $(_element);
                if (!element.prop("changed"))
                    return;
                let permission = permissions.resolveInfo(element.attr("permission"));
                if (!permission) {
                    log.error(LogCategory.PERMISSIONS, _translations.xcYbUTjO || (_translations.xcYbUTjO = tr("Failed to resolve channel permission for name %o")), element.attr("permission"));
                    element.prop("disabled", true);
                    return;
                }
                updated.push(new PermissionValue(permission, element.val()));
            });
            console.log(_translations._gd7bMWS || (_translations._gd7bMWS = tr("Updated permissions %o")), updated);
        }).click(() => {
            modal.close();
            callback(properties, updated); //First may create the channel
        });
        modal.htmlTag.find(".button_cancel").click(() => {
            modal.close();
            callback();
        });
        modal.open();
        if (!channel)
            modal.htmlTag.find(".channel_name").focus();
    }
    Modals.createChannelModal = createChannelModal;
    function applyGeneralListener(properties, tag, button, create) {
        let updateButton = () => {
            if (tag.find(".input_error").length == 0)
                button.removeAttr("disabled");
            else
                button.attr("disabled", "true");
        };
        tag.find(".channel_name").on('change keyup', function () {
            properties.channel_name = this.value;
            $(this).removeClass("input_error");
            if (this.value.length < 1 || this.value.length > 40)
                $(this).addClass("input_error");
            updateButton();
        }).prop("disabled", !create && !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_NAME).granted(1));
        tag.find(".channel_password").change(function () {
            properties.channel_flag_password = this.value.length != 0;
            if (properties.channel_flag_password)
                helpers.hashPassword(this.value).then(pass => properties.channel_password = pass);
            $(this).removeClass("input_error");
            if (!properties.channel_flag_password)
                if (globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_FORCE_PASSWORD).granted(1))
                    $(this).addClass("input_error");
            updateButton();
        }).prop("disabled", !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_WITH_PASSWORD : PermissionType.B_CHANNEL_MODIFY_PASSWORD).granted(1));
        tag.find(".channel_topic").change(function () {
            properties.channel_topic = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_WITH_TOPIC : PermissionType.B_CHANNEL_MODIFY_TOPIC).granted(1));
        tag.find(".channel_description").change(function () {
            properties.channel_description = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_WITH_DESCRIPTION : PermissionType.B_CHANNEL_MODIFY_DESCRIPTION).granted(1));
        if (create) {
            setTimeout(() => {
                tag.find(".channel_name").trigger("change");
                tag.find(".channel_password").trigger('change');
            }, 0);
        }
    }
    function applyStandardListener(properties, tag, button, parent, create) {
        tag.find("input[name=\"channel_type\"]").change(function () {
            switch (this.value) {
                case "semi":
                    properties.channel_flag_permanent = false;
                    properties.channel_flag_semi_permanent = true;
                    break;
                case "perm":
                    properties.channel_flag_permanent = true;
                    properties.channel_flag_semi_permanent = false;
                    break;
                default:
                    properties.channel_flag_permanent = false;
                    properties.channel_flag_semi_permanent = false;
                    break;
            }
        });
        tag.find("input[name=\"channel_type\"][value=\"temp\"]")
            .prop("disabled", !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_TEMPORARY : PermissionType.B_CHANNEL_MODIFY_MAKE_TEMPORARY).granted(1));
        tag.find("input[name=\"channel_type\"][value=\"semi\"]")
            .prop("disabled", !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_SEMI_PERMANENT : PermissionType.B_CHANNEL_MODIFY_MAKE_SEMI_PERMANENT).granted(1));
        tag.find("input[name=\"channel_type\"][value=\"perm\"]")
            .prop("disabled", !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_PERMANENT : PermissionType.B_CHANNEL_MODIFY_MAKE_PERMANENT).granted(1));
        if (create)
            tag.find("input[name=\"channel_type\"]:not(:disabled)").last().prop("checked", true).trigger('change');
        tag.find("input[name=\"channel_default\"]").change(function () {
            console.log(this.checked);
            properties.channel_flag_default = this.checked;
            let elements = tag.find("input[name=\"channel_type\"]");
            if (this.checked) {
                elements.prop("enabled", false);
                elements.prop("checked", false);
                tag.find("input[name=\"channel_type\"][value=\"perm\"]").prop("checked", true).trigger("change");
            }
            else
                elements.removeProp("enabled");
        }).prop("disabled", !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_PERMANENT : PermissionType.B_CHANNEL_MODIFY_MAKE_PERMANENT).granted(1) ||
            !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_WITH_DEFAULT : PermissionType.B_CHANNEL_MODIFY_MAKE_DEFAULT).granted(1));
        tag.find("input[name=\"talk_power\"]").change(function () {
            properties.channel_needed_talk_power = parseInt(this.value);
        }).prop("disabled", !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_WITH_NEEDED_TALK_POWER : PermissionType.B_CHANNEL_MODIFY_NEEDED_TALK_POWER).granted(1));
        let orderTag = tag.find(".order_id");
        for (let channel of (parent ? parent.siblings() : globalClient.channelTree.rootChannel()))
            $.spawn("option").attr("channelId", channel.channelId.toString()).text(channel.channelName()).appendTo(orderTag);
        orderTag.change(function () {
            let selected = $(this.options.item(this.selectedIndex));
            properties.channel_order = parseInt(selected.attr("channelId"));
        }).prop("disabled", !globalClient.permissions.neededPermission(create ? PermissionType.B_CHANNEL_CREATE_WITH_SORTORDER : PermissionType.B_CHANNEL_MODIFY_SORTORDER).granted(1));
        orderTag.find("option").last().prop("selected", true);
    }
    function applyPermissionListener(properties, tag, button, permissions, channel) {
        let apply_permissions = (channel_permissions) => {
            console.log(_translations.NRwn_QLj || (_translations.NRwn_QLj = tr("Got permissions: %o")), channel_permissions);
            let required_power = -2;
            for (let cperm of channel_permissions)
                if (cperm.type.name == PermissionType.I_CHANNEL_NEEDED_MODIFY_POWER) {
                    required_power = cperm.value;
                    return;
                }
            tag.find("input[permission]").each((index, _element) => {
                let element = $(_element);
                let permission = permissions.resolveInfo(element.attr("permission"));
                if (!permission) {
                    log.error(LogCategory.PERMISSIONS, _translations.zIR4VyQ6 || (_translations.zIR4VyQ6 = tr("Failed to resolve channel permission for name %o")), element.attr("permission"));
                    element.prop("disabled", true);
                    return;
                }
                let old_value = 0;
                element.on("click keyup", () => {
                    console.log(_translations.cZWPqRim || (_translations.cZWPqRim = tr("Permission triggered! %o")), element.val() != old_value);
                    element.prop("changed", element.val() != old_value);
                });
                for (let cperm of channel_permissions)
                    if (cperm.type == permission) {
                        element.val(old_value = cperm.value);
                        return;
                    }
                element.val(0);
            });
            if (!permissions.neededPermission(PermissionType.I_CHANNEL_MODIFY_POWER).granted(required_power, false)) {
                tag.find("input[permission]").prop("enabled", false); //No permissions
            }
        };
        if (channel) {
            permissions.requestChannelPermissions(channel.getChannelId()).then(apply_permissions).catch((error) => {
                tag.find("input[permission]").prop("enabled", false);
                console.log(error);
            });
        }
        else
            apply_permissions([]);
    }
    function applyAudioListener(properties, tag, button, channel) {
        let update_template = () => {
            let codec = properties.channel_codec;
            if (!codec && channel)
                codec = channel.properties.channel_codec;
            if (!codec)
                return;
            let quality = properties.channel_codec_quality;
            if (!quality && channel)
                quality = channel.properties.channel_codec_quality;
            if (!quality)
                return;
            if (codec == 4 && quality == 4)
                tag.find("input[name=\"voice_template\"][value=\"voice_mobile\"]").prop("checked", true);
            else if (codec == 4 && quality == 6)
                tag.find("input[name=\"voice_template\"][value=\"voice_desktop\"]").prop("checked", true);
            else if (codec == 5 && quality == 6)
                tag.find("input[name=\"voice_template\"][value=\"music\"]").prop("checked", true);
            else
                tag.find("input[name=\"voice_template\"][value=\"custom\"]").prop("checked", true);
        };
        let change_codec = codec => {
            if (properties.channel_codec == codec)
                return;
            tag.find(".voice_codec option").prop("selected", false).eq(codec).prop("selected", true);
            properties.channel_codec = codec;
            update_template();
        };
        let quality_slider = tag.find(".voice_quality_slider");
        let quality_number = tag.find(".voice_quality_number");
        let change_quality = (quality) => {
            if (properties.channel_codec_quality == quality)
                return;
            properties.channel_codec_quality = quality;
            if (quality_slider.val() != quality)
                quality_slider.val(quality);
            if (parseInt(quality_number.text()) != quality)
                quality_number.text(quality);
            update_template();
        };
        tag.find("input[name=\"voice_template\"]").change(function () {
            switch (this.value) {
                case "custom":
                    break;
                case "music":
                    change_codec(5);
                    change_quality(6);
                    break;
                case "voice_desktop":
                    change_codec(4);
                    change_quality(6);
                    break;
                case "voice_mobile":
                    change_codec(4);
                    change_quality(4);
                    break;
            }
        });
        tag.find("input[name=\"voice_template\"][value=\"voice_mobile\"]")
            .prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_CODEC_OPUSVOICE).granted(1));
        tag.find("input[name=\"voice_template\"][value=\"voice_desktop\"]")
            .prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_CODEC_OPUSVOICE).granted(1));
        tag.find("input[name=\"voice_template\"][value=\"music\"]")
            .prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_CODEC_OPUSMUSIC).granted(1));
        let codecs = tag.find(".voice_codec option");
        codecs.eq(0).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_CODEC_SPEEX8).granted(1));
        codecs.eq(1).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_CODEC_SPEEX16).granted(1));
        codecs.eq(2).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_CODEC_SPEEX32).granted(1));
        codecs.eq(3).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_CODEC_CELTMONO48).granted(1));
        codecs.eq(4).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_CODEC_OPUSVOICE).granted(1));
        codecs.eq(5).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_CODEC_OPUSMUSIC).granted(1));
        tag.find(".voice_codec").change(function () {
            if ($(this.item(this.selectedIndex)).prop("disabled"))
                return false;
            change_codec(this.selectedIndex);
        });
        if (!channel) {
            change_codec(4);
            change_quality(6);
        }
        else {
            change_codec(channel.properties.channel_codec);
            change_quality(channel.properties.channel_codec_quality);
        }
        update_template();
        quality_slider.on('input', event => change_quality(parseInt(quality_slider.val())));
    }
    function applyAdvancedListener(properties, tag, button, channel) {
        tag.find(".channel_name_phonetic").change(function () {
            properties.channel_topic = this.value;
        });
        tag.find(".channel_delete_delay").change(function () {
            properties.channel_delete_delay = parseInt(this.value);
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_TEMP_DELETE_DELAY).granted(1));
        tag.find(".channel_codec_is_unencrypted").change(function () {
            properties.channel_codec_is_unencrypted = parseInt(this.value) == 0;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_MODIFY_MAKE_CODEC_ENCRYPTED).granted(1));
        {
            let tag_infinity = tag.find("input[name=\"max_users\"][value=\"infinity\"]");
            let tag_limited = tag.find("input[name=\"max_users\"][value=\"limited\"]");
            let tag_limited_value = tag.find(".channel_maxclients");
            if (!globalClient.permissions.neededPermission(!channel ? PermissionType.B_CHANNEL_CREATE_WITH_MAXCLIENTS : PermissionType.B_CHANNEL_MODIFY_MAXCLIENTS).granted(1)) {
                tag_infinity.prop("disabled", true);
                tag_limited.prop("disabled", true);
                tag_limited_value.prop("disabled", true);
            }
            else {
                tag.find("input[name=\"max_users\"]").change(function () {
                    console.log(this.value);
                    let infinity = this.value == "infinity";
                    tag_limited_value.prop("disabled", infinity);
                    properties.channel_flag_maxclients_unlimited = infinity;
                });
                tag_limited_value.change(event => properties.channel_maxclients = parseInt(tag_limited_value.val()));
                tag.find("input[name=\"max_users\"]:checked").trigger('change');
            }
        }
        {
            let tag_inherited = tag.find("input[name=\"max_users_family\"][value=\"inherited\"]");
            let tag_infinity = tag.find("input[name=\"max_users_family\"][value=\"infinity\"]");
            let tag_limited = tag.find("input[name=\"max_users_family\"][value=\"limited\"]");
            let tag_limited_value = tag.find(".channel_maxfamilyclients");
            if (!globalClient.permissions.neededPermission(!channel ? PermissionType.B_CHANNEL_CREATE_WITH_MAXCLIENTS : PermissionType.B_CHANNEL_MODIFY_MAXCLIENTS).granted(1)) {
                tag_inherited.prop("disabled", true);
                tag_infinity.prop("disabled", true);
                tag_limited.prop("disabled", true);
                tag_limited_value.prop("disabled", true);
            }
            else {
                tag.find("input[name=\"max_users_family\"]").change(function () {
                    console.log(this.value);
                    tag_limited_value.prop("disabled", this.value != "limited");
                    properties.channel_flag_maxfamilyclients_unlimited = this.value == "infinity";
                    properties.channel_flag_maxfamilyclients_inherited = this.value == "inherited";
                });
                tag_limited_value.change(event => properties.channel_maxfamilyclients = parseInt(tag_limited_value.val()));
                tag.find("input[name=\"max_users_family\"]:checked").trigger('change');
            }
        }
    }
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["1989de3bf543787a8a5c1f5b59838523935dc11b49c93064bf2a113c23a7cfa2"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["1989de3bf543787a8a5c1f5b59838523935dc11b49c93064bf2a113c23a7cfa2"] = "1989de3bf543787a8a5c1f5b59838523935dc11b49c93064bf2a113c23a7cfa2";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "K5C5ZsEy", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (76,23)" }, { name: "HtLNzoai", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (211,27)" }, { name: "juaS12U0", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (417,21)" }, { name: "WeNTTHws", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (420,21)" }, { name: "q8GnpAE2", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (425,21)" }, { name: "CXmUH6xQ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (431,23)" }, { name: "YuT5V2ZW", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (433,38)" }, { name: "b8n99v6q", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (433,58)" }, { name: "Qb8tto71", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (449,19)" }, { name: "Vz9RUizt", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (464,23)" }, { name: "wryzmscb", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (466,38)" }, { name: "CmuqCfJt", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (466,71)" }, { name: "zihZLVdJ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (484,27)" }, { name: "pf4z21LT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (486,42)" }, { name: "NQ9k_fS1", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (486,74)" }, { name: "bdg8RkST", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (501,27)" }, { name: "AyWB2F05", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (520,27)" }, { name: "IFNmqXqe", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (526,90)" }, { name: "M3rXbvdc", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (528,43)" }, { name: "tPFBbe0Q", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (580,44)" }, { name: "_sr2lNV9", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (584,52)" }, { name: "Fc9TPpaF", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/view.ts (604,49)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../voice/VoiceHandler.ts" />
/// <reference path="../client.ts" />
/// <reference path="../contextMenu.ts" />
/// <reference path="../proto.ts" />
/// <reference path="channel.ts" />
/// <reference path="client.ts" />
/// <reference path="modal/ModalCreateChannel.ts" />
class ChannelTree {
    constructor(client, htmlTree) {
        this.currently_selected = undefined;
        this.currently_selected_context_callback = undefined;
        document.addEventListener("touchstart", function () { }, true);
        this.client = client;
        this.htmlTree = htmlTree;
        this.client_mover = new ClientMover(this);
        this.reset();
        if (!settings.static(Settings.KEY_DISABLE_CONTEXT_MENU, false)) {
            this.htmlTree.parent().on("contextmenu", (event) => {
                if (event.isDefaultPrevented())
                    return;
                for (const element of document.elementsFromPoint(event.pageX, event.pageY))
                    if (element.classList.contains("channelLine") || element.classList.contains("client"))
                        return;
                event.preventDefault();
                if ($.isArray(this.currently_selected)) { //Multiselect
                    (this.currently_selected_context_callback || ((_) => null))(event);
                }
                else {
                    this.onSelect(undefined);
                    this.showContextMenu(event.pageX, event.pageY);
                }
            });
        }
        this.htmlTree.on('resize', this.handle_resized.bind(this));
        /* TODO release these events again when ChannelTree get deinitialized */
        $(document).on('click', event => {
            if (this.selected_event != event.originalEvent)
                this.selected_event = undefined;
        });
        $(document).on('keydown', this.handle_key_press.bind(this));
        this.htmlTree.on('click', event => {
            {
                this.selected_event = event.originalEvent;
            }
        });
    }
    showContextMenu(x, y, on_close = undefined) {
        let channelCreate = this.client.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_TEMPORARY).granted(1) ||
            this.client.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_SEMI_PERMANENT).granted(1) ||
            this.client.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_PERMANENT).granted(1);
        spawn_context_menu(x, y, {
            type: MenuEntryType.ENTRY,
            icon: "client-channel_create",
            name: _translations.K5C5ZsEy || (_translations.K5C5ZsEy = tr("Create channel")),
            invalidPermission: !channelCreate,
            callback: () => this.spawnCreateChannel()
        }, MenuEntry.CLOSE(on_close));
    }
    initialiseHead(serverName, address) {
        this.server = new ServerEntry(this, serverName, address);
        this.server.htmlTag.appendTo(this.htmlTree);
        this.server.initializeListener();
    }
    __deleteAnimation(element) {
        let tag = element instanceof ChannelEntry ? element.rootTag() : element.tag;
        this.htmlTree.find(tag).fadeOut("slow", () => {
            tag.remove();
            if (element instanceof ChannelEntry) {
                if (element.parent_channel())
                    element.parent_channel().adjustSize(true);
            }
            else if (element instanceof ClientEntry) {
                element.currentChannel().adjustSize(true);
            }
        });
    }
    rootChannel() {
        return this.channels.filter(e => e.parent == undefined);
    }
    deleteChannel(channel) {
        const _this = this;
        for (let index = 0; index < this.channels.length; index++) {
            let entry = this.channels[index];
            let currentEntry = this.channels[index];
            while (currentEntry != undefined && currentEntry != null) {
                if (currentEntry == channel) {
                    _this.channels.remove(entry);
                    _this.__deleteAnimation(entry);
                    entry.channelTree = null;
                    index--;
                    break;
                }
                else
                    currentEntry = currentEntry.parent_channel();
            }
        }
        this.channels.remove(channel);
        this.__deleteAnimation(channel);
        channel.channelTree = null;
        if (channel.channel_previous)
            channel.channel_previous.channel_next = channel.channel_next;
        if (channel.channel_next)
            channel.channel_next.channel_previous = channel.channel_previous;
        if (channel == this.channel_first)
            this.channel_first = channel.channel_next;
        if (channel == this.channel_last)
            this.channel_last = channel.channel_previous;
    }
    insertChannel(channel) {
        channel.channelTree = this;
        this.channels.push(channel);
        let elm = undefined;
        let tag = this.htmlTree;
        let previous_channel = null;
        if (channel.hasParent()) {
            let parent = channel.parent_channel();
            let siblings = parent.siblings();
            if (siblings.length == 0) {
                elm = parent.rootTag();
                previous_channel = null;
            }
            else {
                previous_channel = siblings.last();
                elm = previous_channel.tag;
            }
            tag = parent.siblingTag();
        }
        else {
            previous_channel = this.channel_last;
            if (!this.channel_last)
                this.channel_last = channel;
            if (!this.channel_first)
                this.channel_first = channel;
        }
        channel.channel_previous = previous_channel;
        channel.channel_next = undefined;
        if (previous_channel) {
            channel.channel_next = previous_channel.channel_next;
            previous_channel.channel_next = channel;
            if (channel.channel_next)
                channel.channel_next.channel_previous = channel;
        }
        let entry = channel.rootTag().css({ display: "none" }).fadeIn("slow");
        entry.appendTo(tag);
        channel.originalHeight = entry.outerHeight(false);
        if (elm != undefined)
            elm.after(entry);
        if (channel.channel_previous == channel) /* shall never happen */
            channel.channel_previous = undefined;
        if (channel.channel_next == channel) /* shall never happen */
            channel.channel_next = undefined;
        channel.adjustSize(true);
        channel.initializeListener();
    }
    findChannel(channelId) {
        for (let index = 0; index < this.channels.length; index++)
            if (this.channels[index].getChannelId() == channelId)
                return this.channels[index];
        return undefined;
    }
    find_channel_by_name(name, parent, force_parent = true) {
        for (let index = 0; index < this.channels.length; index++)
            if (this.channels[index].channelName() == name && (!force_parent || parent == this.channels[index].parent))
                return this.channels[index];
        return undefined;
    }
    moveChannel(channel, channel_previus, parent) {
        if (channel_previus != null && channel_previus.parent != parent) {
            console.error(_translations.HtLNzoai || (_translations.HtLNzoai = tr("Invalid channel move (different parents! (%o|%o)")), channel_previus.parent, parent);
            return;
        }
        if (channel.channel_next)
            channel.channel_next.channel_previous = channel.channel_previous;
        if (channel.channel_previous)
            channel.channel_previous.channel_next = channel.channel_next;
        if (channel == this.channel_last)
            this.channel_last = channel.channel_previous;
        if (channel == this.channel_first)
            this.channel_first = channel.channel_next;
        let oldParent = channel.parent_channel();
        channel.channel_next = undefined;
        channel.channel_previous = channel_previus;
        channel.parent = parent;
        if (channel_previus) {
            if (channel_previus == this.channel_last)
                this.channel_last = channel;
            channel.channel_next = channel_previus.channel_next;
            channel_previus.channel_next = channel;
            channel_previus.rootTag().after(channel.rootTag());
            if (channel.channel_next)
                channel.channel_next.channel_previous = channel;
        }
        else {
            if (parent) {
                let siblings = parent.siblings();
                if (siblings.length <= 1) { //Self should be already in there
                    let left = channel.rootTag();
                    left.appendTo(parent.siblingTag());
                    channel.channel_next = undefined;
                }
                else {
                    channel.channel_previous = siblings[siblings.length - 2];
                    channel.channel_previous.rootTag().after(channel.rootTag());
                    channel.channel_next = channel.channel_previous.channel_next;
                    channel.channel_next.channel_previous = channel;
                    channel.channel_previous.channel_next = channel;
                }
            }
            else {
                this.htmlTree.find(".server").after(channel.rootTag());
                channel.channel_next = this.channel_first;
                if (this.channel_first)
                    this.channel_first.channel_previous = channel;
                this.channel_first = channel;
            }
        }
        if (channel.channel_previous == channel) /* shall never happen */
            channel.channel_previous = undefined;
        if (channel.channel_next == channel) /* shall never happen */
            channel.channel_next = undefined;
        if (oldParent) {
            oldParent.adjustSize();
        }
        if (channel) {
            channel.adjustSize();
        }
    }
    deleteClient(client) {
        this.clients.remove(client);
        this.__deleteAnimation(client);
        client.onDelete();
    }
    insertClient(client, channel) {
        let newClient = this.findClient(client.clientId());
        if (newClient)
            client = newClient; //Got new client :)
        else
            this.clients.push(client);
        if (!this._show_queries && client.properties.client_type == ClientType.CLIENT_QUERY)
            client.tag.hide();
        client.channelTree = this;
        client["_channel"] = channel;
        let tag = client.tag.css({ display: "none" }).fadeIn("slow");
        tag.appendTo(channel.clientTag());
        channel.adjustSize(true);
        client.currentChannel().reorderClients();
        channel.updateChannelTypeIcon();
        return client;
    }
    registerClient(client) {
        this.clients.push(client);
        client.channelTree = this;
    }
    reorderAllClients() {
        for (let channel of this.channels)
            channel.reorderClients();
    }
    moveClient(client, channel) {
        let oldChannel = client.currentChannel();
        client["_channel"] = channel;
        let tag = client.tag;
        tag.detach();
        tag.appendTo(client.currentChannel().clientTag());
        if (oldChannel) {
            oldChannel.adjustSize();
            oldChannel.updateChannelTypeIcon();
        }
        if (client.currentChannel()) {
            client.currentChannel().adjustSize();
            client.currentChannel().reorderClients();
            client.currentChannel().updateChannelTypeIcon();
        }
        client.updateClientStatusIcons();
    }
    findClient(clientId) {
        for (let index = 0; index < this.clients.length; index++) {
            if (this.clients[index].clientId() == clientId)
                return this.clients[index];
        }
        return undefined;
    }
    find_client_by_dbid(client_dbid) {
        for (let index = 0; index < this.clients.length; index++) {
            if (this.clients[index].properties.client_database_id == client_dbid)
                return this.clients[index];
        }
        return undefined;
    }
    static same_selected_type(a, b) {
        if (a instanceof ChannelEntry)
            return b instanceof ChannelEntry;
        if (a instanceof ClientEntry)
            return b instanceof ClientEntry;
        if (a instanceof ServerEntry)
            return b instanceof ServerEntry;
        return a == b;
    }
    onSelect(entry, enforce_single) {
        if (this.currently_selected && ppt.key_pressed(ppt.SpecialKey.SHIFT) && entry instanceof ClientEntry) { //Currently we're only supporting client multiselects :D
            if (!entry)
                return; //Nowhere
            if ($.isArray(this.currently_selected)) {
                if (!ChannelTree.same_selected_type(this.currently_selected[0], entry))
                    return; //Not the same type
            }
            else if (ChannelTree.same_selected_type(this.currently_selected, entry)) {
                this.currently_selected = [this.currently_selected];
            }
            if (entry instanceof ChannelEntry)
                this.currently_selected_context_callback = this.callback_multiselect_channel.bind(this);
            if (entry instanceof ClientEntry)
                this.currently_selected_context_callback = this.callback_multiselect_client.bind(this);
        }
        else
            this.currently_selected = undefined;
        if (!$.isArray(this.currently_selected) || enforce_single) {
            this.currently_selected = entry;
            this.htmlTree.find(".selected").each(function (idx, e) {
                $(e).removeClass("selected");
            });
        }
        else {
            for (const e of this.currently_selected)
                if (e == entry) {
                    this.currently_selected.remove(e);
                    if (entry instanceof ChannelEntry)
                        entry.rootTag().find("> .channelLine").removeClass("selected");
                    else if (entry instanceof ClientEntry)
                        entry.tag.removeClass("selected");
                    else if (entry instanceof ServerEntry)
                        entry.htmlTag.removeClass("selected");
                    if (this.currently_selected.length == 1)
                        this.currently_selected = this.currently_selected[0];
                    else if (this.currently_selected.length == 0)
                        this.currently_selected = undefined;
                    //Already selected
                    return;
                }
            this.currently_selected.push(entry);
        }
        if (entry instanceof ChannelEntry)
            entry.rootTag().find("> .channelLine").addClass("selected");
        else if (entry instanceof ClientEntry)
            entry.tag.addClass("selected");
        else if (entry instanceof ServerEntry)
            entry.htmlTag.addClass("selected");
        this.client.selectInfo.setCurrentSelected($.isArray(this.currently_selected) ? undefined : entry);
    }
    callback_multiselect_channel(event) {
        console.log(_translations.juaS12U0 || (_translations.juaS12U0 = tr("Multiselect channel")));
    }
    callback_multiselect_client(event) {
        console.log(_translations.WeNTTHws || (_translations.WeNTTHws = tr("Multiselect client")));
        const clients = this.currently_selected;
        const music_only = clients.map(e => e instanceof MusicClientEntry ? 0 : 1).reduce((a, b) => a + b, 0) == 0;
        const music_entry = clients.map(e => e instanceof MusicClientEntry ? 1 : 0).reduce((a, b) => a + b, 0) > 0;
        const local_client = clients.map(e => e instanceof LocalClientEntry ? 1 : 0).reduce((a, b) => a + b, 0) > 0;
        console.log(_translations.q8GnpAE2 || (_translations.q8GnpAE2 = tr("Music only: %o | Container music: %o | Container local: %o")), music_entry, music_entry, local_client);
        let entries = [];
        if (!music_entry && !local_client) { //Music bots or local client cant be poked
            entries.push({
                type: MenuEntryType.ENTRY,
                icon: "client-poke",
                name: _translations.CXmUH6xQ || (_translations.CXmUH6xQ = tr("Poke clients")),
                callback: () => {
                    createInputModal(_translations.YuT5V2ZW || (_translations.YuT5V2ZW = tr("Poke clients")), _translations.b8n99v6q || (_translations.b8n99v6q = tr("Poke message:<br>")), text => true, result => {
                        if (typeof (result) === "string") {
                            for (const client of this.currently_selected)
                                this.client.serverConnection.sendCommand("clientpoke", {
                                    clid: client.clientId(),
                                    msg: result
                                });
                        }
                    }, { width: 400, maxLength: 512 }).open();
                }
            });
        }
        entries.push({
            type: MenuEntryType.ENTRY,
            icon: "client-move_client_to_own_channel",
            name: _translations.Qb8tto71 || (_translations.Qb8tto71 = tr("Move clients to your channel")),
            callback: () => {
                const target = this.client.getClient().currentChannel().getChannelId();
                for (const client of clients)
                    this.client.serverConnection.sendCommand("clientmove", {
                        clid: client.clientId(),
                        cid: target
                    });
            }
        });
        if (!local_client) { //local client cant be kicked and/or banned or kicked
            entries.push(MenuEntry.HR());
            entries.push({
                type: MenuEntryType.ENTRY,
                icon: "client-kick_channel",
                name: _translations.Vz9RUizt || (_translations.Vz9RUizt = tr("Kick clients from channel")),
                callback: () => {
                    createInputModal(_translations.wryzmscb || (_translations.wryzmscb = tr("Kick clients from channel")), _translations.CmuqCfJt || (_translations.CmuqCfJt = tr("Kick reason:<br>")), text => true, result => {
                        if (result) {
                            for (const client of clients)
                                this.client.serverConnection.sendCommand("clientkick", {
                                    clid: client.clientId(),
                                    reasonid: ViewReasonId.VREASON_CHANNEL_KICK,
                                    reasonmsg: result
                                });
                        }
                    }, { width: 400, maxLength: 255 }).open();
                }
            });
            if (!music_entry) { //Music bots  cant be banned or kicked
                entries.push({
                    type: MenuEntryType.ENTRY,
                    icon: "client-kick_server",
                    name: _translations.zihZLVdJ || (_translations.zihZLVdJ = tr("Kick clients fom server")),
                    callback: () => {
                        createInputModal(_translations.pf4z21LT || (_translations.pf4z21LT = tr("Kick clients from server")), _translations.NQ9k_fS1 || (_translations.NQ9k_fS1 = tr("Kick reason:<br>")), text => true, result => {
                            if (result) {
                                for (const client of clients)
                                    this.client.serverConnection.sendCommand("clientkick", {
                                        clid: client.clientId(),
                                        reasonid: ViewReasonId.VREASON_SERVER_KICK,
                                        reasonmsg: result
                                    });
                            }
                        }, { width: 400, maxLength: 255 }).open();
                    }
                }, {
                    type: MenuEntryType.ENTRY,
                    icon: "client-ban_client",
                    name: _translations.bdg8RkST || (_translations.bdg8RkST = tr("Ban clients")),
                    invalidPermission: !this.client.permissions.neededPermission(PermissionType.I_CLIENT_BAN_MAX_BANTIME).granted(1),
                    callback: () => {
                        Modals.spawnBanClient((clients).map(entry => entry.clientNickName()), (data) => {
                            for (const client of clients)
                                this.client.serverConnection.sendCommand("banclient", {
                                    uid: client.properties.client_unique_identifier,
                                    banreason: data.reason,
                                    time: data.length
                                }, [data.no_ip ? "no-ip" : "", data.no_hwid ? "no-hardware-id" : "", data.no_name ? "no-nickname" : ""]).then(() => {
                                    sound.play(Sound.USER_BANNED);
                                });
                        });
                    }
                });
            }
            if (music_only) {
                entries.push(MenuEntry.HR());
                entries.push({
                    name: _translations.AyWB2F05 || (_translations.AyWB2F05 = tr("Delete bots")),
                    icon: "client-delete",
                    disabled: false,
                    callback: () => {
                        const param_string = clients.map((_, index) => "{" + index + "}").join(', ');
                        const param_values = clients.map(client => client.createChatTag(true));
                        const tag = $.spawn("div").append(...MessageHelper.formatMessage((_translations.IFNmqXqe || (_translations.IFNmqXqe = tr("Do you really want to delete "))) + param_string, ...param_values));
                        const tag_container = $.spawn("div").append(tag);
                        Modals.spawnYesNo(_translations.M3rXbvdc || (_translations.M3rXbvdc = tr("Are you sure?")), tag_container, result => {
                            if (result) {
                                for (const client of clients)
                                    this.client.serverConnection.sendCommand("musicbotdelete", {
                                        botid: client.properties.client_database_id
                                    });
                            }
                        });
                    },
                    type: MenuEntryType.ENTRY
                });
            }
        }
        spawn_context_menu(event.pageX, event.pageY, ...entries);
    }
    clientsByGroup(group) {
        let result = [];
        for (let client of this.clients) {
            if (client.groupAssigned(group))
                result.push(client);
        }
        return result;
    }
    clientsByChannel(channel) {
        let result = [];
        for (let client of this.clients) {
            if (client.currentChannel() == channel)
                result.push(client);
        }
        return result;
    }
    reset() {
        this.server = null;
        this.clients = [];
        this.channels = [];
        this.htmlTree.children().detach(); //Do not remove the listener!
        this.channel_first = undefined;
        this.channel_last = undefined;
    }
    spawnCreateChannel(parent) {
        Modals.createChannelModal(undefined, parent, this.client.permissions, (properties, permissions) => {
            if (!properties)
                return;
            properties["cpid"] = parent ? parent.channelId : 0;
            log.debug(LogCategory.CHANNEL, _translations.tPFBbe0Q || (_translations.tPFBbe0Q = tr("Creating a new channel.\nProperties: %o\nPermissions: %o")), properties);
            this.client.serverConnection.sendCommand("channelcreate", properties).then(() => {
                let channel = this.find_channel_by_name(properties.channel_name, parent, true);
                if (!channel) {
                    log.error(LogCategory.CHANNEL, _translations._sr2lNV9 || (_translations._sr2lNV9 = tr("Failed to resolve channel after creation. Could not apply permissions!")));
                    return;
                }
                if (permissions && permissions.length > 0) {
                    let perms = [];
                    for (let perm of permissions) {
                        perms.push({
                            permvalue: perm.value,
                            permnegated: false,
                            permskip: false,
                            permid: perm.type.id
                        });
                    }
                    perms[0]["cid"] = channel.channelId;
                    return this.client.serverConnection.sendCommand("channeladdperm", perms, ["continueonerror"]).then(() => new Promise(resolve => { resolve(channel); }));
                }
                return new Promise(resolve => { resolve(channel); });
            }).then(channel => {
                chat.serverChat().appendMessage(_translations.Fc9TPpaF || (_translations.Fc9TPpaF = tr("Channel {} successfully created!")), true, channel.createChatTag());
                sound.play(Sound.CHANNEL_CREATED);
            });
        });
    }
    handle_resized() {
        for (let channel of this.channels)
            channel.handle_frame_resized();
    }
    select_next_channel(channel, select_client) {
        if (select_client) {
            const clients = channel.clients_ordered();
            if (clients.length > 0) {
                this.onSelect(clients[0], true);
                return;
            }
        }
        const children = channel.siblings();
        if (children.length > 0) {
            this.onSelect(children[0], true);
            return;
        }
        const next = channel.channel_next;
        if (next) {
            this.onSelect(next, true);
            return;
        }
        let parent = channel.parent_channel();
        while (parent) {
            const p_next = parent.channel_next;
            if (p_next) {
                this.onSelect(p_next, true);
                return;
            }
            parent = parent.parent_channel();
        }
    }
    handle_key_press(event) {
        if (!this.selected_event || !this.currently_selected || $.isArray(this.currently_selected))
            return;
        if (event.keyCode == 38 /* ArrowUp */) {
            event.preventDefault();
            if (this.currently_selected instanceof ChannelEntry) {
                let previous = this.currently_selected.channel_previous;
                if (previous) {
                    while (true) {
                        const siblings = previous.siblings();
                        if (siblings.length == 0)
                            break;
                        previous = siblings.last();
                    }
                    const clients = previous.clients_ordered();
                    if (clients.length > 0) {
                        this.onSelect(clients.last(), true);
                        return;
                    }
                    else {
                        this.onSelect(previous, true);
                        return;
                    }
                }
                else if (this.currently_selected.hasParent()) {
                    const channel = this.currently_selected.parent_channel();
                    const clients = channel.clients_ordered();
                    if (clients.length > 0) {
                        this.onSelect(clients.last(), true);
                        return;
                    }
                    else {
                        this.onSelect(channel, true);
                        return;
                    }
                }
                else
                    this.onSelect(this.server, true);
            }
            else if (this.currently_selected instanceof ClientEntry) {
                const channel = this.currently_selected.currentChannel();
                const clients = channel.clients_ordered();
                const index = clients.indexOf(this.currently_selected);
                if (index > 0) {
                    this.onSelect(clients[index - 1], true);
                    return;
                }
                this.onSelect(channel, true);
                return;
            }
        }
        else if (event.keyCode == 40 /* ArrowDown */) {
            event.preventDefault();
            if (this.currently_selected instanceof ChannelEntry) {
                this.select_next_channel(this.currently_selected, true);
            }
            else if (this.currently_selected instanceof ClientEntry) {
                const channel = this.currently_selected.currentChannel();
                const clients = channel.clients_ordered();
                const index = clients.indexOf(this.currently_selected);
                if (index + 1 < clients.length) {
                    this.onSelect(clients[index + 1], true);
                    return;
                }
                this.select_next_channel(channel, false);
            }
            else if (this.currently_selected instanceof ServerEntry)
                this.onSelect(this.channel_first, true);
        }
        else if (event.keyCode == 13 /* Enter */) {
            if (this.currently_selected instanceof ChannelEntry) {
                this.currently_selected.joinChannel();
            }
        }
    }
    toggle_server_queries(flag) {
        if (this._show_queries == flag)
            return;
        this._show_queries = flag;
        //FIXME resize channels
        const channels = [];
        for (const client of this.clients)
            if (client.properties.client_type == ClientType.CLIENT_QUERY) {
                if (this._show_queries)
                    client.tag.show();
                else
                    client.tag.hide();
                if (channels.indexOf(client.currentChannel()) == -1)
                    channels.push(client.currentChannel());
            }
        for (const channel of channels)
            channel.adjustSize();
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["b582d407ddd8509971d52fc3825eab949d1d92ca25e6826d7eabb512c30c6e3c"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["b582d407ddd8509971d52fc3825eab949d1d92ca25e6826d7eabb512c30c6e3c"] = "b582d407ddd8509971d52fc3825eab949d1d92ca25e6826d7eabb512c30c6e3c";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "Bs6gchUN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (122,21)" }, { name: "OIVx7K6I", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (125,26)" }, { name: "qQPwLXhN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (141,29)" }, { name: "pgPiLKgs", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (161,37)" }, { name: "dAuUrGsC", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (163,41)" }, { name: "p764TLam", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (167,43)" }, { name: "Nk_23DCt", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (187,39)" }, { name: "cEpwCdTd", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (194,35)" }, { name: "a020BAuv", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (203,25)" }, { name: "i72Ajplb", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/sound/Sounds.ts (210,34)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var Sound;
(function (Sound) {
    Sound["SOUND_TEST"] = "sound.test";
    Sound["SOUND_EGG"] = "sound.egg";
    Sound["AWAY_ACTIVATED"] = "away_activated";
    Sound["AWAY_DEACTIVATED"] = "away_deactivated";
    Sound["CONNECTION_CONNECTED"] = "connection.connected";
    Sound["CONNECTION_DISCONNECTED"] = "connection.disconnected";
    Sound["CONNECTION_BANNED"] = "connection.banned";
    Sound["CONNECTION_DISCONNECTED_TIMEOUT"] = "connection.disconnected.timeout";
    Sound["CONNECTION_REFUSED"] = "connection.refused";
    Sound["SERVER_EDITED"] = "server.edited";
    Sound["SERVER_EDITED_SELF"] = "server.edited.self";
    Sound["SERVER_KICKED"] = "server.kicked";
    Sound["CHANNEL_CREATED"] = "channel.created";
    Sound["CHANNEL_MOVED"] = "channel.moved";
    Sound["CHANNEL_EDITED"] = "channel.edited";
    Sound["CHANNEL_EDITED_SELF"] = "channel.edited.self";
    Sound["CHANNEL_DELETED"] = "channel.deleted";
    Sound["CHANNEL_JOINED"] = "channel.joined";
    Sound["CHANNEL_KICKED"] = "channel.kicked";
    Sound["USER_MOVED"] = "user.moved";
    Sound["USER_MOVED_SELF"] = "user.moved.self";
    Sound["USER_POKED_SELF"] = "user.poked.self";
    Sound["USER_BANNED"] = "user.banned";
    Sound["USER_ENTERED"] = "user.joined";
    Sound["USER_ENTERED_MOVED"] = "user.joined.moved";
    Sound["USER_ENTERED_KICKED"] = "user.joined.kicked";
    Sound["USER_ENTERED_CONNECT"] = "user.joined.connect";
    Sound["USER_LEFT"] = "user.left";
    Sound["USER_LEFT_MOVED"] = "user.left.moved";
    Sound["USER_LEFT_KICKED_CHANNEL"] = "user.left.kicked.server";
    Sound["USER_LEFT_KICKED_SERVER"] = "user.left.kicked.channel";
    Sound["USER_LEFT_DISCONNECT"] = "user.left.disconnect";
    Sound["USER_LEFT_BANNED"] = "user.left.banned";
    Sound["ERROR_INSUFFICIENT_PERMISSIONS"] = "error.insufficient_permissions";
    Sound["MESSAGE_SEND"] = "message.send";
    Sound["MESSAGE_RECEIVED"] = "message.received";
    Sound["GROUP_SERVER_ASSIGNED"] = "group.server.assigned";
    Sound["GROUP_SERVER_REVOKED"] = "group.server.revoked";
    Sound["GROUP_CHANNEL_CHANGED"] = "group.channel.changed";
    Sound["GROUP_SERVER_ASSIGNED_SELF"] = "group.server.assigned.self";
    Sound["GROUP_SERVER_REVOKED_SELF"] = "group.server.revoked.self";
    Sound["GROUP_CHANNEL_CHANGED_SELF"] = "group.channel.changed.self";
})(Sound || (Sound = {}));
var sound;
(function (sound_1) {
    let warned = false;
    let speech_mapping = {};
    function register_sound(key, file) {
        speech_mapping[key] = { key: key, filename: file };
    }
    function initialize() {
        $.ajaxSetup({
            beforeSend: function (jqXHR, settings) {
                if (settings.dataType === 'binary') {
                    console.log("Settins binary");
                    settings.xhr().responseType = 'arraybuffer';
                    settings.processData = false;
                }
            }
        });
        register_sound("message.received", "effects/message_received.wav");
        register_sound("message.send", "effects/message_send.wav");
        return new Promise(resolve => {
            $.ajax({
                url: "audio/speech/mapping.json",
                success: response => {
                    if (typeof (response) === "string")
                        response = JSON.parse(response);
                    for (const entry of response)
                        register_sound(entry.key, "speech/" + entry.file);
                    resolve();
                },
                error: () => {
                    console.log("error!");
                    console.dir(...arguments);
                },
                timeout: 5000,
                async: true,
                type: 'GET'
            });
        });
    }
    sound_1.initialize = initialize;
    function str2ab(str) {
        var buf = new ArrayBuffer(str.length * 2); // 2 bytes for each char
        var bufView = new Uint16Array(buf);
        for (var i = 0, strLen = str.length; i < strLen; i++) {
            bufView[i] = str.charCodeAt(i);
        }
        return buf;
    }
    function play(sound, options) {
        console.log(_translations.Bs6gchUN || (_translations.Bs6gchUN = tr("playback sound %o")), sound);
        const file = speech_mapping[sound];
        if (!file) {
            console.warn(_translations.OIVx7K6I || (_translations.OIVx7K6I = tr("Missing sound %o")), sound);
            return;
        }
        if (file.not_supported) {
            if (!file.not_supported_timeout || Date.now() < file.not_supported_timeout) //Test if the not supported isnt may timeouted
                return;
            file.not_supported = false;
            file.not_supported_timeout = undefined;
        }
        const path = "audio/" + file.filename;
        const context = audio.player.context();
        const volume = options && options.background_notification ? .5 : 1;
        if (context.decodeAudioData) {
            if (file.cached) {
                console.log(_translations.qQPwLXhN || (_translations.qQPwLXhN = tr("Using cached buffer: %o")), file.cached);
                const player = context.createBufferSource();
                player.buffer = file.cached;
                player.start(0);
                if (volume != 1 && context.createGain) {
                    const gain = context.createGain();
                    if (gain.gain.setValueAtTime)
                        gain.gain.setValueAtTime(volume, 0);
                    else
                        gain.gain.value = volume;
                    player.connect(gain);
                    gain.connect(audio.player.destination());
                }
                else
                    player.connect(audio.player.destination());
            }
            else {
                const decode_data = buffer => {
                    console.log(buffer);
                    try {
                        console.log(_translations.pgPiLKgs || (_translations.pgPiLKgs = tr("Decoding data")));
                        context.decodeAudioData(buffer, result => {
                            console.log(_translations.dAuUrGsC || (_translations.dAuUrGsC = tr("Got decoded data")));
                            file.cached = result;
                            play(sound, options);
                        }, error => {
                            console.error(_translations.p764TLam || (_translations.p764TLam = tr("Failed to decode audio data for %o")), sound);
                            console.error(error);
                            file.not_supported = true;
                            file.not_supported_timeout = Date.now() + 1000 * 60 * 60; //Try in 2min again!
                        });
                    }
                    catch (error) {
                        console.error(error);
                        file.not_supported = true;
                        file.not_supported_timeout = Date.now() + 1000 * 60 * 60; //Try in 2min again!
                    }
                };
                const xhr = new XMLHttpRequest();
                xhr.open('GET', path, true);
                xhr.responseType = 'arraybuffer';
                xhr.onload = function (e) {
                    if (this.status == 200) {
                        decode_data(this.response);
                    }
                    else {
                        console.error(_translations.Nk_23DCt || (_translations.Nk_23DCt = tr("Failed to load audio file. (Response code %o)")), this.status);
                        file.not_supported = true;
                        file.not_supported_timeout = Date.now() + 1000 * 60 * 60; //Try in 2min again!
                    }
                };
                xhr.onerror = error => {
                    console.error(_translations.cEpwCdTd || (_translations.cEpwCdTd = tr("Failed to load audio file ")), sound);
                    console.error(error);
                    file.not_supported = true;
                    file.not_supported_timeout = Date.now() + 1000 * 60 * 60; //Try in 2min again!
                };
                xhr.send();
            }
        }
        else {
            console.log(_translations.a020BAuv || (_translations.a020BAuv = tr("Replaying %s")), path);
            if (file.node) {
                file.node.currentTime = 0;
                file.node.play();
            }
            else {
                if (!warned) {
                    warned = true;
                    console.warn(_translations.i72Ajplb || (_translations.i72Ajplb = tr("Your browser does not support decodeAudioData! Using a node to playback! This bypasses the audio output and volume regulation!")));
                }
                const container = $("#sounds");
                const node = $.spawn("audio").attr("src", path);
                node.appendTo(container);
                file.node = node[0];
                file.node.play();
            }
        }
    }
    sound_1.play = play;
})(sound || (sound = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["ba22e4e40051480593077fa0698d3ba64f7e622f21d4e43b7a5f248f1eed5433"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["ba22e4e40051480593077fa0698d3ba64f7e622f21d4e43b7a5f248f1eed5433"] = "ba22e4e40051480593077fa0698d3ba64f7e622f21d4e43b7a5f248f1eed5433";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "U8Ag7ktK", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPoke.ts (13,21)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
/// <reference path="../../proto.ts" />
/// <reference path="../../client.ts" />
var Modals;
(function (Modals) {
    function spawnPoke(invoker, message) {
        let modal;
        modal = createModal({
            header: _translations.U8Ag7ktK || (_translations.U8Ag7ktK = tr("You have been poked!")),
            body: () => {
                let template = $("#tmpl_poke_popup").renderTag({
                    "invoker": ClientEntry.chatTag(invoker.id, invoker.name, invoker.unique_id, true),
                    "message": message
                });
                template = $.spawn("div").append(template);
                template.find(".button-close").on('click', event => modal.close());
                return template;
            },
            footer: undefined,
            width: 750
        });
        modal.open();
    }
    Modals.spawnPoke = spawnPoke;
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["2b3411d7b4eeec6044c609d01e1e0a19666923adf9bc0ec66b3b66c16f4168e4"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["2b3411d7b4eeec6044c609d01e1e0a19666923adf9bc0ec66b3b66c16f4168e4"] = "2b3411d7b4eeec6044c609d01e1e0a19666923adf9bc0ec66b3b66c16f4168e4";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "pJrWdoBE", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (59,21)" }, { name: "BNd2ByE3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (60,41)" }, { name: "TqQpZsWq", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (79,41)" }, { name: "BjX2lrmX", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (84,29)" }, { name: "zR7jEoC9", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (111,29)" }, { name: "xnUfAAAC", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (135,58)" }, { name: "nebTEDup", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (138,27)" }, { name: "gA29Va4z", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (151,31)" }, { name: "YRHv9hys", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (156,29)" }, { name: "COg8cNDz", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (162,29)" }, { name: "ZP7XQ0K5", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (168,74)" }, { name: "nBDZLRRr", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (169,19)" }, { name: "FQQk6F1R", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (170,40)" }, { name: "eJlTrROc", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (175,27)" }, { name: "NlXoInCc", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (230,47)" }, { name: "yHq8ajZ2", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (231,63)" }, { name: "mIrLGr7T", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (238,55)" }, { name: "cTbYUvox", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (240,39)" }, { name: "Vv2_bG0z", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (331,35)" }, { name: "mJX6Zb3o", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (558,25)" }, { name: "Gi1TGdbo", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (577,21)" }, { name: "ofemCku2", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (600,41)" }, { name: "pkupIpKv", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (614,35)" }, { name: "GEvsAn9f", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (621,31)" }, { name: "XdiA_E5o", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (652,21)" }, { name: "ncstpGaE", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (668,21)" }, { name: "Pxlf6WI7", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (672,31)" }, { name: "rOH2yuAO", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (682,21)" }, { name: "u6XpUCid", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (686,31)" }, { name: "CAYwVg4x", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (724,49)" }, { name: "tQCdByCd", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (726,49)" }, { name: "nryrhVjd", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (732,45)" }, { name: "giyppEsa", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (742,45)" }, { name: "FlYj7V5I", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (750,26)" }, { name: "vvhvL7Pp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (780,27)" }, { name: "W88dqpqm", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (803,45)" }, { name: "TB4kC3cG", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (808,45)" }, { name: "i0K2uAvV", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (816,43)" }, { name: "S0KF1Lmb", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (824,43)" }, { name: "iPR9V7w4", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (838,43)" }, { name: "gy5Vm8mp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (848,27)" }, { name: "YxmSvffF", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (862,27)" }, { name: "gCVcs7NM", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (867,27)" }, { name: "m4aiRqhe", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (871,27)" }, { name: "i0Mu9ooZ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (887,52)" }, { name: "JZ71QMKH", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (887,105)" }, { name: "dW6dNjEp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (900,52)" }, { name: "kWOqzUKo", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (900,97)" }, { name: "uPKI2k4K", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (911,52)" }, { name: "YAX0fxcY", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (911,123)" }, { name: "U72KUXk8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (925,26)" }, { name: "QiONPBbl", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (937,27)" }, { name: "rG9k4Hc8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (943,27)" }, { name: "GQ6TztkA", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (949,27)" }, { name: "jFySjD0I", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (962,27)" }, { name: "PLjb8d_b", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (990,31)" }, { name: "eGNfPcZk", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (994,31)" }, { name: "EO5swjey", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (1020,27)" }, { name: "MEAMCLXl", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/connection.ts (1083,42)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="ui/channel.ts" />
/// <reference path="client.ts" />
/// <reference path="sound/Sounds.ts" />
/// <reference path="ui/modal/ModalPoke.ts" />
class CommandResult {
    constructor(json) {
        this.json = json;
        this.id = json["id"];
        this.message = json["msg"];
        this.extra_message = "";
        if (json["extra_msg"])
            this.extra_message = json["extra_msg"];
        this.success = this.id == 0;
    }
}
class ReturnListener {
}
class ServerConnection {
    constructor(client) {
        this._connectionState = ConnectionState.UNCONNECTED;
        this._connectTimeoutHandler = undefined;
        this._connected = false;
        this.on_connect = () => {
            console.log(_translations.pJrWdoBE || (_translations.pJrWdoBE = tr("Socket connected")));
            chat.serverChat().appendMessage(_translations.BNd2ByE3 || (_translations.BNd2ByE3 = tr("Logging in...")));
            this._handshakeHandler.startHandshake();
        };
        this._client = client;
        this._socket = null;
        this.commandHandler = new ConnectionCommandHandler(this);
        this.helper = new CommandHelper(this);
        this._retCodeIdx = 0;
        this._retListener = [];
    }
    generateReturnCode() {
        return (this._retCodeIdx++).toString();
    }
    startConnection(address, handshake, timeout = 1000) {
        if (this._connectTimeoutHandler) {
            clearTimeout(this._connectTimeoutHandler);
            this._connectTimeoutHandler = null;
            this.disconnect();
        }
        this.updateConnectionState(ConnectionState.CONNECTING);
        this._remote_address = address;
        this._handshakeHandler = handshake;
        this._handshakeHandler.setConnection(this);
        this._connected = false;
        chat.serverChat().appendMessage(_translations.TqQpZsWq || (_translations.TqQpZsWq = tr("Connecting to {0}:{1}")), true, address.host, address.port);
        const self = this;
        try {
            this._connectTimeoutHandler = setTimeout(() => {
                console.log(_translations.BjX2lrmX || (_translations.BjX2lrmX = tr("Connect timeout triggered!")));
                this.disconnect();
                this._client.handleDisconnect(DisconnectReason.CONNECT_FAILURE);
            }, timeout);
            let sockCpy;
            this._socket = (sockCpy = new WebSocket('wss://' + address.host + ":" + address.port));
            clearTimeout(this._connectTimeoutHandler);
            this._connectTimeoutHandler = null;
            if (this._socket != sockCpy)
                return; //Connect timeouted
            this._socket.onopen = () => {
                if (this._socket != sockCpy)
                    return;
                this._connected = true;
                this.on_connect();
            };
            this._socket.onclose = event => {
                if (this._socket != sockCpy)
                    return;
                this._client.handleDisconnect(this._connected ? DisconnectReason.CONNECTION_CLOSED : DisconnectReason.CONNECT_FAILURE, {
                    code: event.code,
                    reason: event.reason,
                    event: event
                });
            };
            this._socket.onerror = e => {
                if (this._socket != sockCpy)
                    return;
                console.log(_translations.zR7jEoC9 || (_translations.zR7jEoC9 = tr("Got error: (%s)")), self._socket.readyState);
                console.log(e);
            };
            this._socket.onmessage = msg => {
                if (this._socket != sockCpy)
                    return;
                self.handleWebSocketMessage(msg.data);
            };
            this.updateConnectionState(ConnectionState.INITIALISING);
        }
        catch (e) {
            this.disconnect();
            this._client.handleDisconnect(DisconnectReason.CONNECT_FAILURE, e);
        }
    }
    updateConnectionState(state) {
        this._connectionState = state;
        this._client.controlBar.update_connection_state();
    }
    disconnect() {
        if (this._connectionState == ConnectionState.UNCONNECTED)
            return false;
        this.updateConnectionState(ConnectionState.UNCONNECTED);
        if (this._socket)
            this._socket.close(3000 + 0xFF, _translations.xnUfAAAC || (_translations.xnUfAAAC = tr("request disconnect")));
        this._socket = null;
        for (let future of this._retListener)
            future.reject(_translations.nebTEDup || (_translations.nebTEDup = tr("Connection closed")));
        this._retListener = [];
        this._retCodeIdx = 0;
        this._connected = false;
        return true;
    }
    handleWebSocketMessage(data) {
        if (typeof (data) === "string") {
            let json;
            try {
                json = JSON.parse(data);
            }
            catch (e) {
                console.error(_translations.gA29Va4z || (_translations.gA29Va4z = tr("Could not parse message json!")));
                alert(e); // error in the above string (in this case, yes)!
                return;
            }
            if (json["type"] === undefined) {
                console.log(_translations.YRHv9hys || (_translations.YRHv9hys = tr("Missing data type!")));
                return;
            }
            if (json["type"] === "command")
                this.handleCommand(json);
            else if (json["type"] === "WebRTC")
                this._client.voiceConnection.handleControlPacket(json);
            else {
                console.log(_translations.COg8cNDz || (_translations.COg8cNDz = tr("Unknown command type %o")), json["type"]);
            }
        }
    }
    handleCommand(json) {
        let group = log.group(log.LogType.DEBUG, LogCategory.NETWORKING, _translations.ZP7XQ0K5 || (_translations.ZP7XQ0K5 = tr("Handling command '%s'")), json["command"]);
        group.log(_translations.nBDZLRRr || (_translations.nBDZLRRr = tr("Handling command '%s'")), json["command"]);
        group.group(log.LogType.TRACE, _translations.FQQk6F1R || (_translations.FQQk6F1R = tr("Json:"))).collapsed(true).log("%o", json).end();
        try {
            let fn = this.commandHandler[json["command"]];
            if (fn === undefined) {
                group.log(_translations.eJlTrROc || (_translations.eJlTrROc = tr("Missing command '%s'")), json["command"]);
                return;
            }
            fn.call(this.commandHandler, json["data"]);
        }
        finally {
            group.end();
        }
    }
    sendData(data) {
        this._socket.send(data);
    }
    commandiefy(input) {
        return JSON.stringify(input, (key, value) => {
            switch (typeof value) {
                case "boolean": return value == true ? "1" : "0";
                case "function": return value();
                default:
                    return value;
            }
        });
    }
    sendCommand(command, data = {}, flags = [], logResult = true) {
        const _this = this;
        let result = new Promise((resolve, failed) => {
            let _data = $.isArray(data) ? data : [data];
            let retCode = _data[0]["return_code"] !== undefined ? _data[0].return_code : _this.generateReturnCode();
            _data[0].return_code = retCode;
            let listener = new ReturnListener();
            listener.resolve = resolve;
            listener.reject = failed;
            listener.code = retCode;
            listener.timeout = setTimeout(() => {
                _this._retListener.remove(listener);
                listener.reject("timeout");
            }, 1500);
            this._retListener.push(listener);
            this._socket.send(this.commandiefy({
                "type": "command",
                "command": command,
                "data": _data,
                "flags": flags.filter(entry => entry.length != 0)
            }));
        });
        return new Promise((resolve, failed) => {
            result.then(resolve).catch(ex => {
                if (logResult) {
                    if (ex instanceof CommandResult) {
                        let res = ex;
                        if (!res.success) {
                            if (res.id == 2568) { //Permission error
                                res.message = (_translations.NlXoInCc || (_translations.NlXoInCc = tr("Insufficient client permissions. Failed on permission "))) + this._client.permissions.resolveInfo(res.json["failed_permid"]).name;
                                chat.serverChat().appendError(_translations.yHq8ajZ2 || (_translations.yHq8ajZ2 = tr("Insufficient client permissions. Failed on permission {}")), this._client.permissions.resolveInfo(res.json["failed_permid"]).name);
                                sound.play(Sound.ERROR_INSUFFICIENT_PERMISSIONS);
                            }
                            else {
                                chat.serverChat().appendError(res.extra_message.length == 0 ? res.message : res.extra_message);
                            }
                        }
                    }
                    else if (typeof (ex) === "string") {
                        chat.serverChat().appendError((_translations.mIrLGr7T || (_translations.mIrLGr7T = tr("Command execution results in "))) + ex);
                    }
                    else {
                        console.error(_translations.cTbYUvox || (_translations.cTbYUvox = tr("Invalid promise result type: %o. Result:")), typeof (ex));
                        console.error(ex);
                    }
                }
                failed(ex);
            });
        });
    }
    get connected() {
        return this._socket && this._socket.readyState == WebSocket.OPEN;
    }
    /**
     *   HELPER METHODS
     */
    joinChannel(channel, password = "") {
        return this.sendCommand("clientmove", [{
                "clid": this._client.getClientId(),
                "cid": channel.getChannelId(),
                "cpw": password
            }]);
    }
    sendMessage(message, type, target) {
        if (type == ChatType.SERVER)
            return this.sendCommand("sendtextmessage", { "targetmode": 3, "target": 0, "msg": message });
        else if (type == ChatType.CHANNEL)
            return this.sendCommand("sendtextmessage", { "targetmode": 2, "target": target.getChannelId(), "msg": message });
        else if (type == ChatType.CLIENT)
            return this.sendCommand("sendtextmessage", { "targetmode": 1, "target": target.clientId(), "msg": message });
    }
    updateClient(key, value) {
        let data = {};
        data[key] = value;
        return this.sendCommand("clientupdate", data);
    }
}
class HandshakeHandler {
    constructor(profile, name, password) {
        this.profile = profile;
        this.server_password = password;
        this.name = name;
    }
    setConnection(con) {
        this.connection = con;
    }
    startHandshake() {
        this.handshake_handler = this.profile.spawn_identity_handshake_handler(this.connection);
        if (!this.handshake_handler) {
            this.handshake_failed("failed to create identity handler");
            return;
        }
        this.handshake_handler.register_callback((flag, message) => {
            if (flag)
                this.handshake_finished();
            else
                this.handshake_failed(message);
        });
        this.handshake_handler.start_handshake();
    }
    handshake_failed(message) {
        this.connection._client.handleDisconnect(DisconnectReason.HANDSHAKE_FAILED, message);
    }
    handshake_finished(version) {
        if (native_client && window["native"] && native.client_version && !version) {
            native.client_version()
                .then(this.handshake_finished.bind(this))
                .catch(error => {
                console.error(_translations.Vv2_bG0z || (_translations.Vv2_bG0z = tr("Failed to get version:")));
                console.error(error);
                this.handshake_finished("?.?.?");
            });
            return;
        }
        const git_version = settings.static_global("version", "unknown");
        const browser_name = (navigator.browserSpecs || {})["name"] || " ";
        let data = {
            //TODO variables!
            client_nickname: this.name,
            client_platform: (browser_name ? browser_name + " " : "") + navigator.platform,
            client_version: "TeaWeb " + git_version + " (" + navigator.userAgent + ")",
            client_server_password: this.server_password,
            client_browser_engine: navigator.product
        };
        if (version) {
            data.client_version = "TeaClient ";
            data.client_version += " " + version;
            const os = require("os");
            const arch_mapping = {
                "x32": "32bit",
                "x64": "64bit"
            };
            data.client_version += " " + (arch_mapping[os.arch()] || os.arch());
            const os_mapping = {
                "win32": "Windows",
                "linux": "Linux"
            };
            data.client_platform = (os_mapping[os.platform()] || os.platform());
        }
        this.connection.sendCommand("clientinit", data).catch(error => {
            this.connection.disconnect();
            if (error instanceof CommandResult) {
                if (error.id == 1028) {
                    this.connection._client.handleDisconnect(DisconnectReason.SERVER_REQUIRES_PASSWORD);
                }
                else {
                    this.connection._client.handleDisconnect(DisconnectReason.CLIENT_KICKED, error);
                }
            }
        });
    }
}
class CommandHelper {
    constructor(connection) {
        this._callbacks_namefromuid = [];
        this.connection = connection;
        this.connection.commandHandler["notifyclientnamefromuid"] = this.handle_notifyclientnamefromuid.bind(this);
    }
    info_from_uid(...uid) {
        let uids = [...uid];
        for (let p of this._callbacks_namefromuid)
            if (p.keys == uids)
                return p.promise;
        let req = {};
        req.keys = uids;
        req.response = new Array(uids.length);
        req.promise = new LaterPromise();
        for (let uid of uids) {
            this.connection.sendCommand("clientgetnamefromuid", {
                cluid: uid
            }).catch(req.promise.function_rejected());
        }
        this._callbacks_namefromuid.push(req);
        return req.promise;
    }
    request_query_list(server_id = undefined) {
        return new Promise((resolve, reject) => {
            this.connection.commandHandler["notifyquerylist"] = json => {
                const result = {};
                result.flag_all = json[0]["flag_all"];
                result.flag_own = json[0]["flag_own"];
                result.queries = [];
                for (const entry of json) {
                    const rentry = {};
                    rentry.bounded_server = entry["client_bounded_server"];
                    rentry.username = entry["client_login_name"];
                    rentry.unique_id = entry["client_unique_identifier"];
                    result.queries.push(rentry);
                }
                resolve(result);
                this.connection.commandHandler["notifyquerylist"] = undefined;
            };
            let data = {};
            if (server_id !== undefined)
                data["server_id"] = server_id;
            this.connection.sendCommand("querylist", data).catch(error => {
                if (error instanceof CommandResult) {
                    if (error.id == 0x0501) {
                        resolve(undefined);
                        return;
                    }
                }
                reject(error);
            });
        });
    }
    /**
     * @deprecated
     *  Its just a workaround for the query management.
     *  There is no garante that the whoami trick will work forever
     */
    current_virtual_server_id() {
        if (this._who_am_i)
            return Promise.resolve(parseInt(this._who_am_i["virtualserver_id"]));
        return new Promise((resolve, reject) => {
            this.connection.commandHandler[""] = json => {
                this._who_am_i = json[0];
                resolve(parseInt(this._who_am_i["virtualserver_id"]));
                this.connection.commandHandler[""] = undefined;
            };
            this.connection.sendCommand("whoami");
        });
    }
    handle_notifyclientnamefromuid(json) {
        for (let entry of json) {
            let info = {};
            info.client_unique_id = entry["cluid"];
            info.client_nickname = entry["clname"];
            info.client_database_id = parseInt(entry["cldbid"]);
            for (let elm of this._callbacks_namefromuid.slice(0)) {
                let unset = 0;
                for (let index = 0; index < elm.keys.length; index++) {
                    if (elm.keys[index] == info.client_unique_id) {
                        elm.response[index] = info;
                    }
                    if (elm.response[index] == undefined)
                        unset++;
                }
                if (unset == 0) {
                    this._callbacks_namefromuid.remove(elm);
                    elm.promise.resolved(elm.response);
                }
            }
        }
    }
}
class ConnectionCommandHandler {
    constructor(connection) {
        this.connection = connection;
        this["error"] = this.handleCommandResult;
        this["channellist"] = this.handleCommandChannelList;
        this["notifychannelcreated"] = this.handleCommandChannelCreate;
        this["notifychanneldeleted"] = this.handleCommandChannelDelete;
        this["notifychannelhide"] = this.handleCommandChannelHide;
        this["notifychannelshow"] = this.handleCommandChannelShow;
        this["notifycliententerview"] = this.handleCommandClientEnterView;
        this["notifyclientleftview"] = this.handleCommandClientLeftView;
        this["notifyclientmoved"] = this.handleNotifyClientMoved;
        this["initserver"] = this.handleCommandServerInit;
        this["notifychannelmoved"] = this.handleNotifyChannelMoved;
        this["notifychanneledited"] = this.handleNotifyChannelEdited;
        this["notifytextmessage"] = this.handleNotifyTextMessage;
        this["notifyclientupdated"] = this.handleNotifyClientUpdated;
        this["notifyserveredited"] = this.handleNotifyServerEdited;
        this["notifyserverupdated"] = this.handleNotifyServerUpdated;
        this["notifyclientpoke"] = this.handleNotifyClientPoke;
        this["notifymusicplayerinfo"] = this.handleNotifyMusicPlayerInfo;
        this["notifyservergroupclientadded"] = this.handleNotifyServerGroupClientAdd;
        this["notifyservergroupclientdeleted"] = this.handleNotifyServerGroupClientRemove;
        this["notifyclientchannelgroupchanged"] = this.handleNotifyClientChannelGroupChanged;
    }
    handleCommandResult(json) {
        json = json[0]; //Only one bulk
        let code = json["return_code"];
        if (code.length == 0) {
            console.log(_translations.mJX6Zb3o || (_translations.mJX6Zb3o = tr("Invalid return code! (%o)")), json);
            return;
        }
        let retListeners = this.connection["_retListener"];
        for (let e of retListeners) {
            if (e.code != code)
                continue;
            retListeners.remove(e);
            let result = new CommandResult(json);
            if (result.success)
                e.resolve(result);
            else
                e.reject(result);
            break;
        }
    }
    handleCommandServerInit(json) {
        //We could setup the voice channel
        console.log(_translations.Gi1TGdbo || (_translations.Gi1TGdbo = tr("Setting up voice")));
        this.connection._client.voiceConnection.createSession();
        json = json[0]; //Only one bulk
        this.connection._client.clientId = parseInt(json["aclid"]);
        this.connection._client.getClient().updateVariables({ key: "client_nickname", value: json["acn"] });
        let updates = [];
        for (let key in json) {
            if (key === "aclid")
                continue;
            if (key === "acn")
                continue;
            updates.push({ key: key, value: json[key] });
        }
        this.connection._client.channelTree.server.updateVariables(false, ...updates);
        chat.serverChat().name = this.connection._client.channelTree.server.properties["virtualserver_name"];
        chat.serverChat().appendMessage(_translations.ofemCku2 || (_translations.ofemCku2 = tr("Connected as {0}")), true, this.connection._client.getClient().createChatTag(true));
        sound.play(Sound.CONNECTION_CONNECTED);
        globalClient.onConnected();
    }
    createChannelFromJson(json, ignoreOrder = false) {
        let tree = this.connection._client.channelTree;
        let channel = new ChannelEntry(parseInt(json["cid"]), json["channel_name"], tree.findChannel(json["cpid"]));
        tree.insertChannel(channel);
        if (json["channel_order"] !== "0") {
            let prev = tree.findChannel(json["channel_order"]);
            if (!prev && json["channel_order"] != 0) {
                if (!ignoreOrder) {
                    console.error(_translations.pkupIpKv || (_translations.pkupIpKv = tr("Invalid channel order id!")));
                    return;
                }
            }
            let parent = tree.findChannel(json["cpid"]);
            if (!parent && json["cpid"] != 0) {
                console.error(_translations.GEvsAn9f || (_translations.GEvsAn9f = tr("Invalid channel parent")));
                return;
            }
            tree.moveChannel(channel, prev, parent); //TODO test if channel exists!
        }
        if (ignoreOrder) {
            for (let ch of tree.channels) {
                if (ch.properties.channel_order == channel.channelId) {
                    tree.moveChannel(ch, channel, channel.parent); //Corrent the order :)
                }
            }
        }
        let updates = [];
        for (let key in json) {
            if (key === "cid")
                continue;
            if (key === "cpid")
                continue;
            if (key === "invokerid")
                continue;
            if (key === "invokername")
                continue;
            if (key === "invokeruid")
                continue;
            if (key === "reasonid")
                continue;
            updates.push({ key: key, value: json[key] });
        }
        channel.updateVariables(...updates);
    }
    handleCommandChannelList(json) {
        console.log(_translations.XdiA_E5o || (_translations.XdiA_E5o = tr("Got %d new channels")), json.length);
        for (let index = 0; index < json.length; index++)
            this.createChannelFromJson(json[index], true);
    }
    handleCommandChannelCreate(json) {
        this.createChannelFromJson(json[0]);
    }
    handleCommandChannelShow(json) {
        this.createChannelFromJson(json[0]); //TODO may chat?
    }
    handleCommandChannelDelete(json) {
        let tree = this.connection._client.channelTree;
        console.log(_translations.ncstpGaE || (_translations.ncstpGaE = tr("Got %d channel deletions")), json.length);
        for (let index = 0; index < json.length; index++) {
            let channel = tree.findChannel(json[index]["cid"]);
            if (!channel) {
                console.error(_translations.Pxlf6WI7 || (_translations.Pxlf6WI7 = tr("Invalid channel onDelete (Unknown channel)")));
                continue;
            }
            tree.deleteChannel(channel);
        }
    }
    handleCommandChannelHide(json) {
        let tree = this.connection._client.channelTree;
        console.log(_translations.rOH2yuAO || (_translations.rOH2yuAO = tr("Got %d channel hides")), json.length);
        for (let index = 0; index < json.length; index++) {
            let channel = tree.findChannel(json[index]["cid"]);
            if (!channel) {
                console.error(_translations.u6XpUCid || (_translations.u6XpUCid = tr("Invalid channel on hide (Unknown channel)")));
                continue;
            }
            tree.deleteChannel(channel);
        }
    }
    handleCommandClientEnterView(json) {
        json = json[0]; //Only one bulk
        let tree = this.connection._client.channelTree;
        let client;
        let channel = tree.findChannel(json["ctid"]);
        let old_channel = tree.findChannel(json["cfid"]);
        client = tree.findClient(json["clid"]);
        if (!client) {
            if (parseInt(json["client_type_exact"]) == ClientType.CLIENT_MUSIC) {
                client = new MusicClientEntry(parseInt(json["clid"]), json["client_nickname"]);
            }
            else {
                client = new ClientEntry(parseInt(json["clid"]), json["client_nickname"]);
            }
            client = tree.insertClient(client, channel);
        }
        else {
            if (client == this.connection._client.getClient())
                chat.channelChat().name = channel.channelName();
            tree.moveClient(client, channel);
        }
        const own_channel = this.connection._client.getClient().currentChannel();
        if (json["reasonid"] == ViewReasonId.VREASON_USER_ACTION) {
            if (own_channel == channel)
                if (old_channel)
                    sound.play(Sound.USER_ENTERED);
                else
                    sound.play(Sound.USER_ENTERED_CONNECT);
            if (old_channel) {
                chat.serverChat().appendMessage(_translations.CAYwVg4x || (_translations.CAYwVg4x = tr("{0} appeared from {1} to {2}")), true, client.createChatTag(true), old_channel.createChatTag(true), channel.createChatTag(true));
            }
            else {
                chat.serverChat().appendMessage(_translations.tQCdByCd || (_translations.tQCdByCd = tr("{0} connected to channel {1}")), true, client.createChatTag(true), channel.createChatTag(true));
            }
        }
        else if (json["reasonid"] == ViewReasonId.VREASON_MOVED) {
            if (own_channel == channel)
                sound.play(Sound.USER_ENTERED_MOVED);
            chat.serverChat().appendMessage(_translations.nryrhVjd || (_translations.nryrhVjd = tr("{0} appeared from {1} to {2}, moved by {3}")), true, client.createChatTag(true), old_channel ? old_channel.createChatTag(true) : undefined, channel.createChatTag(true), ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"]));
        }
        else if (json["reasonid"] == ViewReasonId.VREASON_CHANNEL_KICK) {
            if (own_channel == channel)
                sound.play(Sound.USER_ENTERED_KICKED);
            chat.serverChat().appendMessage(_translations.giyppEsa || (_translations.giyppEsa = tr("{0} appeared from {1} to {2}, kicked by {3}{4}")), true, client.createChatTag(true), old_channel ? old_channel.createChatTag(true) : undefined, channel.createChatTag(true), ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"]), json["reasonmsg"] > 0 ? " (" + json["msg"] + ")" : "");
        }
        else {
            console.warn(_translations.FlYj7V5I || (_translations.FlYj7V5I = tr("Unknown reasonid for %o")), json["reasonid"]);
        }
        let updates = [];
        for (let key in json) {
            if (key == "cfid")
                continue;
            if (key == "ctid")
                continue;
            if (key === "invokerid")
                continue;
            if (key === "invokername")
                continue;
            if (key === "invokeruid")
                continue;
            if (key === "reasonid")
                continue;
            updates.push({ key: key, value: json[key] });
        }
        client.updateVariables(...updates);
        if (client instanceof LocalClientEntry)
            this.connection._client.controlBar.updateVoice();
    }
    handleCommandClientLeftView(json) {
        json = json[0]; //Only one bulk
        let tree = this.connection._client.channelTree;
        let client = tree.findClient(json["clid"]);
        if (!client) {
            console.error(_translations.vvhvL7Pp || (_translations.vvhvL7Pp = tr("Unknown client left!")));
            return 0;
        }
        if (client == this.connection._client.getClient()) {
            if (json["reasonid"] == ViewReasonId.VREASON_BAN) {
                this.connection._client.handleDisconnect(DisconnectReason.CLIENT_BANNED, json);
            }
            else if (json["reasonid"] == ViewReasonId.VREASON_SERVER_KICK) {
                this.connection._client.handleDisconnect(DisconnectReason.CLIENT_KICKED, json);
            }
            else if (json["reasonid"] == ViewReasonId.VREASON_SERVER_SHUTDOWN) {
                this.connection._client.handleDisconnect(DisconnectReason.SERVER_CLOSED, json);
            }
            else if (json["reasonid"] == ViewReasonId.VREASON_SERVER_STOPPED) {
                this.connection._client.handleDisconnect(DisconnectReason.SERVER_CLOSED, json);
            }
            else
                this.connection._client.handleDisconnect(DisconnectReason.UNKNOWN, json);
            return;
        }
        const own_channel = this.connection._client.getClient().currentChannel();
        let channel_from = tree.findChannel(json["cfid"]);
        let channel_to = tree.findChannel(json["ctid"]);
        if (json["reasonid"] == ViewReasonId.VREASON_USER_ACTION) {
            chat.serverChat().appendMessage(_translations.W88dqpqm || (_translations.W88dqpqm = tr("{0} disappeared from {1} to {2}")), true, client.createChatTag(true), channel_from.createChatTag(true), channel_to.createChatTag(true));
            if (channel_from == own_channel)
                sound.play(Sound.USER_LEFT);
        }
        else if (json["reasonid"] == ViewReasonId.VREASON_SERVER_LEFT) {
            chat.serverChat().appendMessage(_translations.TB4kC3cG || (_translations.TB4kC3cG = tr("{0} left the server{1}")), true, client.createChatTag(true), json["reasonmsg"] ? " (" + json["reasonmsg"] + ")" : "");
            if (channel_from == own_channel)
                sound.play(Sound.USER_LEFT_DISCONNECT);
        }
        else if (json["reasonid"] == ViewReasonId.VREASON_SERVER_KICK) {
            chat.serverChat().appendError(_translations.i0K2uAvV || (_translations.i0K2uAvV = tr("{0} was kicked from the server by {1}.{2}")), client.createChatTag(true), ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"]), json["reasonmsg"] ? " (" + json["reasonmsg"] + ")" : "");
            if (channel_from == own_channel)
                sound.play(Sound.USER_LEFT_KICKED_SERVER);
        }
        else if (json["reasonid"] == ViewReasonId.VREASON_CHANNEL_KICK) {
            chat.serverChat().appendError(_translations.S0KF1Lmb || (_translations.S0KF1Lmb = tr("{0} was kicked from your channel by {1}.{2}")), client.createChatTag(true), ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"]), json["reasonmsg"] ? " (" + json["reasonmsg"] + ")" : "");
            if (channel_from == own_channel)
                sound.play(Sound.USER_LEFT_KICKED_CHANNEL);
        }
        else if (json["reasonid"] == ViewReasonId.VREASON_BAN) {
            //"Mulus" was banned for 1 second from the server by "WolverinDEV" (Sry brauchte kurz ein opfer :P <3 (Nohomo))
            let duration = "permanently";
            if (json["bantime"])
                duration = "for " + formatDate(Number.parseInt(json["bantime"]));
            chat.serverChat().appendError(_translations.iPR9V7w4 || (_translations.iPR9V7w4 = tr("{0} was banned {1} by {2}.{3}")), client.createChatTag(true), duration, ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"]), json["reasonmsg"] ? " (" + json["reasonmsg"] + ")" : "");
            if (channel_from == own_channel)
                sound.play(Sound.USER_LEFT_BANNED);
        }
        else {
            console.error(_translations.gy5Vm8mp || (_translations.gy5Vm8mp = tr("Unknown client left reason!")));
        }
        tree.deleteClient(client);
    }
    handleNotifyClientMoved(json) {
        json = json[0]; //Only one bulk
        let tree = this.connection._client.channelTree;
        let client = tree.findClient(json["clid"]);
        let channel_to = tree.findChannel(json["ctid"]);
        let channel_from = tree.findChannel(json["cfid"]);
        if (!client) {
            console.error(_translations.YxmSvffF || (_translations.YxmSvffF = tr("Unknown client move (Client)!")));
            return 0;
        }
        if (!channel_to) {
            console.error(_translations.gCVcs7NM || (_translations.gCVcs7NM = tr("Unknown client move (Channel to)!")));
            return 0;
        }
        if (!channel_from) //Not critical
            console.error(_translations.m4aiRqhe || (_translations.m4aiRqhe = tr("Unknown client move (Channel from)!")));
        let self = client instanceof LocalClientEntry;
        let current_clients;
        if (self) {
            chat.channelChat().name = channel_to.channelName();
            current_clients = client.channelTree.clientsByChannel(client.currentChannel());
            this.connection._client.controlBar.updateVoice(channel_to);
        }
        tree.moveClient(client, channel_to);
        for (const entry of current_clients || [])
            if (entry !== client)
                entry.getAudioController().stopAudio(true);
        const own_channel = this.connection._client.getClient().currentChannel();
        if (json["reasonid"] == ViewReasonId.VREASON_MOVED) {
            chat.serverChat().appendMessage(self ? _translations.i0Mu9ooZ || (_translations.i0Mu9ooZ = tr("You was moved by {3} from channel {1} to {2}")) : _translations.JZ71QMKH || (_translations.JZ71QMKH = tr("{0} was moved from channel {1} to {2} by {3}")), true, client.createChatTag(true), channel_from ? channel_from.createChatTag(true) : undefined, channel_to.createChatTag(true), ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"]));
            if (self)
                sound.play(Sound.USER_MOVED_SELF);
            else if (own_channel == channel_to)
                sound.play(Sound.USER_ENTERED_MOVED);
            else if (own_channel == channel_from)
                sound.play(Sound.USER_LEFT_MOVED);
        }
        else if (json["reasonid"] == ViewReasonId.VREASON_USER_ACTION) {
            chat.serverChat().appendMessage(self ? _translations.dW6dNjEp || (_translations.dW6dNjEp = tr("You switched from channel {1} to {2}")) : _translations.kWOqzUKo || (_translations.kWOqzUKo = tr("{0} switched from channel {1} to {2}")), true, client.createChatTag(true), channel_from ? channel_from.createChatTag(true) : undefined, channel_to.createChatTag(true));
            if (self) { } //If we do an action we wait for the error response
            else if (own_channel == channel_to)
                sound.play(Sound.USER_ENTERED);
            else if (own_channel == channel_from)
                sound.play(Sound.USER_LEFT);
        }
        else if (json["reasonid"] == ViewReasonId.VREASON_CHANNEL_KICK) {
            chat.serverChat().appendMessage(self ? _translations.uPKI2k4K || (_translations.uPKI2k4K = tr("You got kicked out of the channel {1} to channel {2} by {3}{4}")) : _translations.YAX0fxcY || (_translations.YAX0fxcY = tr("{0} got kicked from channel {1} to {2} by {3}{4}")), true, client.createChatTag(true), channel_from ? channel_from.createChatTag(true) : undefined, channel_to.createChatTag(true), ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"]), json["reasonmsg"] ? " (" + json["reasonmsg"] + ")" : "");
            if (self) {
                sound.play(Sound.CHANNEL_KICKED);
            }
            else if (own_channel == channel_to)
                sound.play(Sound.USER_ENTERED_KICKED);
            else if (own_channel == channel_from)
                sound.play(Sound.USER_LEFT_KICKED_CHANNEL);
        }
        else {
            console.warn(_translations.U72KUXk8 || (_translations.U72KUXk8 = tr("Unknown reason id %o")), json["reasonid"]);
        }
    }
    handleNotifyChannelMoved(json) {
        json = json[0]; //Only one bulk
        for (let key in json)
            console.log("Key: " + key + " Value: " + json[key]);
        let tree = this.connection._client.channelTree;
        let channel = tree.findChannel(json["cid"]);
        if (!channel) {
            console.error(_translations.QiONPBbl || (_translations.QiONPBbl = tr("Unknown channel move (Channel)!")));
            return 0;
        }
        let prev = tree.findChannel(json["order"]);
        if (!prev && json["order"] != 0) {
            console.error(_translations.rG9k4Hc8 || (_translations.rG9k4Hc8 = tr("Unknown channel move (prev)!")));
            return 0;
        }
        let parent = tree.findChannel(json["cpid"]);
        if (!parent && json["cpid"] != 0) {
            console.error(_translations.GQ6TztkA || (_translations.GQ6TztkA = tr("Unknown channel move (parent)!")));
            return 0;
        }
        tree.moveChannel(channel, prev, parent);
    }
    handleNotifyChannelEdited(json) {
        json = json[0]; //Only one bulk
        let tree = this.connection._client.channelTree;
        let channel = tree.findChannel(json["cid"]);
        if (!channel) {
            console.error(_translations.jFySjD0I || (_translations.jFySjD0I = tr("Unknown channel edit (Channel)!")));
            return 0;
        }
        let updates = [];
        for (let key in json) {
            if (key === "cid")
                continue;
            if (key === "invokerid")
                continue;
            if (key === "invokername")
                continue;
            if (key === "invokeruid")
                continue;
            if (key === "reasonid")
                continue;
            updates.push({ key: key, value: json[key] });
        }
        channel.updateVariables(...updates);
    }
    handleNotifyTextMessage(json) {
        json = json[0]; //Only one bulk
        //TODO chat format?
        let mode = json["targetmode"];
        if (mode == 1) {
            let invoker = this.connection._client.channelTree.findClient(json["invokerid"]);
            let target = this.connection._client.channelTree.findClient(json["target"]);
            if (!invoker) { //TODO spawn chat (Client is may invisible)
                console.error(_translations.PLjb8d_b || (_translations.PLjb8d_b = tr("Got private message from invalid client!")));
                return;
            }
            if (!target) { //TODO spawn chat (Client is may invisible)
                console.error(_translations.eGNfPcZk || (_translations.eGNfPcZk = tr("Got private message from invalid client!")));
                return;
            }
            if (invoker == this.connection._client.getClient()) {
                sound.play(Sound.MESSAGE_SEND, { background_notification: true });
                target.chat(true).appendMessage("{0}: {1}", true, this.connection._client.getClient().createChatTag(true), json["msg"]);
            }
            else {
                sound.play(Sound.MESSAGE_RECEIVED, { background_notification: true });
                invoker.chat(true).appendMessage("{0}: {1}", true, ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"], true), json["msg"]);
            }
        }
        else if (mode == 2) {
            if (json["invokerid"] == this.connection._client.clientId)
                sound.play(Sound.MESSAGE_SEND, { background_notification: true });
            else
                sound.play(Sound.MESSAGE_RECEIVED, { background_notification: true });
            chat.channelChat().appendMessage("{0}: {1}", true, ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"], true), json["msg"]);
        }
        else if (mode == 3) {
            chat.serverChat().appendMessage("{0}: {1}", true, ClientEntry.chatTag(json["invokerid"], json["invokername"], json["invokeruid"], true), json["msg"]);
        }
    }
    handleNotifyClientUpdated(json) {
        json = json[0]; //Only one bulk
        let client = this.connection._client.channelTree.findClient(json["clid"]);
        if (!client) {
            console.error(_translations.EO5swjey || (_translations.EO5swjey = tr("Tried to update an non existing client")));
            return;
        }
        let updates = [];
        for (let key in json) {
            if (key == "clid")
                continue;
            updates.push({ key: key, value: json[key] });
        }
        client.updateVariables(...updates);
        if (this.connection._client.selectInfo.currentSelected == client)
            this.connection._client.selectInfo.update();
    }
    handleNotifyServerEdited(json) {
        json = json[0];
        let updates = [];
        for (let key in json) {
            if (key === "invokerid")
                continue;
            if (key === "invokername")
                continue;
            if (key === "invokeruid")
                continue;
            if (key === "reasonid")
                continue;
            updates.push({ key: key, value: json[key] });
        }
        this.connection._client.channelTree.server.updateVariables(false, ...updates);
        if (this.connection._client.selectInfo.currentSelected == this.connection._client.channelTree.server)
            this.connection._client.selectInfo.update();
    }
    handleNotifyServerUpdated(json) {
        json = json[0];
        let updates = [];
        for (let key in json) {
            if (key === "invokerid")
                continue;
            if (key === "invokername")
                continue;
            if (key === "invokeruid")
                continue;
            if (key === "reasonid")
                continue;
            updates.push({ key: key, value: json[key] });
        }
        this.connection._client.channelTree.server.updateVariables(true, ...updates);
        let info = this.connection._client.selectInfo;
        if (info.currentSelected instanceof ServerEntry)
            info.update();
    }
    handleNotifyMusicPlayerInfo(json) {
        json = json[0];
        let bot = this.connection._client.channelTree.find_client_by_dbid(json["bot_id"]);
        if (!bot || !(bot instanceof MusicClientEntry)) {
            log.warn(LogCategory.CLIENT, _translations.MEAMCLXl || (_translations.MEAMCLXl = tr("Got music player info for unknown or invalid bot! (ID: %i, Entry: %o)")), json["bot_id"], bot);
            return;
        }
        bot.handlePlayerInfo(json);
    }
    handleNotifyClientPoke(json) {
        json = json[0];
        Modals.spawnPoke({
            id: parseInt(json["invokerid"]),
            name: json["invokername"],
            unique_id: json["invokeruid"]
        }, json["msg"]);
        sound.play(Sound.USER_POKED_SELF);
    }
    //TODO server chat message
    handleNotifyServerGroupClientAdd(json) {
        json = json[0];
        const self = this.connection._client.getClient();
        if (json["clid"] == self.clientId())
            sound.play(Sound.GROUP_SERVER_ASSIGNED_SELF);
    }
    //TODO server chat message
    handleNotifyServerGroupClientRemove(json) {
        json = json[0];
        const self = this.connection._client.getClient();
        if (json["clid"] == self.clientId()) {
            sound.play(Sound.GROUP_SERVER_REVOKED_SELF);
        }
        else {
        }
    }
    //TODO server chat message
    handleNotifyClientChannelGroupChanged(json) {
        json = json[0];
        const self = this.connection._client.getClient();
        if (json["clid"] == self.clientId()) {
            sound.play(Sound.GROUP_CHANNEL_CHANGED_SELF);
        }
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["94e03b1121817a52aa859b4e2db82bb7266bcf108834e5a6a5021b98e982b6ec"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["94e03b1121817a52aa859b4e2db82bb7266bcf108834e5a6a5021b98e982b6ec"] = "94e03b1121817a52aa859b4e2db82bb7266bcf108834e5a6a5021b98e982b6ec";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="client.ts" />
if (typeof (customElements) !== "undefined") {
    class X_Properties extends HTMLElement {
    }
    class X_Property extends HTMLElement {
    }
    customElements.define('x-properties', X_Properties, { extends: 'div' });
    customElements.define('x-property', X_Property, { extends: 'div' });
}
class StaticSettings {
    static get instance() {
        if (!this._instance)
            this._instance = new StaticSettings(true);
        return this._instance;
    }
    static transformStO(input, _default) {
        if (typeof input === "undefined")
            return _default;
        if (typeof _default === "string")
            return input;
        else if (typeof _default === "number")
            return parseInt(input);
        else if (typeof _default === "boolean")
            return (input == "1" || input == "true");
        else if (typeof _default === "undefined")
            return input;
        return JSON.parse(input);
    }
    static transformOtS(input) {
        if (typeof input === "string")
            return input;
        else if (typeof input === "number")
            return input.toString();
        else if (typeof input === "boolean")
            return input ? "1" : "0";
        else if (typeof input === "undefined")
            return undefined;
        return JSON.stringify(input);
    }
    constructor(_reserved = undefined) {
        if (_reserved && !StaticSettings._instance) {
            this._staticPropsTag = $("#properties");
            this.initializeStatic();
        }
        else {
            this._handle = StaticSettings.instance;
        }
    }
    initializeStatic() {
        location.search.substr(1).split("&").forEach(part => {
            let item = part.split("=");
            $("<x-property></x-property>")
                .attr("key", item[0])
                .attr("value", item[1])
                .appendTo(this._staticPropsTag);
        });
    }
    static(key, _default) {
        if (this._handle)
            return this._handle.static(key, _default);
        let result = this._staticPropsTag.find("[key='" + key + "']");
        return StaticSettings.transformStO(result.length > 0 ? decodeURIComponent(result.last().attr("value")) : undefined, _default);
    }
    deleteStatic(key) {
        if (this._handle) {
            this._handle.deleteStatic(key);
            return;
        }
        let result = this._staticPropsTag.find("[key='" + key + "']");
        if (result.length != 0)
            result.detach();
    }
}
class Settings extends StaticSettings {
    constructor() {
        super();
        this.cacheGlobal = {};
        this.cacheServer = {};
        this.updated = false;
        this.cacheGlobal = JSON.parse(localStorage.getItem("settings.global"));
        if (!this.cacheGlobal)
            this.cacheGlobal = {};
        this.saveWorker = setInterval(() => {
            if (this.updated)
                this.save();
        }, 5 * 1000);
    }
    static_global(key, _default) {
        let _static = this.static(key);
        if (_static)
            return StaticSettings.transformStO(_static, _default);
        return this.global(key, _default);
    }
    global(key, _default) {
        let result = this.cacheGlobal[key];
        return StaticSettings.transformStO(result, _default);
    }
    server(key, _default) {
        let result = this.cacheServer[key];
        return StaticSettings.transformStO(result, _default);
    }
    changeGlobal(key, value) {
        if (this.cacheGlobal[key] == value)
            return;
        this.updated = true;
        this.cacheGlobal[key] = StaticSettings.transformOtS(value);
        if (Settings.UPDATE_DIRECT)
            this.save();
    }
    changeServer(key, value) {
        if (this.cacheServer[key] == value)
            return;
        this.updated = true;
        this.cacheServer[key] = StaticSettings.transformOtS(value);
        if (Settings.UPDATE_DIRECT)
            this.save();
    }
    setServer(server) {
        if (this.currentServer) {
            this.save();
            this.cacheServer = {};
            this.currentServer = undefined;
        }
        this.currentServer = server;
        if (this.currentServer) {
            let serverId = this.currentServer.properties.virtualserver_unique_identifier;
            this.cacheServer = JSON.parse(localStorage.getItem("settings.server_" + serverId));
            if (!this.cacheServer)
                this.cacheServer = {};
        }
    }
    save() {
        this.updated = false;
        if (this.currentServer) {
            let serverId = this.currentServer.properties.virtualserver_unique_identifier;
            let server = JSON.stringify(this.cacheServer);
            localStorage.setItem("settings.server_" + serverId, server);
        }
        let global = JSON.stringify(this.cacheGlobal);
        localStorage.setItem("settings.global", global);
    }
}
Settings.KEY_DISABLE_CONTEXT_MENU = "disableContextMenu";
Settings.KEY_DISABLE_UNLOAD_DIALOG = "disableUnloadDialog";
Settings.UPDATE_DIRECT = true;
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["0d0e8b8a935b2dbb09d4804a44485da66c5bc35ec727e3751206c913391087d2"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["0d0e8b8a935b2dbb09d4804a44485da66c5bc35ec727e3751206c913391087d2"] = "0d0e8b8a935b2dbb09d4804a44485da66c5bc35ec727e3751206c913391087d2";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/*
Copyright (C) 2011 Patrick Gillespie, http://patorjk.com/

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
/*
    Extendible BBCode Parser v1.0.0
    By Patrick Gillespie (patorjk@gmail.com)
    Website: http://patorjk.com/

    This module allows you to parse BBCode and to extend to the mark-up language
    to add in your own tags.
*/
var XBBCODE;
(function (XBBCODE) {
    // -----------------------------------------------------------------------------
    // Set up private variables
    // -----------------------------------------------------------------------------
    const urlPattern = /^(?:https?|file|c):(?:\/{1,3}|\\{1})[-a-zA-Z0-9:;,@#%&()~_?\+=\/\\\.]*$/, colorNamePattern = /^(?:aliceblue|antiquewhite|aqua|aquamarine|azure|beige|bisque|black|blanchedalmond|blue|blueviolet|brown|burlywood|cadetblue|chartreuse|chocolate|coral|cornflowerblue|cornsilk|crimson|cyan|darkblue|darkcyan|darkgoldenrod|darkgray|darkgreen|darkkhaki|darkmagenta|darkolivegreen|darkorange|darkorchid|darkred|darksalmon|darkseagreen|darkslateblue|darkslategray|darkturquoise|darkviolet|deeppink|deepskyblue|dimgray|dodgerblue|firebrick|floralwhite|forestgreen|fuchsia|gainsboro|ghostwhite|gold|goldenrod|gray|green|greenyellow|honeydew|hotpink|indianred|indigo|ivory|khaki|lavender|lavenderblush|lawngreen|lemonchiffon|lightblue|lightcoral|lightcyan|lightgoldenrodyellow|lightgray|lightgreen|lightpink|lightsalmon|lightseagreen|lightskyblue|lightslategray|lightsteelblue|lightyellow|lime|limegreen|linen|magenta|maroon|mediumaquamarine|mediumblue|mediumorchid|mediumpurple|mediumseagreen|mediumslateblue|mediumspringgreen|mediumturquoise|mediumvioletred|midnightblue|mintcream|mistyrose|moccasin|navajowhite|navy|oldlace|olive|olivedrab|orange|orangered|orchid|palegoldenrod|palegreen|paleturquoise|palevioletred|papayawhip|peachpuff|peru|pink|plum|powderblue|purple|red|rosybrown|royalblue|saddlebrown|salmon|sandybrown|seagreen|seashell|sienna|silver|skyblue|slateblue|slategray|snow|springgreen|steelblue|tan|teal|thistle|tomato|turquoise|violet|wheat|white|whitesmoke|yellow|yellowgreen)$/, colorCodePattern = /^#?[a-fA-F0-9]{6}$/, emailPattern = /[^\s@]+@[^\s@]+\.[^\s@]+/, fontFacePattern = /^([a-z][a-z0-9_]+|"[a-z][a-z0-9_\s]+")$/i;
    let tagList, tagsNoParseList = [], bbRegExp, pbbRegExp, pbbRegExp2, openTags, closeTags;
    /* -----------------------------------------------------------------------------
     * _tags
     * This object contains a list of _tags that your code will be able to understand.
     * Each tag object has the following properties:
     *
     *   openTag - A function that takes in the tag's parameters (if any) and its
     *             contents, and returns what its HTML open tag should be.
     *             Example: [color=red]test[/color] would take in "=red" as a
     *             parameter input, and "test" as a content input.
     *             It should be noted that any BBCode inside of "content" will have
     *             been processed by the time it enter the openTag function.
     *
     *   closeTag - A function that takes in the tag's parameters (if any) and its
     *              contents, and returns what its HTML close tag should be.
     *
     *   displayContent - Defaults to true. If false, the content for the tag will
     *                    not be displayed. This is useful for _tags like IMG where
     *                    its contents are actually a parameter input.
     *
     *   restrictChildrenTo - A list of BBCode _tags which are allowed to be nested
     *                        within this BBCode tag. If this property is omitted,
     *                        any BBCode tag may be nested within the tag.
     *
     *   restrictParentsTo - A list of BBCode _tags which are allowed to be parents of
     *                       this BBCode tag. If this property is omitted, any BBCode
     *                       tag may be a parent of the tag.
     *
     *   noParse - true or false. If true, none of the content WITHIN this tag will be
     *             parsed by the XBBCode parser.
     *
     *
     *
     * LIMITIONS on adding NEW TAGS:
     *  - Tag names should be alphanumeric (including underscores) and all _tags should have an opening tag
     *    and a closing tag.
     *    The [*] tag is an exception because it was already a standard
     *    bbcode tag. Technecially _tags don't *have* to be alphanumeric, but since
     *    regular expressions are used to parse the text, if you use a non-alphanumeric
     *    tag names, just make sure the tag name gets escaped properly (if needed).
     * --------------------------------------------------------------------------- */
    let _tags = {
        "b": {
            openTag: function (params, content) {
                return '<span class="xbbcode-b">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        /*
            This tag does nothing and is here mostly to be used as a classification for
            the bbcode input when evaluating parent-child tag relationships
        */
        "bbcode": {
            openTag: function (params, content) {
                return '';
            },
            closeTag: function (params, content) {
                return '';
            }
        },
        "center": {
            openTag: function (params, content) {
                return '<span class="xbbcode-center">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "code": {
            openTag: function (params, content) {
                return '<span class="xbbcode-code">';
            },
            closeTag: function (params, content) {
                return '</span>';
            },
            noParse: true
        },
        "color": {
            openTag: function (params, content) {
                params = params || '';
                var colorCode = (params.substr(1)).toLowerCase() || "black";
                colorNamePattern.lastIndex = 0;
                colorCodePattern.lastIndex = 0;
                if (!colorNamePattern.test(colorCode)) {
                    if (!colorCodePattern.test(colorCode)) {
                        colorCode = "black";
                    }
                    else {
                        if (colorCode.substr(0, 1) !== "#") {
                            colorCode = "#" + colorCode;
                        }
                    }
                }
                return '<span style="color:' + colorCode + '">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "email": {
            openTag: function (params, content) {
                var myEmail;
                if (!params) {
                    myEmail = content.replace(/<.*?>/g, "");
                }
                else {
                    myEmail = params.substr(1);
                }
                emailPattern.lastIndex = 0;
                if (!emailPattern.test(myEmail)) {
                    return '<a>';
                }
                return '<a href="mailto:' + myEmail + '">';
            },
            closeTag: function (params, content) {
                return '</a>';
            }
        },
        "face": {
            openTag: function (params, content) {
                params = params || '';
                var faceCode = params.substr(1) || "inherit";
                fontFacePattern.lastIndex = 0;
                if (!fontFacePattern.test(faceCode)) {
                    faceCode = "inherit";
                }
                return '<span style="font-family:' + faceCode + '">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "font": {
            openTag: function (params, content) {
                params = params || '';
                var faceCode = params.substr(1) || "inherit";
                fontFacePattern.lastIndex = 0;
                if (!fontFacePattern.test(faceCode)) {
                    faceCode = "inherit";
                }
                return '<span style="font-family:' + faceCode + '">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "i": {
            openTag: function (params, content) {
                return '<span class="xbbcode-i">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "img": {
            openTag: function (params, content) {
                var myUrl = content;
                urlPattern.lastIndex = 0;
                if (!urlPattern.test(myUrl)) {
                    myUrl = "";
                }
                return '<img src="' + myUrl + '" />';
            },
            closeTag: function (params, content) {
                return '';
            },
            displayContent: false
        },
        "justify": {
            openTag: function (params, content) {
                return '<span class="xbbcode-justify">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "large": {
            openTag: function (params, content) {
                params = params || '';
                var colorCode = params.substr(1) || "inherit";
                colorNamePattern.lastIndex = 0;
                colorCodePattern.lastIndex = 0;
                if (!colorNamePattern.test(colorCode)) {
                    if (!colorCodePattern.test(colorCode)) {
                        colorCode = "inherit";
                    }
                    else {
                        if (colorCode.substr(0, 1) !== "#") {
                            colorCode = "#" + colorCode;
                        }
                    }
                }
                return '<span class="xbbcode-size-36" style="color:' + colorCode + '">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "left": {
            openTag: function (params, content) {
                return '<span class="xbbcode-left">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "li": {
            openTag: function (params, content) {
                return "<li>";
            },
            closeTag: function (params, content) {
                return "</li>";
            },
            restrictParentsTo: ["list", "ul", "ol"]
        },
        "list": {
            openTag: function (params, content) {
                return '<ul>';
            },
            closeTag: function (params, content) {
                return '</ul>';
            },
            restrictChildrenTo: ["*", "li"]
        },
        "noparse": {
            openTag: function (params, content) {
                return '';
            },
            closeTag: function (params, content) {
                return '';
            },
            noParse: true
        },
        "ol": {
            openTag: function (params, content) {
                return '<ol>';
            },
            closeTag: function (params, content) {
                return '</ol>';
            },
            restrictChildrenTo: ["*", "li"]
        },
        "php": {
            openTag: function (params, content) {
                return '<span class="xbbcode-code">';
            },
            closeTag: function (params, content) {
                return '</span>';
            },
            noParse: true
        },
        "quote": {
            openTag: function (params, content) {
                return '<blockquote class="xbbcode-blockquote">';
            },
            closeTag: function (params, content) {
                return '</blockquote>';
            }
        },
        "right": {
            openTag: function (params, content) {
                return '<span class="xbbcode-right">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "s": {
            openTag: function (params, content) {
                return '<span class="xbbcode-s">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "size": {
            openTag: function (params, content) {
                params = params || '';
                var mySize = parseInt(params.substr(1), 10) || 0;
                if (mySize < 4 || mySize > 40) {
                    mySize = 14;
                }
                return '<span class="xbbcode-size-' + mySize + '">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "small": {
            openTag: function (params, content) {
                params = params || '';
                var colorCode = params.substr(1) || "inherit";
                colorNamePattern.lastIndex = 0;
                colorCodePattern.lastIndex = 0;
                if (!colorNamePattern.test(colorCode)) {
                    if (!colorCodePattern.test(colorCode)) {
                        colorCode = "inherit";
                    }
                    else {
                        if (colorCode.substr(0, 1) !== "#") {
                            colorCode = "#" + colorCode;
                        }
                    }
                }
                return '<span class="xbbcode-size-10" style="color:' + colorCode + '">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "sub": {
            openTag: function (params, content) {
                return '<sub>';
            },
            closeTag: function (params, content) {
                return '</sub>';
            }
        },
        "sup": {
            openTag: function (params, content) {
                return '<sup>';
            },
            closeTag: function (params, content) {
                return '</sup>';
            }
        },
        "table": {
            openTag: function (params, content) {
                return '<table class="xbbcode-table">';
            },
            closeTag: function (params, content) {
                return '</table>';
            },
            restrictChildrenTo: ["tbody", "thead", "tfoot", "tr"]
        },
        "tbody": {
            openTag: function (params, content) {
                return '<tbody>';
            },
            closeTag: function (params, content) {
                return '</tbody>';
            },
            restrictChildrenTo: ["tr"],
            restrictParentsTo: ["table"]
        },
        "tfoot": {
            openTag: function (params, content) {
                return '<tfoot>';
            },
            closeTag: function (params, content) {
                return '</tfoot>';
            },
            restrictChildrenTo: ["tr"],
            restrictParentsTo: ["table"]
        },
        "thead": {
            openTag: function (params, content) {
                return '<thead class="xbbcode-thead">';
            },
            closeTag: function (params, content) {
                return '</thead>';
            },
            restrictChildrenTo: ["tr"],
            restrictParentsTo: ["table"]
        },
        "td": {
            openTag: function (params, content) {
                return '<td class="xbbcode-td">';
            },
            closeTag: function (params, content) {
                return '</td>';
            },
            restrictParentsTo: ["tr"]
        },
        "th": {
            openTag: function (params, content) {
                return '<th class="xbbcode-th">';
            },
            closeTag: function (params, content) {
                return '</th>';
            },
            restrictParentsTo: ["tr"]
        },
        "tr": {
            openTag: function (params, content) {
                return '<tr class="xbbcode-tr">';
            },
            closeTag: function (params, content) {
                return '</tr>';
            },
            restrictChildrenTo: ["td", "th"],
            restrictParentsTo: ["table", "tbody", "tfoot", "thead"]
        },
        "u": {
            openTag: function (params, content) {
                return '<span class="xbbcode-u">';
            },
            closeTag: function (params, content) {
                return '</span>';
            }
        },
        "ul": {
            openTag: function (params, content) {
                return '<ul>';
            },
            closeTag: function (params, content) {
                return '</ul>';
            },
            restrictChildrenTo: ["*", "li"]
        },
        "url": {
            openTag: function (params, content) {
                let myUrl;
                if (!params) {
                    myUrl = content.replace(/<.*?>/g, "");
                }
                else {
                    myUrl = params.substr(1);
                }
                urlPattern.lastIndex = 0;
                if (!urlPattern.test(myUrl)) {
                    myUrl = "#";
                }
                return '<a href="' + myUrl + '" target="_blank">';
            },
            closeTag: function (params, content) {
                return '</a>';
            }
        },
        /*
            The [*] tag is special since the user does not define a closing [/*] tag when writing their bbcode.
            Instead this module parses the code and adds the closing [/*] tag in for them. None of the _tags you
            add will act like this and this tag is an exception to the others.
        */
        "*": {
            openTag: function (params, content) {
                return "<li>";
            },
            closeTag: function (params, content) {
                return "</li>";
            },
            restrictParentsTo: ["list", "ul", "ol"]
        }
    };
    // create tag list and lookup fields
    function initTags() {
        tagList = [];
        let prop, ii, len;
        for (prop in _tags) {
            if (_tags.hasOwnProperty(prop)) {
                if (prop === "*") {
                    tagList.push("\\" + prop);
                }
                else {
                    tagList.push(prop);
                    if (_tags[prop].noParse) {
                        tagsNoParseList.push(prop);
                    }
                }
                _tags[prop].validChildLookup = {};
                _tags[prop].validParentLookup = {};
                _tags[prop].restrictParentsTo = _tags[prop].restrictParentsTo || [];
                _tags[prop].restrictChildrenTo = _tags[prop].restrictChildrenTo || [];
                len = _tags[prop].restrictChildrenTo.length;
                for (ii = 0; ii < len; ii++) {
                    _tags[prop].validChildLookup[_tags[prop].restrictChildrenTo[ii]] = true;
                }
                len = _tags[prop].restrictParentsTo.length;
                for (ii = 0; ii < len; ii++) {
                    _tags[prop].validParentLookup[_tags[prop].restrictParentsTo[ii]] = true;
                }
            }
        }
        bbRegExp = new RegExp("<bbcl=([0-9]+) (" + tagList.join("|") + ")([ =][^>]*?)?>((?:.|[\\r\\n])*?)<bbcl=\\1 /\\2>", "gi");
        pbbRegExp = new RegExp("\\[(" + tagList.join("|") + ")([ =][^\\]]*?)?\\]([^\\[]*?)\\[/\\1\\]", "gi");
        pbbRegExp2 = new RegExp("\\[(" + tagsNoParseList.join("|") + ")([ =][^\\]]*?)?\\]([\\s\\S]*?)\\[/\\1\\]", "gi");
        // create the regex for escaping ['s that aren't apart of _tags
        (function () {
            var closeTagList = [];
            for (var ii = 0; ii < tagList.length; ii++) {
                if (tagList[ii] !== "\\*") { // the * tag doesn't have an offical closing tag
                    closeTagList.push("/" + tagList[ii]);
                }
            }
            openTags = new RegExp("(\\[)((?:" + tagList.join("|") + ")(?:[ =][^\\]]*?)?)(\\])", "gi");
            closeTags = new RegExp("(\\[)(" + closeTagList.join("|") + ")(\\])", "gi");
        })();
    }
    initTags();
    // -----------------------------------------------------------------------------
    // private functions
    // -----------------------------------------------------------------------------
    function checkParentChildRestrictions(parentTag, bbcode, bbcodeLevel, tagName, tagParams, tagContents, errQueue) {
        errQueue = errQueue || [];
        bbcodeLevel++;
        // get a list of all of the child _tags to this tag
        var reTagNames = new RegExp("(<bbcl=" + bbcodeLevel + " )(" + tagList.join("|") + ")([ =>])", "gi"), reTagNamesParts = new RegExp("(<bbcl=" + bbcodeLevel + " )(" + tagList.join("|") + ")([ =>])", "i"), matchingTags = tagContents.match(reTagNames) || [], cInfo, errStr, ii, childTag, pInfo = _tags[parentTag] || {};
        reTagNames.lastIndex = 0;
        if (!matchingTags) {
            tagContents = "";
        }
        for (ii = 0; ii < matchingTags.length; ii++) {
            reTagNamesParts.lastIndex = 0;
            childTag = (matchingTags[ii].match(reTagNamesParts))[2].toLowerCase();
            if (pInfo && pInfo.restrictChildrenTo && pInfo.restrictChildrenTo.length > 0) {
                if (!pInfo.validChildLookup[childTag]) {
                    errStr = "The tag \"" + childTag + "\" is not allowed as a child of the tag \"" + parentTag + "\".";
                    errQueue.push(errStr);
                }
            }
            cInfo = _tags[childTag] || {};
            if (cInfo.restrictParentsTo.length > 0) {
                if (!cInfo.validParentLookup[parentTag]) {
                    errStr = "The tag \"" + parentTag + "\" is not allowed as a parent of the tag \"" + childTag + "\".";
                    errQueue.push(errStr);
                }
            }
        }
        tagContents = tagContents.replace(bbRegExp, function (matchStr, bbcodeLevel, tagName, tagParams, tagContents) {
            errQueue = checkParentChildRestrictions(tagName.toLowerCase(), matchStr, bbcodeLevel, tagName, tagParams, tagContents, errQueue);
            return matchStr;
        });
        return errQueue;
    }
    /*
        This function updates or adds a piece of metadata to each tag called "bbcl" which
        indicates how deeply nested a particular tag was in the bbcode. This property is removed
        from the HTML code _tags at the end of the processing.
    */
    function updateTagDepths(tagContents) {
        tagContents = tagContents.replace(/\<([^\>][^\>]*?)\>/gi, function (matchStr, subMatchStr) {
            var bbCodeLevel = subMatchStr.match(/^bbcl=([0-9]+) /);
            if (bbCodeLevel === null) {
                return "<bbcl=0 " + subMatchStr + ">";
            }
            else {
                return "<" + subMatchStr.replace(/^(bbcl=)([0-9]+)/, function (matchStr, m1, m2) {
                    return m1 + (parseInt(m2, 10) + 1);
                }) + ">";
            }
        });
        return tagContents;
    }
    /*
        This function removes the metadata added by the updateTagDepths function
    */
    function unprocess(tagContent) {
        return tagContent.replace(/<bbcl=[0-9]+ \/\*>/gi, "").replace(/<bbcl=[0-9]+ /gi, "&#91;").replace(/>/gi, "&#93;");
    }
    var replaceFunct = function (matchStr, bbcodeLevel, tagName, tagParams, tagContents) {
        tagName = tagName.toLowerCase();
        var processedContent = _tags[tagName].noParse ? unprocess(tagContents) : tagContents.replace(bbRegExp, replaceFunct), openTag = _tags[tagName].openTag(tagParams, processedContent), closeTag = _tags[tagName].closeTag(tagParams, processedContent);
        if (_tags[tagName].displayContent === false) {
            processedContent = "";
        }
        return openTag + processedContent + closeTag;
    };
    function parse(config) {
        var output = config.text;
        output = output.replace(bbRegExp, replaceFunct);
        return output;
    }
    /*
        The star tag [*] is special in that it does not use a closing tag. Since this parser requires that _tags to have a closing
        tag, we must pre-process the input and add in closing _tags [/*] for the star tag.
        We have a little levaridge in that we know the text we're processing wont contain the <> characters (they have been
        changed into their HTML entity form to prevent XSS and code injection), so we can use those characters as markers to
        help us define boundaries and figure out where to place the [/*] _tags.
    */
    function fixStarTag(text) {
        text = text.replace(/\[(?!\*[ =\]]|list([ =][^\]]*)?\]|\/list[\]])/ig, "<");
        text = text.replace(/\[(?=list([ =][^\]]*)?\]|\/list[\]])/ig, ">");
        while (text !== (text = text.replace(/>list([ =][^\]]*)?\]([^>]*?)(>\/list])/gi, function (matchStr, contents, endTag) {
            var innerListTxt = matchStr;
            while (innerListTxt !== (innerListTxt = innerListTxt.replace(/\[\*\]([^\[]*?)(\[\*\]|>\/list])/i, function (matchStr, contents, endTag) {
                if (endTag.toLowerCase() === ">/list]") {
                    endTag = "</*]</list]";
                }
                else {
                    endTag = "</*][*]";
                }
                return "<*]" + contents + endTag;
            })))
                ;
            innerListTxt = innerListTxt.replace(/>/g, "<");
            return innerListTxt;
        })))
            ;
        // add ['s for our _tags back in
        text = text.replace(/</g, "[");
        return text;
    }
    function addBbcodeLevels(text) {
        while (text !== (text = text.replace(pbbRegExp, function (matchStr, tagName, tagParams, tagContents) {
            matchStr = matchStr.replace(/\[/g, "<");
            matchStr = matchStr.replace(/\]/g, ">");
            return updateTagDepths(matchStr);
        })))
            ;
        return text;
    }
    // -----------------------------------------------------------------------------
    // public functions
    // -----------------------------------------------------------------------------
    // API, Expose all available _tags
    function tags() {
        return _tags;
    }
    XBBCODE.tags = tags;
    ;
    // API
    function addTags(newtags) {
        var tag;
        for (tag in newtags) {
            tags[tag] = newtags[tag];
        }
        initTags();
    }
    XBBCODE.addTags = addTags;
    ;
    class ProcessResult {
    }
    XBBCODE.ProcessResult = ProcessResult;
    function process(config) {
        let result = new ProcessResult();
        result.errorQueue = [];
        config.text = config.text.replace(/</g, "&lt;"); // escape HTML tag brackets
        config.text = config.text.replace(/>/g, "&gt;"); // escape HTML tag brackets
        config.text = config.text.replace(openTags, function (matchStr, openB, contents, closeB) {
            return "<" + contents + ">";
        });
        config.text = config.text.replace(closeTags, function (matchStr, openB, contents, closeB) {
            return "<" + contents + ">";
        });
        config.text = config.text.replace(/\[/g, "&#91;"); // escape ['s that aren't apart of _tags
        config.text = config.text.replace(/\]/g, "&#93;"); // escape ['s that aren't apart of _tags
        config.text = config.text.replace(/</g, "["); // escape ['s that aren't apart of _tags
        config.text = config.text.replace(/>/g, "]"); // escape ['s that aren't apart of _tags
        // process _tags that don't have their content parsed
        while (config.text !== (config.text = config.text.replace(pbbRegExp2, function (matchStr, tagName, tagParams, tagContents) {
            tagContents = tagContents.replace(/\[/g, "&#91;");
            tagContents = tagContents.replace(/\]/g, "&#93;");
            tagParams = tagParams || "";
            tagContents = tagContents || "";
            return "[" + tagName + tagParams + "]" + tagContents + "[/" + tagName + "]";
        })))
            ;
        config.text = fixStarTag(config.text); // add in closing _tags for the [*] tag
        config.text = addBbcodeLevels(config.text); // add in level metadata
        result.errorQueue = checkParentChildRestrictions("bbcode", config.text, -1, "", "", config.text);
        result.html = parse(config);
        if (result.html.indexOf("[") !== -1 || result.html.indexOf("]") !== -1) {
            result.errorQueue.push("Some _tags appear to be misaligned.");
        }
        if (config.removeMisalignedTags) {
            result.html = result.html.replace(/\[.*?\]/g, "");
        }
        if (config.addInLineBreaks) {
            result.html = '<div style="white-space:pre-wrap;" class="xbbcode">' + result.html + '</div>';
        }
        if (!config.escapeHtml) {
            result.html = result.html.replace("&#91;", "["); // put ['s back in
            result.html = result.html.replace("&#93;", "]"); // put ['s back in
        }
        if (result.errorQueue.length == 0) {
            result.error = false;
            result.errorQueue = undefined;
        }
        else {
            result.error = true;
        }
        return result;
    }
    XBBCODE.process = process;
    ;
})(XBBCODE || (XBBCODE = {}));
// for node
if (typeof module !== "undefined") {
    module.exports = XBBCODE;
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["70b9d19c8f245c9cea5ce28a7ba2eb5fab1e144b78bc4d6d033718621ec30b6e"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["70b9d19c8f245c9cea5ce28a7ba2eb5fab1e144b78bc4d6d033718621ec30b6e"] = "70b9d19c8f245c9cea5ce28a7ba2eb5fab1e144b78bc4d6d033718621ec30b6e";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "FcCf8Mp2", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (95,21)" }, { name: "Fj712FEm", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (139,30)" }, { name: "dX7xdIIx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (163,31)" }, { name: "n80GlVj5", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (400,49)" }, { name: "fjJocmpR", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (402,60)" }, { name: "zPnZh7o3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (410,69)" }, { name: "SMfKN85w", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (430,54)" }, { name: "BjfKw86L", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (430,112)" }, { name: "gFbMXxFO", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (443,54)" }, { name: "dnjCOY_f", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (443,113)" }, { name: "enViXCF2", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (455,50)" }, { name: "nmUwa4m8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (455,108)" }, { name: "h0iro_2e", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (478,50)" }, { name: "myXJpz7t", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (478,83)" }, { name: "vCOFG2RW", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (487,50)" }, { name: "KZskzQ3f", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (487,81)" }, { name: "pzRFqwNo", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (492,46)" }, { name: "_7NksefN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (492,69)" }, { name: "Vlbpd2SQ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (629,25)" }, { name: "YnrHpMBg", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (630,25)" }, { name: "n1Ug4iv3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/SelectedItemInfo.ts (631,25)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../client.ts" />
/// <reference path="../../../../vendor/bbcode/xbbcode.ts" />
class InfoManagerBase {
    constructor() {
        this.timers = [];
        this.intervals = [];
    }
    resetTimers() {
        for (let timer of this.timers)
            clearTimeout(timer);
        this.timers = [];
    }
    resetIntervals() {
        for (let interval of this.intervals)
            clearInterval(interval);
        this.intervals = [];
    }
    registerTimer(timer) {
        this.timers.push(timer);
    }
    registerInterval(interval) {
        this.intervals.push(interval);
    }
}
class InfoManager extends InfoManagerBase {
    createFrame(handle, object, html_tag) {
        this.handle = handle;
    }
    finalizeFrame(object, frame) {
        this.resetIntervals();
        this.resetTimers();
        this.handle = undefined;
    }
    triggerUpdate() {
        if (this.handle)
            this.handle.update();
    }
}
class InfoBar {
    constructor(client, htmlTag) {
        this.current_manager = undefined;
        this.managers = [];
        this.handle = client;
        this._htmlTag = htmlTag;
        this._tag_info = htmlTag.find(".container-select-info");
        this._tag_banner = htmlTag.find(".container-banner");
        this.managers.push(new MusicInfoManager());
        this.managers.push(new ClientInfoManager());
        this.managers.push(new ChannelInfoManager());
        this.managers.push(new ServerInfoManager());
        this.banner_manager = new Hostbanner(client, this._tag_banner);
    }
    setCurrentSelected(entry) {
        if (this.current_selected == entry)
            return;
        if (this.current_manager) {
            this.current_manager.finalizeFrame(this.current_selected, this._tag_info);
            this.current_manager = null;
            this.current_selected = null;
        }
        this._tag_info.empty();
        this.current_selected = entry;
        for (let manager of this.managers) {
            if (manager.available(this.current_selected)) {
                this.current_manager = manager;
                break;
            }
        }
        console.log(_translations.FcCf8Mp2 || (_translations.FcCf8Mp2 = tr("Using info manager: %o")), this.current_manager);
        if (this.current_manager)
            this.current_manager.createFrame(this, this.current_selected, this._tag_info);
    }
    get currentSelected() {
        return this.current_selected;
    }
    update() {
        if (this.current_manager && this.current_selected)
            this.current_manager.updateFrame(this.current_selected, this._tag_info);
    }
    update_banner() {
        this.banner_manager.update();
    }
}
class Hostbanner {
    constructor(client, htmlTag) {
        this.client = client;
        this.html_tag = htmlTag;
    }
    update() {
        if (this.updater) {
            clearTimeout(this.updater);
            this.updater = undefined;
        }
        const tag = this.generate_tag();
        if (tag) {
            tag.then(element => {
                this.html_tag.empty();
                this.html_tag.append(element).removeClass("disabled");
            }).catch(error => {
                console.warn(_translations.Fj712FEm || (_translations.Fj712FEm = tr("Failed to load hostbanner: %o")), error);
                this.html_tag.empty().addClass("disabled");
            });
        }
        else {
            this.html_tag.empty().addClass("disabled");
        }
    }
    generate_tag() {
        if (!this.client.connected)
            return undefined;
        const server = this.client.channelTree.server;
        if (!server)
            return undefined;
        if (!server.properties.virtualserver_hostbanner_gfx_url)
            return undefined;
        let properties = {};
        for (let key in server.properties)
            properties["property_" + key] = server.properties[key];
        const rendered = $("#tmpl_selected_hostbanner").renderTag(properties);
        const image = rendered.find("img");
        return new Promise((resolve, reject) => {
            const node_image = image[0];
            node_image.onload = () => {
                console.debug(_translations.dX7xdIIx || (_translations.dX7xdIIx = tr("Hostbanner has been loaded")));
                if (server.properties.virtualserver_hostbanner_gfx_interval > 0)
                    this.updater = setTimeout(() => this.update(), Math.min(server.properties.virtualserver_hostbanner_gfx_interval, 60) * 1000);
                resolve(rendered);
            };
            node_image.onerror = event => {
                reject(event);
            };
        });
    }
}
class ClientInfoManager extends InfoManager {
    available(object) {
        return typeof object == "object" && object instanceof ClientEntry;
    }
    createFrame(handle, client, html_tag) {
        super.createFrame(handle, client, html_tag);
        client.updateClientVariables();
        this.updateFrame(client, html_tag);
    }
    updateFrame(client, html_tag) {
        this.resetIntervals();
        html_tag.empty();
        let properties = this.buildProperties(client);
        let rendered = $("#tmpl_selected_client").renderTag(properties);
        html_tag.append(rendered);
        this.registerInterval(setInterval(() => {
            html_tag.find(".update_onlinetime").text(formatDate(client.calculateOnlineTime()));
        }, 1000));
    }
    buildProperties(client) {
        let properties = {};
        properties["client_name"] = client.createChatTag()[0];
        properties["client_onlinetime"] = formatDate(client.calculateOnlineTime());
        properties["sound_volume"] = client.audioController.volume * 100;
        properties["group_server"] = [];
        for (let groupId of client.assignedServerGroupIds()) {
            let group = client.channelTree.client.groups.serverGroup(groupId);
            if (!group)
                continue;
            let group_property = {};
            group_property["group_id"] = groupId;
            group_property["group_name"] = group.name;
            properties["group_server"].push(group_property);
            properties["group_" + groupId + "_icon"] = client.channelTree.client.fileManager.icons.generateTag(group.properties.iconid);
        }
        let group = client.channelTree.client.groups.channelGroup(client.assignedChannelGroup());
        if (group) {
            properties["group_channel"] = group.id;
            properties["group_" + group.id + "_name"] = group.name;
            properties["group_" + group.id + "_icon"] = client.channelTree.client.fileManager.icons.generateTag(group.properties.iconid);
        }
        for (let key in client.properties)
            properties["property_" + key] = client.properties[key];
        if (client.properties.client_teaforum_id > 0) {
            properties["teaspeak_forum"] = $.spawn("a")
                .attr("href", "//forum.teaspeak.de/index.php?members/" + client.properties.client_teaforum_id)
                .attr("target", "_blank")
                .text(client.properties.client_teaforum_id);
        }
        if (client.properties.client_flag_avatar && client.properties.client_flag_avatar.length > 0) {
            properties["client_avatar"] = client.channelTree.client.fileManager.avatars.generateTag(client);
        }
        return properties;
    }
}
class ServerInfoManager extends InfoManager {
    createFrame(handle, server, html_tag) {
        super.createFrame(handle, server, html_tag);
        if (server.shouldUpdateProperties())
            server.updateProperties();
        this.updateFrame(server, html_tag);
    }
    updateFrame(server, html_tag) {
        this.resetIntervals();
        html_tag.empty();
        let properties = {};
        properties["server_name"] = $.spawn("a").text(server.properties.virtualserver_name);
        properties["server_onlinetime"] = formatDate(server.calculateUptime());
        properties["server_address"] = server.remote_address.host + ":" + server.remote_address.port;
        for (let key in server.properties)
            properties["property_" + key] = server.properties[key];
        let rendered = $("#tmpl_selected_server").renderTag([properties]);
        this.registerInterval(setInterval(() => {
            html_tag.find(".update_onlinetime").text(formatDate(server.calculateUptime()));
        }, 1000));
        {
            let requestUpdate = rendered.find(".btn_update");
            requestUpdate.prop("disabled", !server.shouldUpdateProperties());
            requestUpdate.click(() => {
                server.updateProperties();
                this.triggerUpdate();
            });
            this.registerTimer(setTimeout(function () {
                requestUpdate.prop("disabled", false);
            }, server.nextInfoRequest - Date.now()));
        }
        html_tag.append(rendered);
    }
    available(object) {
        return typeof object == "object" && object instanceof ServerEntry;
    }
}
class ChannelInfoManager extends InfoManager {
    createFrame(handle, channel, html_tag) {
        super.createFrame(handle, channel, html_tag);
        this.updateFrame(channel, html_tag);
    }
    updateFrame(channel, html_tag) {
        this.resetIntervals();
        html_tag.empty();
        let properties = {};
        properties["channel_name"] = channel.createChatTag();
        properties["channel_type"] = ChannelType.normalize(channel.channelType());
        properties["channel_clients"] = channel.channelTree.clientsByChannel(channel).length;
        properties["channel_subscribed"] = true; //TODO
        properties["server_encryption"] = channel.channelTree.server.properties.virtualserver_codec_encryption_mode;
        for (let key in channel.properties)
            properties["property_" + key] = channel.properties[key];
        let tag_channel_description = $.spawn("div");
        properties["bbcode_channel_description"] = tag_channel_description;
        channel.getChannelDescription().then(description => {
            let result = XBBCODE.process({
                text: description,
                escapeHtml: true,
                addInLineBreaks: true
            });
            if (result.error) {
                console.log("BBCode parse error: %o", result.errorQueue);
            }
            tag_channel_description.html(result.html)
                .css("overflow-y", "auto")
                .css("flex-grow", "1");
        });
        let rendered = $("#tmpl_selected_channel").renderTag([properties]);
        html_tag.append(rendered);
    }
    available(object) {
        return typeof object == "object" && object instanceof ChannelEntry;
    }
}
function format_time(time) {
    let hours = 0, minutes = 0, seconds = 0;
    if (time >= 60 * 60) {
        hours = Math.floor(time / (60 * 60));
        time -= hours * 60 * 60;
    }
    if (time >= 60) {
        minutes = Math.floor(time / 60);
        time -= minutes * 60;
    }
    seconds = time;
    if (hours > 9)
        hours = hours.toString();
    else if (hours > 0)
        hours = '0' + hours.toString();
    else
        hours = '';
    if (minutes > 9)
        minutes = minutes.toString();
    else if (minutes > 0)
        minutes = '0' + minutes.toString();
    else
        minutes = '00';
    if (seconds > 9)
        seconds = seconds.toString();
    else if (seconds > 0)
        seconds = '0' + seconds.toString();
    else
        seconds = '00';
    return (hours ? hours + ":" : "") + minutes + ':' + seconds;
}
var MusicPlayerState;
(function (MusicPlayerState) {
    MusicPlayerState[MusicPlayerState["SLEEPING"] = 0] = "SLEEPING";
    MusicPlayerState[MusicPlayerState["LOADING"] = 1] = "LOADING";
    MusicPlayerState[MusicPlayerState["PLAYING"] = 2] = "PLAYING";
    MusicPlayerState[MusicPlayerState["PAUSED"] = 3] = "PAUSED";
    MusicPlayerState[MusicPlayerState["STOPPED"] = 4] = "STOPPED";
})(MusicPlayerState || (MusicPlayerState = {}));
class MusicInfoManager extends ClientInfoManager {
    createFrame(handle, channel, html_tag) {
        super.createFrame(handle, channel, html_tag);
        this.updateFrame(channel, html_tag);
    }
    updateFrame(bot, html_tag) {
        this.resetIntervals();
        html_tag.empty();
        let properties = super.buildProperties(bot);
        { //Render info frame
            if (bot.properties.player_state < MusicPlayerState.PLAYING) {
                properties["music_player"] = $("#tmpl_music_frame_empty").renderTag().css("align-self", "center");
            }
            else {
                let frame = $.spawn("div").text(_translations.n80GlVj5 || (_translations.n80GlVj5 = tr("loading...")));
                properties["music_player"] = frame;
                properties["song_url"] = $.spawn("a").text(_translations.fjJocmpR || (_translations.fjJocmpR = tr("loading...")));
                bot.requestPlayerInfo().then(info => {
                    let timestamp = Date.now();
                    console.log(info);
                    let _frame = $("#tmpl_music_frame").renderTag({
                        song_name: info.player_title ? info.player_title :
                            info.song_url ? info.song_url : _translations.zPnZh7o3 || (_translations.zPnZh7o3 = tr("No title or url")),
                        song_url: info.song_url,
                        thumbnail: info.song_thumbnail && info.song_thumbnail.length > 0 ? info.song_thumbnail : undefined
                    }).css("align-self", "center");
                    properties["song_url"].text(info.song_url);
                    frame.replaceWith(_frame);
                    frame = _frame;
                    /* Play/Pause logic */
                    {
                        let button_play = frame.find(".button_play");
                        let button_pause = frame.find(".button_pause");
                        let button_stop = frame.find('.button_stop');
                        button_play.click(handler => {
                            if (!button_play.hasClass("active")) {
                                this.handle.handle.serverConnection.sendCommand("musicbotplayeraction", {
                                    bot_id: bot.properties.client_database_id,
                                    action: 1
                                }).then(updated => this.triggerUpdate()).catch(error => {
                                    createErrorModal(_translations.SMfKN85w || (_translations.SMfKN85w = tr("Failed to execute play")), MessageHelper.formatMessage(_translations.BjfKw86L || (_translations.BjfKw86L = tr("Failed to execute play.<br>{}")), error)).open();
                                    this.triggerUpdate();
                                });
                            }
                            button_pause.show();
                            button_play.hide();
                        });
                        button_pause.click(handler => {
                            if (!button_pause.hasClass("active")) {
                                this.handle.handle.serverConnection.sendCommand("musicbotplayeraction", {
                                    bot_id: bot.properties.client_database_id,
                                    action: 2
                                }).then(updated => this.triggerUpdate()).catch(error => {
                                    createErrorModal(_translations.gFbMXxFO || (_translations.gFbMXxFO = tr("Failed to execute pause")), MessageHelper.formatMessage(_translations.dnjCOY_f || (_translations.dnjCOY_f = tr("Failed to execute pause.<br>{}")), error)).open();
                                    this.triggerUpdate();
                                });
                            }
                            button_play.show();
                            button_pause.hide();
                        });
                        button_stop.click(handler => {
                            this.handle.handle.serverConnection.sendCommand("musicbotplayeraction", {
                                bot_id: bot.properties.client_database_id,
                                action: 0
                            }).then(updated => this.triggerUpdate()).catch(error => {
                                createErrorModal(_translations.enViXCF2 || (_translations.enViXCF2 = tr("Failed to execute stop")), MessageHelper.formatMessage(_translations.nmUwa4m8 || (_translations.nmUwa4m8 = tr("Failed to execute stop.<br>{}")), error)).open();
                                this.triggerUpdate();
                            });
                        });
                        if (bot.properties.player_state == 2) {
                            button_play.hide();
                            button_pause.show();
                        }
                        else if (bot.properties.player_state == 3) {
                            button_pause.hide();
                            button_play.show();
                        }
                        else if (bot.properties.player_state == 4) {
                            button_pause.hide();
                            button_play.show();
                        }
                    }
                    { /* Button functions */
                        _frame.find(".btn-forward").click(() => {
                            this.handle.handle.serverConnection.sendCommand("musicbotplayeraction", {
                                bot_id: bot.properties.client_database_id,
                                action: 3
                            }).then(updated => this.triggerUpdate()).catch(error => {
                                createErrorModal(_translations.h0iro_2e || (_translations.h0iro_2e = tr("Failed to execute forward")), (_translations.myXJpz7t || (_translations.myXJpz7t = tr("Failed to execute pause.<br>{}"))).format(error)).open();
                                this.triggerUpdate();
                            });
                        });
                        _frame.find(".btn-rewind").click(() => {
                            this.handle.handle.serverConnection.sendCommand("musicbotplayeraction", {
                                bot_id: bot.properties.client_database_id,
                                action: 4
                            }).then(updated => this.triggerUpdate()).catch(error => {
                                createErrorModal(_translations.vCOFG2RW || (_translations.vCOFG2RW = tr("Failed to execute rewind")), (_translations.KZskzQ3f || (_translations.KZskzQ3f = tr("Failed to execute pause.<br>{}"))).format(error)).open();
                                this.triggerUpdate();
                            });
                        });
                        _frame.find(".btn-settings").click(() => {
                            createErrorModal(_translations.pzRFqwNo || (_translations.pzRFqwNo = tr("Not implemented")), _translations._7NksefN || (_translations._7NksefN = tr("This function is not implemented yet!"))).open();
                        });
                    }
                    /* Required flip card javascript */
                    frame.find(".right").mouseenter(() => {
                        frame.find(".controls-overlay").addClass("flipped");
                    });
                    frame.find(".right").mouseleave(() => {
                        frame.find(".controls-overlay").removeClass("flipped");
                    });
                    /* Slider */
                    frame.find(".timeline .slider").on('mousedown', ev => {
                        let timeline = frame.find(".timeline");
                        let time = frame.find(".time");
                        let slider = timeline.find(".slider");
                        let slider_old = slider.css("margin-left");
                        let time_max = parseInt(timeline.attr("time-max"));
                        slider.prop("editing", true);
                        let target_timestamp = 0;
                        let move_handler = (event) => {
                            let max = timeline.width();
                            let current = event.pageX - timeline.offset().left - slider.width() / 2;
                            if (current < 0)
                                current = 0;
                            else if (current > max)
                                current = max;
                            target_timestamp = current / max * time_max;
                            time.text(format_time(Math.floor(target_timestamp / 1000)));
                            slider.css("margin-left", current / max * 100 + "%");
                        };
                        let finish_handler = event => {
                            console.log("Event (%i | %s): %o", event.button, event.type, event);
                            if (event.type == "mousedown" && event.button != 2)
                                return;
                            $(document).unbind("mousemove", move_handler);
                            $(document).unbind("mouseup mouseleave mousedown", finish_handler);
                            if (event.type != "mousedown") {
                                slider.prop("editing", false);
                                slider.prop("edited", true);
                                let current_timestamp = info.player_replay_index + Date.now() - timestamp;
                                this.handle.handle.serverConnection.sendCommand("musicbotplayeraction", {
                                    bot_id: bot.properties.client_database_id,
                                    action: current_timestamp > target_timestamp ? 6 : 5,
                                    units: current_timestamp < target_timestamp ? target_timestamp - current_timestamp : current_timestamp - target_timestamp
                                }).then(() => this.triggerUpdate()).catch(error => {
                                    slider.prop("edited", false);
                                });
                            }
                            else { //Restore old
                                event.preventDefault();
                                slider.css("margin-left", slider_old + "%");
                            }
                        };
                        $(document).on('mousemove', move_handler);
                        $(document).on('mouseup mouseleave mousedown', finish_handler);
                        ev.preventDefault();
                        return false;
                    });
                    {
                        frame.find(".timeline").attr("time-max", info.player_max_index);
                        let timeline = frame.find(".timeline");
                        let time_bar = timeline.find(".played");
                        let slider = timeline.find(".slider");
                        let player_time = _frame.find(".player_time");
                        let update_handler = () => {
                            let time_index = info.player_replay_index + (bot.properties.player_state == 2 ? Date.now() - timestamp : 0);
                            time_bar.css("width", time_index / info.player_max_index * 100 + "%");
                            if (!slider.prop("editing") && !slider.prop("edited")) {
                                player_time.text(format_time(Math.floor(time_index / 1000)));
                                slider.css("margin-left", time_index / info.player_max_index * 100 + "%");
                            }
                        };
                        this.registerInterval(setInterval(update_handler, 1000));
                        update_handler();
                    }
                });
            }
            const player = properties["music_player"];
            const player_transformer = $.spawn("div").append(player);
            player_transformer.css({
                'display': 'block',
                //'width': "100%",
                'height': '100%'
            });
            properties["music_player"] = player_transformer;
        }
        let rendered = $("#tmpl_selected_music").renderTag([properties]);
        html_tag.append(rendered);
        {
            const player = properties["music_player"];
            const player_width = 400; //player.width();
            const player_height = 400; //player.height();
            const parent = player.parent();
            parent.css({
                'flex-grow': 1,
                'display': 'flex',
                'flex-direction': 'row',
                'justify-content': 'space-around',
            });
            const padding = 14;
            const scale_x = Math.min((parent.width() - padding) / player_width, 1.5);
            const scale_y = Math.min((parent.height() - padding) / player_height, 1.5);
            let scale = Math.min(scale_x, scale_y);
            let translate_x = 50, translate_y = 50;
            if (scale_x == scale_y && scale_x == scale) {
                //Equal scale
            }
            else if (scale_x == scale) {
                //We scale on the x-Axis
                //We have to adjust the y-Axis
            }
            else {
                //We scale on the y-Axis
                //We have to adjust the x-Axis
            }
            //1 => 0 | 0
            //1.5 => 0 | 25
            //0.5 => 0 | -25
            //const translate_x = scale_x != scale ? 0 : undefined || 50 - (50 * ((parent.width() - padding) / player_width));
            //const translate_y = scale_y != scale || scale_y > 1 ? 0 : undefined || 50 - (50 * ((parent.height() - padding) / player_height));
            const transform = ("translate(0%, " + (scale * 50 - 50) + "%) scale(" + scale.toPrecision(2) + ")");
            console.log(_translations.Vlbpd2SQ || (_translations.Vlbpd2SQ = tr("Parents: %o | %o")), parent.width(), parent.height());
            console.log(_translations.YnrHpMBg || (_translations.YnrHpMBg = tr("Player: %o | %o")), player_width, player_height);
            console.log(_translations.n1Ug4iv3 || (_translations.n1Ug4iv3 = tr("Scale: %f => translate: %o | %o")), scale, translate_x, translate_y);
            player.css({
                transform: transform
            });
            console.log("Transform: " + transform);
        }
    }
    available(object) {
        return typeof object == "object" && object instanceof MusicClientEntry;
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["fd3b1882660a0dc9fa45958131a30799c3844ee71dde7a5881b44fd19a3fdf16"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["fd3b1882660a0dc9fa45958131a30799c3844ee71dde7a5881b44fd19a3fdf16"] = "fd3b1882660a0dc9fa45958131a30799c3844ee71dde7a5881b44fd19a3fdf16";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "JAgygUCq", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (326,44)" }, { name: "JReBmSQI", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (413,51)" }, { name: "Dz16ock5", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (463,75)" }, { name: "Tg7FPhxD", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (470,30)" }, { name: "oIKPE70P", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (484,23)" }, { name: "wNecJT6J", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (489,43)" }, { name: "u40sS5ox", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (498,47)" }, { name: "_ez0sGZV", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (507,75)" }, { name: "Qy8Zd5U8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (523,55)" }, { name: "e1V0Kugs", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (552,43)" }, { name: "aSiZSfvT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (561,44)" }, { name: "SoAz74XT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (648,44)" }, { name: "gNkgjiqN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (651,47)" }, { name: "srsVKz6I", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/PermissionManager.ts (673,27)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../client.ts" />
var PermissionType;
(function (PermissionType) {
    PermissionType["B_SERVERINSTANCE_HELP_VIEW"] = "b_serverinstance_help_view";
    PermissionType["B_SERVERINSTANCE_VERSION_VIEW"] = "b_serverinstance_version_view";
    PermissionType["B_SERVERINSTANCE_INFO_VIEW"] = "b_serverinstance_info_view";
    PermissionType["B_SERVERINSTANCE_VIRTUALSERVER_LIST"] = "b_serverinstance_virtualserver_list";
    PermissionType["B_SERVERINSTANCE_BINDING_LIST"] = "b_serverinstance_binding_list";
    PermissionType["B_SERVERINSTANCE_PERMISSION_LIST"] = "b_serverinstance_permission_list";
    PermissionType["B_SERVERINSTANCE_PERMISSION_FIND"] = "b_serverinstance_permission_find";
    PermissionType["B_VIRTUALSERVER_CREATE"] = "b_virtualserver_create";
    PermissionType["B_VIRTUALSERVER_DELETE"] = "b_virtualserver_delete";
    PermissionType["B_VIRTUALSERVER_START_ANY"] = "b_virtualserver_start_any";
    PermissionType["B_VIRTUALSERVER_STOP_ANY"] = "b_virtualserver_stop_any";
    PermissionType["B_VIRTUALSERVER_CHANGE_MACHINE_ID"] = "b_virtualserver_change_machine_id";
    PermissionType["B_VIRTUALSERVER_CHANGE_TEMPLATE"] = "b_virtualserver_change_template";
    PermissionType["B_SERVERQUERY_LOGIN"] = "b_serverquery_login";
    PermissionType["B_SERVERINSTANCE_TEXTMESSAGE_SEND"] = "b_serverinstance_textmessage_send";
    PermissionType["B_SERVERINSTANCE_LOG_VIEW"] = "b_serverinstance_log_view";
    PermissionType["B_SERVERINSTANCE_LOG_ADD"] = "b_serverinstance_log_add";
    PermissionType["B_SERVERINSTANCE_STOP"] = "b_serverinstance_stop";
    PermissionType["B_SERVERINSTANCE_MODIFY_SETTINGS"] = "b_serverinstance_modify_settings";
    PermissionType["B_SERVERINSTANCE_MODIFY_QUERYGROUP"] = "b_serverinstance_modify_querygroup";
    PermissionType["B_SERVERINSTANCE_MODIFY_TEMPLATES"] = "b_serverinstance_modify_templates";
    PermissionType["B_VIRTUALSERVER_SELECT"] = "b_virtualserver_select";
    PermissionType["B_VIRTUALSERVER_INFO_VIEW"] = "b_virtualserver_info_view";
    PermissionType["B_VIRTUALSERVER_CONNECTIONINFO_VIEW"] = "b_virtualserver_connectioninfo_view";
    PermissionType["B_VIRTUALSERVER_CHANNEL_LIST"] = "b_virtualserver_channel_list";
    PermissionType["B_VIRTUALSERVER_CHANNEL_SEARCH"] = "b_virtualserver_channel_search";
    PermissionType["B_VIRTUALSERVER_CLIENT_LIST"] = "b_virtualserver_client_list";
    PermissionType["B_VIRTUALSERVER_CLIENT_SEARCH"] = "b_virtualserver_client_search";
    PermissionType["B_VIRTUALSERVER_CLIENT_DBLIST"] = "b_virtualserver_client_dblist";
    PermissionType["B_VIRTUALSERVER_CLIENT_DBSEARCH"] = "b_virtualserver_client_dbsearch";
    PermissionType["B_VIRTUALSERVER_CLIENT_DBINFO"] = "b_virtualserver_client_dbinfo";
    PermissionType["B_VIRTUALSERVER_PERMISSION_FIND"] = "b_virtualserver_permission_find";
    PermissionType["B_VIRTUALSERVER_CUSTOM_SEARCH"] = "b_virtualserver_custom_search";
    PermissionType["B_VIRTUALSERVER_START"] = "b_virtualserver_start";
    PermissionType["B_VIRTUALSERVER_STOP"] = "b_virtualserver_stop";
    PermissionType["B_VIRTUALSERVER_TOKEN_LIST"] = "b_virtualserver_token_list";
    PermissionType["B_VIRTUALSERVER_TOKEN_ADD"] = "b_virtualserver_token_add";
    PermissionType["B_VIRTUALSERVER_TOKEN_USE"] = "b_virtualserver_token_use";
    PermissionType["B_VIRTUALSERVER_TOKEN_DELETE"] = "b_virtualserver_token_delete";
    PermissionType["B_VIRTUALSERVER_LOG_VIEW"] = "b_virtualserver_log_view";
    PermissionType["B_VIRTUALSERVER_LOG_ADD"] = "b_virtualserver_log_add";
    PermissionType["B_VIRTUALSERVER_JOIN_IGNORE_PASSWORD"] = "b_virtualserver_join_ignore_password";
    PermissionType["B_VIRTUALSERVER_NOTIFY_REGISTER"] = "b_virtualserver_notify_register";
    PermissionType["B_VIRTUALSERVER_NOTIFY_UNREGISTER"] = "b_virtualserver_notify_unregister";
    PermissionType["B_VIRTUALSERVER_SNAPSHOT_CREATE"] = "b_virtualserver_snapshot_create";
    PermissionType["B_VIRTUALSERVER_SNAPSHOT_DEPLOY"] = "b_virtualserver_snapshot_deploy";
    PermissionType["B_VIRTUALSERVER_PERMISSION_RESET"] = "b_virtualserver_permission_reset";
    PermissionType["B_VIRTUALSERVER_MODIFY_NAME"] = "b_virtualserver_modify_name";
    PermissionType["B_VIRTUALSERVER_MODIFY_WELCOMEMESSAGE"] = "b_virtualserver_modify_welcomemessage";
    PermissionType["B_VIRTUALSERVER_MODIFY_MAXCLIENTS"] = "b_virtualserver_modify_maxclients";
    PermissionType["B_VIRTUALSERVER_MODIFY_RESERVED_SLOTS"] = "b_virtualserver_modify_reserved_slots";
    PermissionType["B_VIRTUALSERVER_MODIFY_PASSWORD"] = "b_virtualserver_modify_password";
    PermissionType["B_VIRTUALSERVER_MODIFY_DEFAULT_SERVERGROUP"] = "b_virtualserver_modify_default_servergroup";
    PermissionType["B_VIRTUALSERVER_MODIFY_DEFAULT_CHANNELGROUP"] = "b_virtualserver_modify_default_channelgroup";
    PermissionType["B_VIRTUALSERVER_MODIFY_DEFAULT_CHANNELADMINGROUP"] = "b_virtualserver_modify_default_channeladmingroup";
    PermissionType["B_VIRTUALSERVER_MODIFY_CHANNEL_FORCED_SILENCE"] = "b_virtualserver_modify_channel_forced_silence";
    PermissionType["B_VIRTUALSERVER_MODIFY_COMPLAIN"] = "b_virtualserver_modify_complain";
    PermissionType["B_VIRTUALSERVER_MODIFY_ANTIFLOOD"] = "b_virtualserver_modify_antiflood";
    PermissionType["B_VIRTUALSERVER_MODIFY_FT_SETTINGS"] = "b_virtualserver_modify_ft_settings";
    PermissionType["B_VIRTUALSERVER_MODIFY_FT_QUOTAS"] = "b_virtualserver_modify_ft_quotas";
    PermissionType["B_VIRTUALSERVER_MODIFY_HOSTMESSAGE"] = "b_virtualserver_modify_hostmessage";
    PermissionType["B_VIRTUALSERVER_MODIFY_HOSTBANNER"] = "b_virtualserver_modify_hostbanner";
    PermissionType["B_VIRTUALSERVER_MODIFY_HOSTBUTTON"] = "b_virtualserver_modify_hostbutton";
    PermissionType["B_VIRTUALSERVER_MODIFY_PORT"] = "b_virtualserver_modify_port";
    PermissionType["B_VIRTUALSERVER_MODIFY_HOST"] = "b_virtualserver_modify_host";
    PermissionType["B_VIRTUALSERVER_MODIFY_AUTOSTART"] = "b_virtualserver_modify_autostart";
    PermissionType["B_VIRTUALSERVER_MODIFY_NEEDED_IDENTITY_SECURITY_LEVEL"] = "b_virtualserver_modify_needed_identity_security_level";
    PermissionType["B_VIRTUALSERVER_MODIFY_PRIORITY_SPEAKER_DIMM_MODIFICATOR"] = "b_virtualserver_modify_priority_speaker_dimm_modificator";
    PermissionType["B_VIRTUALSERVER_MODIFY_LOG_SETTINGS"] = "b_virtualserver_modify_log_settings";
    PermissionType["B_VIRTUALSERVER_MODIFY_MIN_CLIENT_VERSION"] = "b_virtualserver_modify_min_client_version";
    PermissionType["B_VIRTUALSERVER_MODIFY_ICON_ID"] = "b_virtualserver_modify_icon_id";
    PermissionType["B_VIRTUALSERVER_MODIFY_WEBLIST"] = "b_virtualserver_modify_weblist";
    PermissionType["B_VIRTUALSERVER_MODIFY_CODEC_ENCRYPTION_MODE"] = "b_virtualserver_modify_codec_encryption_mode";
    PermissionType["B_VIRTUALSERVER_MODIFY_TEMPORARY_PASSWORDS"] = "b_virtualserver_modify_temporary_passwords";
    PermissionType["B_VIRTUALSERVER_MODIFY_TEMPORARY_PASSWORDS_OWN"] = "b_virtualserver_modify_temporary_passwords_own";
    PermissionType["B_VIRTUALSERVER_MODIFY_CHANNEL_TEMP_DELETE_DELAY_DEFAULT"] = "b_virtualserver_modify_channel_temp_delete_delay_default";
    PermissionType["B_VIRTUALSERVER_MODIFY_MUSIC_BOT_LIMIT"] = "b_virtualserver_modify_music_bot_limit";
    PermissionType["B_VIRTUALSERVER_MODIFY_DEFAULT_MESSAGES"] = "b_virtualserver_modify_music_bot_limit";
    PermissionType["I_CHANNEL_MIN_DEPTH"] = "i_channel_min_depth";
    PermissionType["I_CHANNEL_MAX_DEPTH"] = "i_channel_max_depth";
    PermissionType["B_CHANNEL_GROUP_INHERITANCE_END"] = "b_channel_group_inheritance_end";
    PermissionType["I_CHANNEL_PERMISSION_MODIFY_POWER"] = "i_channel_permission_modify_power";
    PermissionType["I_CHANNEL_NEEDED_PERMISSION_MODIFY_POWER"] = "i_channel_needed_permission_modify_power";
    PermissionType["B_CHANNEL_INFO_VIEW"] = "b_channel_info_view";
    PermissionType["B_CHANNEL_CREATE_CHILD"] = "b_channel_create_child";
    PermissionType["B_CHANNEL_CREATE_PERMANENT"] = "b_channel_create_permanent";
    PermissionType["B_CHANNEL_CREATE_SEMI_PERMANENT"] = "b_channel_create_semi_permanent";
    PermissionType["B_CHANNEL_CREATE_TEMPORARY"] = "b_channel_create_temporary";
    PermissionType["B_CHANNEL_CREATE_PRIVATE"] = "b_channel_create_private";
    PermissionType["B_CHANNEL_CREATE_WITH_TOPIC"] = "b_channel_create_with_topic";
    PermissionType["B_CHANNEL_CREATE_WITH_DESCRIPTION"] = "b_channel_create_with_description";
    PermissionType["B_CHANNEL_CREATE_WITH_PASSWORD"] = "b_channel_create_with_password";
    PermissionType["B_CHANNEL_CREATE_MODIFY_WITH_CODEC_SPEEX8"] = "b_channel_create_modify_with_codec_speex8";
    PermissionType["B_CHANNEL_CREATE_MODIFY_WITH_CODEC_SPEEX16"] = "b_channel_create_modify_with_codec_speex16";
    PermissionType["B_CHANNEL_CREATE_MODIFY_WITH_CODEC_SPEEX32"] = "b_channel_create_modify_with_codec_speex32";
    PermissionType["B_CHANNEL_CREATE_MODIFY_WITH_CODEC_CELTMONO48"] = "b_channel_create_modify_with_codec_celtmono48";
    PermissionType["B_CHANNEL_CREATE_MODIFY_WITH_CODEC_OPUSVOICE"] = "b_channel_create_modify_with_codec_opusvoice";
    PermissionType["B_CHANNEL_CREATE_MODIFY_WITH_CODEC_OPUSMUSIC"] = "b_channel_create_modify_with_codec_opusmusic";
    PermissionType["I_CHANNEL_CREATE_MODIFY_WITH_CODEC_MAXQUALITY"] = "i_channel_create_modify_with_codec_maxquality";
    PermissionType["I_CHANNEL_CREATE_MODIFY_WITH_CODEC_LATENCY_FACTOR_MIN"] = "i_channel_create_modify_with_codec_latency_factor_min";
    PermissionType["B_CHANNEL_CREATE_WITH_MAXCLIENTS"] = "b_channel_create_with_maxclients";
    PermissionType["B_CHANNEL_CREATE_WITH_MAXFAMILYCLIENTS"] = "b_channel_create_with_maxfamilyclients";
    PermissionType["B_CHANNEL_CREATE_WITH_SORTORDER"] = "b_channel_create_with_sortorder";
    PermissionType["B_CHANNEL_CREATE_WITH_DEFAULT"] = "b_channel_create_with_default";
    PermissionType["B_CHANNEL_CREATE_WITH_NEEDED_TALK_POWER"] = "b_channel_create_with_needed_talk_power";
    PermissionType["B_CHANNEL_CREATE_MODIFY_WITH_FORCE_PASSWORD"] = "b_channel_create_modify_with_force_password";
    PermissionType["I_CHANNEL_CREATE_MODIFY_WITH_TEMP_DELETE_DELAY"] = "i_channel_create_modify_with_temp_delete_delay";
    PermissionType["B_CHANNEL_MODIFY_PARENT"] = "b_channel_modify_parent";
    PermissionType["B_CHANNEL_MODIFY_MAKE_DEFAULT"] = "b_channel_modify_make_default";
    PermissionType["B_CHANNEL_MODIFY_MAKE_PERMANENT"] = "b_channel_modify_make_permanent";
    PermissionType["B_CHANNEL_MODIFY_MAKE_SEMI_PERMANENT"] = "b_channel_modify_make_semi_permanent";
    PermissionType["B_CHANNEL_MODIFY_MAKE_TEMPORARY"] = "b_channel_modify_make_temporary";
    PermissionType["B_CHANNEL_MODIFY_NAME"] = "b_channel_modify_name";
    PermissionType["B_CHANNEL_MODIFY_TOPIC"] = "b_channel_modify_topic";
    PermissionType["B_CHANNEL_MODIFY_DESCRIPTION"] = "b_channel_modify_description";
    PermissionType["B_CHANNEL_MODIFY_PASSWORD"] = "b_channel_modify_password";
    PermissionType["B_CHANNEL_MODIFY_CODEC"] = "b_channel_modify_codec";
    PermissionType["B_CHANNEL_MODIFY_CODEC_QUALITY"] = "b_channel_modify_codec_quality";
    PermissionType["B_CHANNEL_MODIFY_CODEC_LATENCY_FACTOR"] = "b_channel_modify_codec_latency_factor";
    PermissionType["B_CHANNEL_MODIFY_MAXCLIENTS"] = "b_channel_modify_maxclients";
    PermissionType["B_CHANNEL_MODIFY_MAXFAMILYCLIENTS"] = "b_channel_modify_maxfamilyclients";
    PermissionType["B_CHANNEL_MODIFY_SORTORDER"] = "b_channel_modify_sortorder";
    PermissionType["B_CHANNEL_MODIFY_NEEDED_TALK_POWER"] = "b_channel_modify_needed_talk_power";
    PermissionType["I_CHANNEL_MODIFY_POWER"] = "i_channel_modify_power";
    PermissionType["I_CHANNEL_NEEDED_MODIFY_POWER"] = "i_channel_needed_modify_power";
    PermissionType["B_CHANNEL_MODIFY_MAKE_CODEC_ENCRYPTED"] = "b_channel_modify_make_codec_encrypted";
    PermissionType["B_CHANNEL_MODIFY_TEMP_DELETE_DELAY"] = "b_channel_modify_temp_delete_delay";
    PermissionType["B_CHANNEL_DELETE_PERMANENT"] = "b_channel_delete_permanent";
    PermissionType["B_CHANNEL_DELETE_SEMI_PERMANENT"] = "b_channel_delete_semi_permanent";
    PermissionType["B_CHANNEL_DELETE_TEMPORARY"] = "b_channel_delete_temporary";
    PermissionType["B_CHANNEL_DELETE_FLAG_FORCE"] = "b_channel_delete_flag_force";
    PermissionType["I_CHANNEL_DELETE_POWER"] = "i_channel_delete_power";
    PermissionType["I_CHANNEL_NEEDED_DELETE_POWER"] = "i_channel_needed_delete_power";
    PermissionType["B_CHANNEL_JOIN_PERMANENT"] = "b_channel_join_permanent";
    PermissionType["B_CHANNEL_JOIN_SEMI_PERMANENT"] = "b_channel_join_semi_permanent";
    PermissionType["B_CHANNEL_JOIN_TEMPORARY"] = "b_channel_join_temporary";
    PermissionType["B_CHANNEL_JOIN_IGNORE_PASSWORD"] = "b_channel_join_ignore_password";
    PermissionType["B_CHANNEL_JOIN_IGNORE_MAXCLIENTS"] = "b_channel_join_ignore_maxclients";
    PermissionType["I_CHANNEL_JOIN_POWER"] = "i_channel_join_power";
    PermissionType["I_CHANNEL_NEEDED_JOIN_POWER"] = "i_channel_needed_join_power";
    PermissionType["I_CHANNEL_SUBSCRIBE_POWER"] = "i_channel_subscribe_power";
    PermissionType["I_CHANNEL_NEEDED_SUBSCRIBE_POWER"] = "i_channel_needed_subscribe_power";
    PermissionType["I_CHANNEL_DESCRIPTION_VIEW_POWER"] = "i_channel_description_view_power";
    PermissionType["I_CHANNEL_NEEDED_DESCRIPTION_VIEW_POWER"] = "i_channel_needed_description_view_power";
    PermissionType["I_ICON_ID"] = "i_icon_id";
    PermissionType["I_MAX_ICON_FILESIZE"] = "i_max_icon_filesize";
    PermissionType["B_ICON_MANAGE"] = "b_icon_manage";
    PermissionType["B_GROUP_IS_PERMANENT"] = "b_group_is_permanent";
    PermissionType["I_GROUP_AUTO_UPDATE_TYPE"] = "i_group_auto_update_type";
    PermissionType["I_GROUP_AUTO_UPDATE_MAX_VALUE"] = "i_group_auto_update_max_value";
    PermissionType["I_GROUP_SORT_ID"] = "i_group_sort_id";
    PermissionType["I_GROUP_SHOW_NAME_IN_TREE"] = "i_group_show_name_in_tree";
    PermissionType["B_VIRTUALSERVER_SERVERGROUP_LIST"] = "b_virtualserver_servergroup_list";
    PermissionType["B_VIRTUALSERVER_SERVERGROUP_PERMISSION_LIST"] = "b_virtualserver_servergroup_permission_list";
    PermissionType["B_VIRTUALSERVER_SERVERGROUP_CLIENT_LIST"] = "b_virtualserver_servergroup_client_list";
    PermissionType["B_VIRTUALSERVER_CHANNELGROUP_LIST"] = "b_virtualserver_channelgroup_list";
    PermissionType["B_VIRTUALSERVER_CHANNELGROUP_PERMISSION_LIST"] = "b_virtualserver_channelgroup_permission_list";
    PermissionType["B_VIRTUALSERVER_CHANNELGROUP_CLIENT_LIST"] = "b_virtualserver_channelgroup_client_list";
    PermissionType["B_VIRTUALSERVER_CLIENT_PERMISSION_LIST"] = "b_virtualserver_client_permission_list";
    PermissionType["B_VIRTUALSERVER_CHANNEL_PERMISSION_LIST"] = "b_virtualserver_channel_permission_list";
    PermissionType["B_VIRTUALSERVER_CHANNELCLIENT_PERMISSION_LIST"] = "b_virtualserver_channelclient_permission_list";
    PermissionType["B_VIRTUALSERVER_SERVERGROUP_CREATE"] = "b_virtualserver_servergroup_create";
    PermissionType["B_VIRTUALSERVER_CHANNELGROUP_CREATE"] = "b_virtualserver_channelgroup_create";
    PermissionType["I_SERVER_GROUP_MODIFY_POWER"] = "i_server_group_modify_power";
    PermissionType["I_SERVER_GROUP_NEEDED_MODIFY_POWER"] = "i_server_group_needed_modify_power";
    PermissionType["I_SERVER_GROUP_MEMBER_ADD_POWER"] = "i_server_group_member_add_power";
    PermissionType["I_SERVER_GROUP_NEEDED_MEMBER_ADD_POWER"] = "i_server_group_needed_member_add_power";
    PermissionType["I_SERVER_GROUP_MEMBER_REMOVE_POWER"] = "i_server_group_member_remove_power";
    PermissionType["I_SERVER_GROUP_NEEDED_MEMBER_REMOVE_POWER"] = "i_server_group_needed_member_remove_power";
    PermissionType["I_CHANNEL_GROUP_MODIFY_POWER"] = "i_channel_group_modify_power";
    PermissionType["I_CHANNEL_GROUP_NEEDED_MODIFY_POWER"] = "i_channel_group_needed_modify_power";
    PermissionType["I_CHANNEL_GROUP_MEMBER_ADD_POWER"] = "i_channel_group_member_add_power";
    PermissionType["I_CHANNEL_GROUP_NEEDED_MEMBER_ADD_POWER"] = "i_channel_group_needed_member_add_power";
    PermissionType["I_CHANNEL_GROUP_MEMBER_REMOVE_POWER"] = "i_channel_group_member_remove_power";
    PermissionType["I_CHANNEL_GROUP_NEEDED_MEMBER_REMOVE_POWER"] = "i_channel_group_needed_member_remove_power";
    PermissionType["I_GROUP_MEMBER_ADD_POWER"] = "i_group_member_add_power";
    PermissionType["I_GROUP_NEEDED_MEMBER_ADD_POWER"] = "i_group_needed_member_add_power";
    PermissionType["I_GROUP_MEMBER_REMOVE_POWER"] = "i_group_member_remove_power";
    PermissionType["I_GROUP_NEEDED_MEMBER_REMOVE_POWER"] = "i_group_needed_member_remove_power";
    PermissionType["I_GROUP_MODIFY_POWER"] = "i_group_modify_power";
    PermissionType["I_GROUP_NEEDED_MODIFY_POWER"] = "i_group_needed_modify_power";
    PermissionType["I_DISPLAYED_GROUP_MEMBER_ADD_POWER"] = "i_displayed_group_member_add_power";
    PermissionType["I_DISPLAYED_GROUP_NEEDED_MEMBER_ADD_POWER"] = "i_displayed_group_needed_member_add_power";
    PermissionType["I_DISPLAYED_GROUP_MEMBER_REMOVE_POWER"] = "i_displayed_group_member_remove_power";
    PermissionType["I_DISPLAYED_GROUP_NEEDED_MEMBER_REMOVE_POWER"] = "i_displayed_group_needed_member_remove_power";
    PermissionType["I_DISPLAYED_GROUP_MODIFY_POWER"] = "i_displayed_group_modify_power";
    PermissionType["I_DISPLAYED_GROUP_NEEDED_MODIFY_POWER"] = "i_displayed_group_needed_modify_power";
    PermissionType["I_PERMISSION_MODIFY_POWER"] = "i_permission_modify_power";
    PermissionType["B_PERMISSION_MODIFY_POWER_IGNORE"] = "b_permission_modify_power_ignore";
    PermissionType["B_VIRTUALSERVER_SERVERGROUP_DELETE"] = "b_virtualserver_servergroup_delete";
    PermissionType["B_VIRTUALSERVER_CHANNELGROUP_DELETE"] = "b_virtualserver_channelgroup_delete";
    PermissionType["I_CLIENT_PERMISSION_MODIFY_POWER"] = "i_client_permission_modify_power";
    PermissionType["I_CLIENT_NEEDED_PERMISSION_MODIFY_POWER"] = "i_client_needed_permission_modify_power";
    PermissionType["I_CLIENT_MAX_CLONES_UID"] = "i_client_max_clones_uid";
    PermissionType["I_CLIENT_MAX_IDLETIME"] = "i_client_max_idletime";
    PermissionType["I_CLIENT_MAX_AVATAR_FILESIZE"] = "i_client_max_avatar_filesize";
    PermissionType["I_CLIENT_MAX_CHANNEL_SUBSCRIPTIONS"] = "i_client_max_channel_subscriptions";
    PermissionType["B_CLIENT_IS_PRIORITY_SPEAKER"] = "b_client_is_priority_speaker";
    PermissionType["B_CLIENT_SKIP_CHANNELGROUP_PERMISSIONS"] = "b_client_skip_channelgroup_permissions";
    PermissionType["B_CLIENT_FORCE_PUSH_TO_TALK"] = "b_client_force_push_to_talk";
    PermissionType["B_CLIENT_IGNORE_BANS"] = "b_client_ignore_bans";
    PermissionType["B_CLIENT_IGNORE_ANTIFLOOD"] = "b_client_ignore_antiflood";
    PermissionType["B_CLIENT_ISSUE_CLIENT_QUERY_COMMAND"] = "b_client_issue_client_query_command";
    PermissionType["B_CLIENT_USE_RESERVED_SLOT"] = "b_client_use_reserved_slot";
    PermissionType["B_CLIENT_USE_CHANNEL_COMMANDER"] = "b_client_use_channel_commander";
    PermissionType["B_CLIENT_REQUEST_TALKER"] = "b_client_request_talker";
    PermissionType["B_CLIENT_AVATAR_DELETE_OTHER"] = "b_client_avatar_delete_other";
    PermissionType["B_CLIENT_IS_STICKY"] = "b_client_is_sticky";
    PermissionType["B_CLIENT_IGNORE_STICKY"] = "b_client_ignore_sticky";
    PermissionType["B_CLIENT_MUSIC_CHANNEL_LIST"] = "b_client_music_channel_list";
    PermissionType["B_CLIENT_MUSIC_SERVER_LIST"] = "b_client_music_server_list";
    PermissionType["I_CLIENT_MUSIC_INFO"] = "i_client_music_info";
    PermissionType["I_CLIENT_MUSIC_NEEDED_INFO"] = "i_client_music_needed_info";
    PermissionType["B_CLIENT_INFO_VIEW"] = "b_client_info_view";
    PermissionType["B_CLIENT_PERMISSIONOVERVIEW_VIEW"] = "b_client_permissionoverview_view";
    PermissionType["B_CLIENT_PERMISSIONOVERVIEW_OWN"] = "b_client_permissionoverview_own";
    PermissionType["B_CLIENT_REMOTEADDRESS_VIEW"] = "b_client_remoteaddress_view";
    PermissionType["I_CLIENT_SERVERQUERY_VIEW_POWER"] = "i_client_serverquery_view_power";
    PermissionType["I_CLIENT_NEEDED_SERVERQUERY_VIEW_POWER"] = "i_client_needed_serverquery_view_power";
    PermissionType["B_CLIENT_CUSTOM_INFO_VIEW"] = "b_client_custom_info_view";
    PermissionType["I_CLIENT_KICK_FROM_SERVER_POWER"] = "i_client_kick_from_server_power";
    PermissionType["I_CLIENT_NEEDED_KICK_FROM_SERVER_POWER"] = "i_client_needed_kick_from_server_power";
    PermissionType["I_CLIENT_KICK_FROM_CHANNEL_POWER"] = "i_client_kick_from_channel_power";
    PermissionType["I_CLIENT_NEEDED_KICK_FROM_CHANNEL_POWER"] = "i_client_needed_kick_from_channel_power";
    PermissionType["I_CLIENT_BAN_POWER"] = "i_client_ban_power";
    PermissionType["I_CLIENT_NEEDED_BAN_POWER"] = "i_client_needed_ban_power";
    PermissionType["I_CLIENT_MOVE_POWER"] = "i_client_move_power";
    PermissionType["I_CLIENT_NEEDED_MOVE_POWER"] = "i_client_needed_move_power";
    PermissionType["I_CLIENT_COMPLAIN_POWER"] = "i_client_complain_power";
    PermissionType["I_CLIENT_NEEDED_COMPLAIN_POWER"] = "i_client_needed_complain_power";
    PermissionType["B_CLIENT_COMPLAIN_LIST"] = "b_client_complain_list";
    PermissionType["B_CLIENT_COMPLAIN_DELETE_OWN"] = "b_client_complain_delete_own";
    PermissionType["B_CLIENT_COMPLAIN_DELETE"] = "b_client_complain_delete";
    PermissionType["B_CLIENT_BAN_LIST"] = "b_client_ban_list";
    PermissionType["B_CLIENT_BAN_LIST_GLOBAL"] = "b_client_ban_list_global";
    PermissionType["B_CLIENT_BAN_CREATE"] = "b_client_ban_create";
    PermissionType["B_CLIENT_BAN_CREATE_GLOBAL"] = "b_client_ban_create_global";
    PermissionType["B_CLIENT_BAN_EDIT"] = "b_client_ban_edit";
    PermissionType["B_CLIENT_BAN_EDIT_GLOBAL"] = "b_client_ban_edit_global";
    PermissionType["B_CLIENT_BAN_DELETE_OWN"] = "b_client_ban_delete_own";
    PermissionType["B_CLIENT_BAN_DELETE"] = "b_client_ban_delete";
    PermissionType["B_CLIENT_BAN_DELETE_OWN_GLOBAL"] = "b_client_ban_delete_own_global";
    PermissionType["B_CLIENT_BAN_DELETE_GLOBAL"] = "b_client_ban_delete_global";
    PermissionType["I_CLIENT_BAN_MAX_BANTIME"] = "i_client_ban_max_bantime";
    PermissionType["I_CLIENT_PRIVATE_TEXTMESSAGE_POWER"] = "i_client_private_textmessage_power";
    PermissionType["I_CLIENT_NEEDED_PRIVATE_TEXTMESSAGE_POWER"] = "i_client_needed_private_textmessage_power";
    PermissionType["B_CLIENT_SERVER_TEXTMESSAGE_SEND"] = "b_client_server_textmessage_send";
    PermissionType["B_CLIENT_CHANNEL_TEXTMESSAGE_SEND"] = "b_client_channel_textmessage_send";
    PermissionType["B_CLIENT_OFFLINE_TEXTMESSAGE_SEND"] = "b_client_offline_textmessage_send";
    PermissionType["I_CLIENT_TALK_POWER"] = "i_client_talk_power";
    PermissionType["I_CLIENT_NEEDED_TALK_POWER"] = "i_client_needed_talk_power";
    PermissionType["I_CLIENT_POKE_POWER"] = "i_client_poke_power";
    PermissionType["I_CLIENT_NEEDED_POKE_POWER"] = "i_client_needed_poke_power";
    PermissionType["B_CLIENT_SET_FLAG_TALKER"] = "b_client_set_flag_talker";
    PermissionType["I_CLIENT_WHISPER_POWER"] = "i_client_whisper_power";
    PermissionType["I_CLIENT_NEEDED_WHISPER_POWER"] = "i_client_needed_whisper_power";
    PermissionType["B_CLIENT_MODIFY_DESCRIPTION"] = "b_client_modify_description";
    PermissionType["B_CLIENT_MODIFY_OWN_DESCRIPTION"] = "b_client_modify_own_description";
    PermissionType["B_CLIENT_MODIFY_DBPROPERTIES"] = "b_client_modify_dbproperties";
    PermissionType["B_CLIENT_DELETE_DBPROPERTIES"] = "b_client_delete_dbproperties";
    PermissionType["B_CLIENT_CREATE_MODIFY_SERVERQUERY_LOGIN"] = "b_client_create_modify_serverquery_login";
    PermissionType["B_CLIENT_MUSIC_CREATE"] = "b_client_music_create";
    PermissionType["I_CLIENT_MUSIC_LIMIT"] = "i_client_music_limit";
    PermissionType["I_CLIENT_MUSIC_DELETE_POWER"] = "i_client_music_delete_power";
    PermissionType["I_CLIENT_MUSIC_NEEDED_DELETE_POWER"] = "i_client_music_needed_delete_power";
    PermissionType["I_CLIENT_MUSIC_PLAY_POWER"] = "i_client_music_play_power";
    PermissionType["I_CLIENT_MUSIC_NEEDED_PLAY_POWER"] = "i_client_music_needed_play_power";
    PermissionType["I_CLIENT_MUSIC_RENAME_POWER"] = "i_client_music_rename_power";
    PermissionType["I_CLIENT_MUSIC_NEEDED_RENAME_POWER"] = "i_client_music_needed_rename_power";
    PermissionType["B_FT_IGNORE_PASSWORD"] = "b_ft_ignore_password";
    PermissionType["B_FT_TRANSFER_LIST"] = "b_ft_transfer_list";
    PermissionType["I_FT_FILE_UPLOAD_POWER"] = "i_ft_file_upload_power";
    PermissionType["I_FT_NEEDED_FILE_UPLOAD_POWER"] = "i_ft_needed_file_upload_power";
    PermissionType["I_FT_FILE_DOWNLOAD_POWER"] = "i_ft_file_download_power";
    PermissionType["I_FT_NEEDED_FILE_DOWNLOAD_POWER"] = "i_ft_needed_file_download_power";
    PermissionType["I_FT_FILE_DELETE_POWER"] = "i_ft_file_delete_power";
    PermissionType["I_FT_NEEDED_FILE_DELETE_POWER"] = "i_ft_needed_file_delete_power";
    PermissionType["I_FT_FILE_RENAME_POWER"] = "i_ft_file_rename_power";
    PermissionType["I_FT_NEEDED_FILE_RENAME_POWER"] = "i_ft_needed_file_rename_power";
    PermissionType["I_FT_FILE_BROWSE_POWER"] = "i_ft_file_browse_power";
    PermissionType["I_FT_NEEDED_FILE_BROWSE_POWER"] = "i_ft_needed_file_browse_power";
    PermissionType["I_FT_DIRECTORY_CREATE_POWER"] = "i_ft_directory_create_power";
    PermissionType["I_FT_NEEDED_DIRECTORY_CREATE_POWER"] = "i_ft_needed_directory_create_power";
    PermissionType["I_FT_QUOTA_MB_DOWNLOAD_PER_CLIENT"] = "i_ft_quota_mb_download_per_client";
    PermissionType["I_FT_QUOTA_MB_UPLOAD_PER_CLIENT"] = "i_ft_quota_mb_upload_per_client";
})(PermissionType || (PermissionType = {}));
class PermissionInfo {
}
class PermissionGroup {
}
class GroupedPermissions {
}
class PermissionValue {
    constructor(type, value) {
        this.type = type;
        this.value = value;
    }
    granted(requiredValue, required = true) {
        let result;
        result = this.value == -1 || this.value >= requiredValue || (this.value == -2 && requiredValue == -2 && !required);
        log.trace(LogCategory.PERMISSIONS, _translations.JAgygUCq || (_translations.JAgygUCq = tr("Test needed required: %o | %i | %o => %o")), this, requiredValue, required, result);
        return result;
    }
    hasValue() {
        return this.value != -2;
    }
}
class NeededPermissionValue extends PermissionValue {
    constructor(type, value) {
        super(type, value);
        this.changeListener = [];
    }
}
class ChannelPermissionRequest {
    constructor() {
        this.callback_success = [];
        this.callback_error = [];
    }
}
class TeaPermissionRequest {
}
class PermissionManager {
    constructor(client) {
        this.permissionList = [];
        this.permissionGroups = [];
        this.neededPermissions = [];
        this.requests_channel_permissions = [];
        this.requests_client_permissions = [];
        this.requests_client_channel_permissions = [];
        this.initializedListener = [];
        this.handle = client;
        this.handle.serverConnection.commandHandler["notifyclientneededpermissions"] = this.onNeededPermissions.bind(this);
        this.handle.serverConnection.commandHandler["notifypermissionlist"] = this.onPermissionList.bind(this);
        this.handle.serverConnection.commandHandler["notifychannelpermlist"] = this.onChannelPermList.bind(this);
        this.handle.serverConnection.commandHandler["notifyclientpermlist"] = this.onClientPermList.bind(this);
    }
    static parse_permission_bulk(json, manager) {
        let permissions = [];
        for (let perm of json) {
            let perm_id = parseInt(perm["permid"]);
            let perm_grant = (perm_id & (1 << 15)) > 0;
            if (perm_grant)
                perm_id &= ~(1 << 15);
            let perm_info = manager.resolveInfo(perm_id);
            if (!perm_info) {
                log.warn(LogCategory.PERMISSIONS, _translations.JReBmSQI || (_translations.JReBmSQI = tr("Got unknown permission id (%o/%o (%o))!")), perm["permid"], perm_id, perm["permsid"]);
                return;
            }
            let permission;
            for (let ref_perm of permissions) {
                if (ref_perm.type == perm_info) {
                    permission = ref_perm;
                    break;
                }
            }
            if (!permission) {
                permission = new PermissionValue(perm_info, 0);
                permission.granted_value = undefined;
                permission.value = undefined;
                permissions.push(permission);
            }
            if (perm_grant) {
                permission.granted_value = parseInt(perm["permvalue"]);
            }
            else {
                permission.value = parseInt(perm["permvalue"]);
                permission.flag_negate = perm["permnegated"] == "1";
                permission.flag_skip = perm["permskip"] == "1";
            }
        }
        return permissions;
    }
    initialized() {
        return this.permissionList.length > 0;
    }
    requestPermissionList() {
        this.handle.serverConnection.sendCommand("permissionlist");
    }
    onPermissionList(json) {
        this.permissionList = [];
        this.permissionGroups = [];
        this._group_mapping = PermissionManager.group_mapping.slice();
        let group = log.group(log.LogType.TRACE, LogCategory.PERMISSIONS, _translations.Dz16ock5 || (_translations.Dz16ock5 = tr("Permission mapping")));
        for (let e of json) {
            if (e["group_id_end"]) {
                let group = new PermissionGroup();
                group.begin = this.permissionGroups.length ? this.permissionGroups.last().end : 0;
                group.end = parseInt(e["group_id_end"]);
                group.deep = 0;
                group.name = (_translations.Tg7FPhxD || (_translations.Tg7FPhxD = tr("Group "))) + e["group_id_end"];
                let info = this._group_mapping.pop_front();
                if (info) {
                    group.name = info.name;
                    group.deep = info.deep;
                }
                this.permissionGroups.push(group);
            }
            let perm = new PermissionInfo();
            perm.name = e["permname"];
            perm.id = parseInt(e["permid"]);
            perm.description = e["permdesc"];
            group.log(_translations.oIKPE70P || (_translations.oIKPE70P = tr("%i <> %s -> %s")), perm.id, perm.name, perm.description);
            this.permissionList.push(perm);
        }
        group.end();
        log.info(LogCategory.PERMISSIONS, _translations.wNecJT6J || (_translations.wNecJT6J = tr("Got %i permissions")), this.permissionList.length);
        if (this._cacheNeededPermissions)
            this.onNeededPermissions(this._cacheNeededPermissions);
        for (let listener of this.initializedListener)
            listener(true);
    }
    onNeededPermissions(json) {
        if (this.permissionList.length == 0) {
            log.warn(LogCategory.PERMISSIONS, _translations.u40sS5ox || (_translations.u40sS5ox = tr("Got needed permissions but don't have a permission list!")));
            this._cacheNeededPermissions = json;
            return;
        }
        this._cacheNeededPermissions = undefined;
        let copy = this.neededPermissions.slice();
        let addcount = 0;
        let group = log.group(log.LogType.TRACE, LogCategory.PERMISSIONS, _translations._ez0sGZV || (_translations._ez0sGZV = tr("Got %d needed permissions.")), json.length);
        for (let e of json) {
            let entry = undefined;
            for (let p of copy) {
                if (p.type.id == e["permid"]) {
                    entry = p;
                    copy.remove(p);
                    break;
                }
            }
            if (!entry) {
                let info = this.resolveInfo(e["permid"]);
                if (info) {
                    entry = new NeededPermissionValue(info, -2);
                    this.neededPermissions.push(entry);
                }
                else {
                    log.warn(LogCategory.PERMISSIONS, _translations.Qy8Zd5U8 || (_translations.Qy8Zd5U8 = tr("Could not resolve perm for id %s (%o|%o)")), e["permid"], e, info);
                    continue;
                }
                addcount++;
            }
            if (entry.value == parseInt(e["permvalue"]))
                continue;
            entry.value = parseInt(e["permvalue"]);
            //TODO tr
            group.log("Update needed permission " + entry.type.name + " to " + entry.value);
            for (let listener of entry.changeListener)
                listener(entry.value);
        }
        group.end();
        //TODO tr
        log.debug(LogCategory.PERMISSIONS, "Dropping " + copy.length + " needed permissions and added " + addcount + " permissions.");
        for (let e of copy) {
            e.value = -2;
            for (let listener of e.changeListener)
                listener(e.value);
        }
    }
    onChannelPermList(json) {
        let channelId = parseInt(json[0]["cid"]);
        let permissions = PermissionManager.parse_permission_bulk(json, this.handle.permissions);
        log.debug(LogCategory.PERMISSIONS, _translations.e1V0Kugs || (_translations.e1V0Kugs = tr("Got channel permissions for channel %o")), channelId);
        for (let element of this.requests_channel_permissions) {
            if (element.channel_id == channelId) {
                for (let l of element.callback_success)
                    l(permissions);
                this.requests_channel_permissions.remove(element);
                return;
            }
        }
        log.debug(LogCategory.PERMISSIONS, _translations.aSiZSfvT || (_translations.aSiZSfvT = tr("Missing channel permission handle for requested channel id %o")), channelId);
    }
    resolveInfo(key) {
        for (let perm of this.permissionList)
            if (perm.id == key || perm.name == key)
                return perm;
        return undefined;
    }
    requestChannelPermissions(channelId) {
        return new Promise((resolve, reject) => {
            let request;
            for (let element of this.requests_channel_permissions)
                if (element.requested + 1000 < Date.now() && element.channel_id == channelId) {
                    request = element;
                    break;
                }
            if (!request) {
                request = new ChannelPermissionRequest();
                request.requested = Date.now();
                request.channel_id = channelId;
                this.handle.serverConnection.sendCommand("channelpermlist", { "cid": channelId });
                this.requests_channel_permissions.push(request);
            }
            request.callback_error.push(reject);
            request.callback_success.push(resolve);
        });
    }
    requestClientPermissions(client_id) {
        for (let request of this.requests_client_permissions)
            if (request.client_id == client_id && request.promise.time() + 1000 > Date.now())
                return request.promise;
        let request = {};
        request.client_id = client_id;
        request.promise = new LaterPromise();
        this.handle.serverConnection.sendCommand("clientpermlist", { cldbid: client_id }).catch(error => {
            if (error instanceof CommandResult && error.id == 0x0501)
                request.promise.resolved([]);
            else
                request.promise.rejected(error);
        });
        this.requests_client_permissions.push(request);
        return request.promise;
    }
    requestClientChannelPermissions(client_id, channel_id) {
        for (let request of this.requests_client_channel_permissions)
            if (request.client_id == client_id && request.channel_id == channel_id && request.promise.time() + 1000 > Date.now())
                return request.promise;
        let request = {};
        request.client_id = client_id;
        request.channel_id = channel_id;
        request.promise = new LaterPromise();
        this.handle.serverConnection.sendCommand("channelclientpermlist", { cldbid: client_id, cid: channel_id }).catch(error => {
            if (error instanceof CommandResult && error.id == 0x0501)
                request.promise.resolved([]);
            else
                request.promise.rejected(error);
        });
        this.requests_client_channel_permissions.push(request);
        return request.promise;
    }
    onClientPermList(json) {
        let client = parseInt(json[0]["cldbid"]);
        let permissions = PermissionManager.parse_permission_bulk(json, this);
        for (let req of this.requests_client_permissions.slice(0)) {
            if (req.client_id == client) {
                this.requests_client_permissions.remove(req);
                req.promise.resolved(permissions);
            }
        }
    }
    neededPermission(key) {
        for (let perm of this.neededPermissions)
            if (perm.type.id == key || perm.type.name == key || perm.type == key)
                return perm;
        log.debug(LogCategory.PERMISSIONS, _translations.SoAz74XT || (_translations.SoAz74XT = tr("Could not resolve grant permission %o. Creating a new one.")), key);
        let info = key instanceof PermissionInfo ? key : this.resolveInfo(key);
        if (!info) {
            log.warn(LogCategory.PERMISSIONS, _translations.gNkgjiqN || (_translations.gNkgjiqN = tr("Requested needed permission with invalid key! (%o)")), key);
            return new NeededPermissionValue(undefined, -2);
        }
        let result = new NeededPermissionValue(info, -2);
        this.neededPermissions.push(result);
        return result;
    }
    groupedPermissions() {
        let result = [];
        let current;
        for (let group of this.permissionGroups) {
            if (group.deep == 0) {
                current = new GroupedPermissions();
                current.group = group;
                current.parent = undefined;
                current.children = [];
                current.permissions = [];
                result.push(current);
            }
            else {
                if (!current) {
                    throw _translations.srsVKz6I || (_translations.srsVKz6I = tr("invalid order!"));
                }
                else {
                    while (group.deep <= current.group.deep)
                        current = current.parent;
                    let parent = current;
                    current = new GroupedPermissions();
                    current.group = group;
                    current.parent = parent;
                    current.children = [];
                    current.permissions = [];
                    parent.children.push(current);
                }
            }
            for (let permission of this.permissionList)
                if (permission.id > current.group.begin && permission.id <= current.group.end)
                    current.permissions.push(permission);
        }
        return result;
    }
}
/* Static info mapping until TeaSpeak implements a detailed info */
//TODO tr
PermissionManager.group_mapping = [
    { name: "Global", deep: 0 },
    { name: "Information", deep: 1 },
    { name: "Virtual server management", deep: 1 },
    { name: "Administration", deep: 1 },
    { name: "Settings", deep: 1 },
    { name: "Virtual Server", deep: 0 },
    { name: "Information", deep: 1 },
    { name: "Administration", deep: 1 },
    { name: "Settings", deep: 1 },
    { name: "Channel", deep: 0 },
    { name: "Information", deep: 1 },
    { name: "Create", deep: 1 },
    { name: "Modify", deep: 1 },
    { name: "Delete", deep: 1 },
    { name: "Access", deep: 1 },
    { name: "Group", deep: 0 },
    { name: "Information", deep: 1 },
    { name: "Create", deep: 1 },
    { name: "Modify", deep: 1 },
    { name: "Delete", deep: 1 },
    { name: "Client", deep: 0 },
    { name: "Information", deep: 1 },
    { name: "Admin", deep: 1 },
    { name: "Basics", deep: 1 },
    { name: "Modify", deep: 1 },
    //TODO Music bot
    { name: "File Transfer", deep: 0 },
];
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["e681dcf1119c62c78fc4430710f1133961804c39baf316305a0292d1479efbd1"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["e681dcf1119c62c78fc4430710f1133961804c39baf316305a0292d1479efbd1"] = "e681dcf1119c62c78fc4430710f1133961804c39baf316305a0292d1479efbd1";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "PzfGwJp9", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/GroupManager.ts (115,27)" }, { name: "QeCVIzjU", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/GroupManager.ts (185,48)" }, { name: "DHhe9Dh3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/permission/GroupManager.ts (194,47)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var GroupType;
(function (GroupType) {
    GroupType[GroupType["QUERY"] = 0] = "QUERY";
    GroupType[GroupType["TEMPLATE"] = 1] = "TEMPLATE";
    GroupType[GroupType["NORMAL"] = 2] = "NORMAL";
})(GroupType || (GroupType = {}));
var GroupTarget;
(function (GroupTarget) {
    GroupTarget[GroupTarget["SERVER"] = 0] = "SERVER";
    GroupTarget[GroupTarget["CHANNEL"] = 1] = "CHANNEL";
})(GroupTarget || (GroupTarget = {}));
class GroupProperties {
    constructor() {
        this.iconid = 0;
        this.sortid = 0;
        this.savedb = false;
        this.namemode = 0;
    }
}
class GroupPermissionRequest {
}
class Group {
    constructor(handle, id, target, type, name) {
        this.properties = new GroupProperties();
        this.requiredModifyPower = 0;
        this.requiredMemberAddPower = 0;
        this.requiredMemberRemovePower = 0;
        this.handle = handle;
        this.id = id;
        this.target = target;
        this.type = type;
        this.name = name;
    }
    updateProperty(key, value) {
        JSON.map_field_to(this.properties, value, key);
        if (key == "iconid") {
            this.properties.iconid = (new Uint32Array([this.properties.iconid]))[0];
            console.log("Icon id " + this.properties.iconid);
            this.handle.handle.channelTree.clientsByGroup(this).forEach(client => {
                client.updateGroupIcon(this);
            });
        }
    }
}
class GroupManager {
    constructor(client) {
        this.serverGroups = [];
        this.channelGroups = [];
        this.requests_group_permissions = [];
        this.handle = client;
        this.handle.serverConnection.commandHandler["notifyservergrouplist"] = this.onServerGroupList.bind(this);
        this.handle.serverConnection.commandHandler["notifychannelgrouplist"] = this.onServerGroupList.bind(this);
        this.handle.serverConnection.commandHandler["notifyservergrouppermlist"] = this.onPermissionList.bind(this);
        this.handle.serverConnection.commandHandler["notifychannelgrouppermlist"] = this.onPermissionList.bind(this);
    }
    requestGroups() {
        this.handle.serverConnection.sendCommand("servergrouplist");
        this.handle.serverConnection.sendCommand("channelgrouplist");
    }
    static sorter() {
        return (a, b) => {
            if (a.properties.sortid > b.properties.sortid)
                return 1;
            if (a.properties.sortid < b.properties.sortid)
                return -1;
            if (a.id < b.id)
                return -1;
            if (a.id > b.id)
                return 1;
            return 0;
        };
    }
    serverGroup(id) {
        for (let group of this.serverGroups)
            if (group.id == id)
                return group;
        return undefined;
    }
    channelGroup(id) {
        for (let group of this.channelGroups)
            if (group.id == id)
                return group;
        return undefined;
    }
    onServerGroupList(json) {
        let target;
        if (json[0]["sgid"])
            target = GroupTarget.SERVER;
        else if (json[0]["cgid"])
            target = GroupTarget.CHANNEL;
        else {
            console.error(_translations.PzfGwJp9 || (_translations.PzfGwJp9 = tr("Could not resolve group target! => %o")), json[0]);
            return;
        }
        if (target == GroupTarget.SERVER)
            this.serverGroups = [];
        else
            this.channelGroups = [];
        for (let groupData of json) {
            let type;
            switch (Number.parseInt(groupData["type"])) {
                case 0:
                    type = GroupType.TEMPLATE;
                    break;
                case 1:
                    type = GroupType.NORMAL;
                    break;
                case 2:
                    type = GroupType.QUERY;
                    break;
                default:
                    //TODO tr
                    console.error("Invalid group type: " + groupData["type"] + " for group " + groupData["name"]);
                    continue;
            }
            let group = new Group(this, parseInt(target == GroupTarget.SERVER ? groupData["sgid"] : groupData["cgid"]), target, type, groupData["name"]);
            for (let key in groupData) {
                if (key == "sgid")
                    continue;
                if (key == "cgid")
                    continue;
                if (key == "type")
                    continue;
                if (key == "name")
                    continue;
                group.updateProperty(key, groupData[key]);
            }
            group.requiredMemberRemovePower = parseInt(groupData["n_member_removep"]);
            group.requiredMemberAddPower = parseInt(groupData["n_member_addp"]);
            group.requiredModifyPower = parseInt(groupData["n_modifyp"]);
            if (target == GroupTarget.SERVER)
                this.serverGroups.push(group);
            else
                this.channelGroups.push(group);
        }
        console.log("Got " + json.length + " new " + target + " groups:");
        for (const client of this.handle.channelTree.clients)
            client.update_displayed_client_groups();
    }
    request_permissions(group) {
        for (let request of this.requests_group_permissions)
            if (request.group_id == group.id && request.promise.time() + 1000 > Date.now())
                return request.promise;
        let req = new GroupPermissionRequest();
        req.group_id = group.id;
        req.promise = new LaterPromise();
        this.requests_group_permissions.push(req);
        this.handle.serverConnection.sendCommand(group.target == GroupTarget.SERVER ? "servergrouppermlist" : "channelgrouppermlist", {
            cgid: group.id,
            sgid: group.id
        }).catch(error => {
            if (error instanceof CommandResult && error.id == 0x0501)
                req.promise.resolved([]);
            else
                req.promise.rejected(error);
        });
        return req.promise;
    }
    onPermissionList(json) {
        let group = json[0]["sgid"] ? this.serverGroup(parseInt(json[0]["sgid"])) : this.channelGroup(parseInt(json[0]["cgid"]));
        if (!group) {
            log.error(LogCategory.PERMISSIONS, _translations.QeCVIzjU || (_translations.QeCVIzjU = tr("Got group permissions for group %o/%o, but its not a registered group!")), json[0]["sgid"], json[0]["cgid"]);
            return;
        }
        let requests = [];
        for (let req of this.requests_group_permissions)
            if (req.group_id == group.id)
                requests.push(req);
        if (requests.length == 0) {
            log.warn(LogCategory.PERMISSIONS, _translations.DHhe9Dh3 || (_translations.DHhe9Dh3 = tr("Got group permissions for group %o/%o, but it was never requested!")), json[0]["sgid"], json[0]["cgid"]);
            return;
        }
        let permissions = PermissionManager.parse_permission_bulk(json, this.handle.permissions);
        for (let req of requests) {
            this.requests_group_permissions.remove(req);
            req.promise.resolved(permissions);
        }
    }
}
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try {
            step(generator.next(value));
        }
        catch (e) {
            reject(e);
        } }
        function rejected(value) { try {
            step(generator["throw"](value));
        }
        catch (e) {
            reject(e);
        } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["e59633b67638b1b72773688ea87c7f70f433f13e282fa8c44edbb11e56fb47e4"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["e59633b67638b1b72773688ea87c7f70f433f13e282fa8c44edbb11e56fb47e4"] = "e59633b67638b1b72773688ea87c7f70f433f13e282fa8c44edbb11e56fb47e4";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "hKlN7BiL", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (105,52)" }, { name: "ih8QMg_A", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (106,32)" }, { name: "txTvEcdY", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (110,28)" }, { name: "Pj7rpUtP", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (118,40)" }, { name: "OI3vzsdj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (122,40)" }, { name: "bofVl42p", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (144,32)" }, { name: "NeD9Sp31", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (196,48)" }, { name: "csZiF9ZZ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (199,48)" }, { name: "DSlUZ1S8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (278,52)" }, { name: "flNYUpdo", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (288,44)" }, { name: "xAwamJT4", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (323,34)" }, { name: "mrGYvfC2", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (323,60)" }, { name: "ItT9ld9A", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/i18n/localize.ts (323,196)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/*
"key": {
    "message": "Show permission description",
    "line": 374,
    "character": 30,
    "filename": "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts"
},
"translated": "Berechtigungsbeschreibung anzeigen",
"flags": [
    "google-translate",
    "verified"
]
 */
function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}
var i18n;
(function (i18n) {
    let translations = [];
    let fast_translate = {};
    function tr(message, key) {
        const sloppy = fast_translate[message];
        if (sloppy)
            return sloppy;
        log.info(LogCategory.I18N, "Translating \"%s\". Default: \"%s\"", key, message);
        let translated = message;
        for (const translation of translations) {
            if (translation.key.message == message) {
                translated = translation.translated;
                break;
            }
        }
        fast_translate[message] = translated;
        return translated;
    }
    i18n.tr = tr;
    function load_translation_file(url) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                $.ajax({
                    url: url,
                    async: true,
                    success: result => {
                        try {
                            const file = (typeof (result) === "string" ? JSON.parse(result) : result);
                            if (!file) {
                                reject("Invalid json");
                                return;
                            }
                            file.url = url;
                            //TODO validate file
                            resolve(file);
                        }
                        catch (error) {
                            log.warn(LogCategory.I18N, _translations.hKlN7BiL || (_translations.hKlN7BiL = tr("Failed to load translation file %s. Failed to parse or process json: %o")), url, error);
                            reject(_translations.ih8QMg_A || (_translations.ih8QMg_A = tr("Failed to process or parse json!")));
                        }
                    },
                    error: (xhr, error) => {
                        reject((_translations.txTvEcdY || (_translations.txTvEcdY = tr("Failed to load file: "))) + error);
                    }
                });
            });
        });
    }
    function load_file(url) {
        return load_translation_file(url).then(result => {
            log.info(LogCategory.I18N, _translations.Pj7rpUtP || (_translations.Pj7rpUtP = tr("Successfully initialized up translation file from %s")), url);
            translations = result.translations;
            return Promise.resolve();
        }).catch(error => {
            log.warn(LogCategory.I18N, _translations.OI3vzsdj || (_translations.OI3vzsdj = tr("Failed to load translation file from \"%s\". Error: %o")), url, error);
            return Promise.reject(error);
        });
    }
    i18n.load_file = load_file;
    function load_repository0(repo, reload) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!repo.load_timestamp || repo.load_timestamp < 1000 || reload) {
                const info_json = yield new Promise((resolve, reject) => {
                    $.ajax({
                        url: repo.url + "/info.json",
                        async: true,
                        cache: !reload,
                        success: result => {
                            const file = (typeof (result) === "string" ? JSON.parse(result) : result);
                            if (!file) {
                                reject("Invalid json");
                                return;
                            }
                            resolve(file);
                        },
                        error: (xhr, error) => {
                            reject((_translations.bofVl42p || (_translations.bofVl42p = tr("Failed to load file: "))) + error);
                        }
                    });
                });
                Object.assign(repo, info_json);
            }
            if (!repo.unique_id)
                repo.unique_id = guid();
            repo.translations = repo.translations || [];
            repo.load_timestamp = Date.now();
        });
    }
    function load_repository(url) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = {};
            result.url = url;
            yield load_repository0(result, false);
            return result;
        });
    }
    i18n.load_repository = load_repository;
    let config;
    (function (config_1) {
        const repository_config_key = "i18n.repository";
        let _cached_repository_config;
        function repository_config() {
            if (_cached_repository_config)
                return _cached_repository_config;
            const config_string = localStorage.getItem(repository_config_key);
            const config = config_string ? JSON.parse(config_string) : {};
            config.repositories = config.repositories || [];
            for (const repo of config.repositories)
                (repo.repository || { load_timestamp: 0 }).load_timestamp = 0;
            if (config.repositories.length == 0) {
                //Add the default TeaSpeak repository
                load_repository(StaticSettings.instance.static("i18n.default_repository", "i18n/")).then(repo => {
                    log.info(LogCategory.I18N, _translations.NeD9Sp31 || (_translations.NeD9Sp31 = tr("Successfully added default repository from \"%s\".")), repo.url);
                    register_repository(repo);
                }).catch(error => {
                    log.warn(LogCategory.I18N, _translations.csZiF9ZZ || (_translations.csZiF9ZZ = tr("Failed to add default repository. Error: %o")), error);
                });
            }
            return _cached_repository_config = config;
        }
        config_1.repository_config = repository_config;
        function save_repository_config() {
            localStorage.setItem(repository_config_key, JSON.stringify(_cached_repository_config));
        }
        config_1.save_repository_config = save_repository_config;
        const translation_config_key = "i18n.translation";
        let _cached_translation_config;
        function translation_config() {
            if (_cached_translation_config)
                return _cached_translation_config;
            const config_string = localStorage.getItem(translation_config_key);
            _cached_translation_config = config_string ? JSON.parse(config_string) : {};
            return _cached_translation_config;
        }
        config_1.translation_config = translation_config;
        function save_translation_config() {
            localStorage.setItem(translation_config_key, JSON.stringify(_cached_translation_config));
        }
        config_1.save_translation_config = save_translation_config;
    })(config = i18n.config || (i18n.config = {}));
    function register_repository(repository) {
        if (!repository)
            return;
        for (const repo of config.repository_config().repositories)
            if (repo.url == repository.url)
                return;
        config.repository_config().repositories.push(repository);
        config.save_repository_config();
    }
    i18n.register_repository = register_repository;
    function registered_repositories() {
        return config.repository_config().repositories.map(e => e.repository || { url: e.url, load_timestamp: 0 });
    }
    i18n.registered_repositories = registered_repositories;
    function delete_repository(repository) {
        if (!repository)
            return;
        for (const repo of [...config.repository_config().repositories])
            if (repo.url == repository.url) {
                config.repository_config().repositories.remove(repo);
            }
        config.save_repository_config();
    }
    i18n.delete_repository = delete_repository;
    function iterate_translations(callback_entry, callback_finish) {
        let count = 0;
        const update_finish = () => {
            if (count == 0 && callback_finish)
                callback_finish();
        };
        for (const repo of registered_repositories()) {
            count++;
            load_repository0(repo, false).then(() => {
                for (const translation of repo.translations || []) {
                    const translation_path = repo.url + "/" + translation.path;
                    count++;
                    load_translation_file(translation_path).then(file => {
                        if (callback_entry) {
                            try {
                                callback_entry(repo, file);
                            }
                            catch (error) {
                                console.error(error);
                                //TODO more error handling?
                            }
                        }
                        count--;
                        update_finish();
                    }).catch(error => {
                        log.warn(LogCategory.I18N, _translations.DSlUZ1S8 || (_translations.DSlUZ1S8 = tr("Failed to load translation file for repository %s. Translation: %s (%s) Error: %o")), repo.name, translation.key, translation_path, error);
                        count--;
                        update_finish();
                    });
                }
                count--;
                update_finish();
            }).catch(error => {
                log.warn(LogCategory.I18N, _translations.flNYUpdo || (_translations.flNYUpdo = tr("Failed to load repository while iteration: %s (%s). Error: %o")), (repo || { name: "unknown" }).name, (repo || { url: "unknown" }).url, error);
                count--;
                update_finish();
            });
        }
        update_finish();
    }
    i18n.iterate_translations = iterate_translations;
    function select_translation(repository, entry) {
        const cfg = config.translation_config();
        if (entry && repository) {
            cfg.current_language = entry.info.name;
            cfg.current_repository_url = repository.url;
            cfg.current_translation_url = entry.url;
        }
        else {
            cfg.current_language = undefined;
            cfg.current_repository_url = undefined;
            cfg.current_translation_url = undefined;
        }
        config.save_translation_config();
    }
    i18n.select_translation = select_translation;
    function initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            const rcfg = config.repository_config(); /* initialize */
            const cfg = config.translation_config();
            if (cfg.current_translation_url) {
                try {
                    yield load_file(cfg.current_translation_url);
                }
                catch (error) {
                    createErrorModal(_translations.xAwamJT4 || (_translations.xAwamJT4 = tr("Translation System")), (_translations.mrGYvfC2 || (_translations.mrGYvfC2 = tr("Failed to load current selected translation file."))) + "<br>File: " + cfg.current_translation_url + "<br>Error: " + error + "<br>" + (_translations.ItT9ld9A || (_translations.ItT9ld9A = tr("Using default fallback translations.")))).open();
                }
            }
            // await load_file("http://localhost/home/TeaSpeak/TeaSpeak/Web-Client/web/environment/development/i18n/de_DE.translation");
            // await load_file("http://localhost/home/TeaSpeak/TeaSpeak/Web-Client/web/environment/development/i18n/test.json");
        });
    }
    i18n.initialize = initialize;
})(i18n || (i18n = {}));
const tr = i18n.tr;
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["13a02e5c03f5a80461cc97ce421c8548fd11ab3ec1c41a057b232a40a0b4f496"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["13a02e5c03f5a80461cc97ce421c8548fd11ab3ec1c41a057b232a40a0b4f496"] = "13a02e5c03f5a80461cc97ce421c8548fd11ab3ec1c41a057b232a40a0b4f496";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "dQUcP8ob", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/utils/tab.ts (21,18)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../i18n/localize.ts" />
if (typeof (customElements) !== "undefined") {
    class X_Tab extends HTMLElement {
    }
    class X_Entry extends HTMLElement {
    }
    class X_Tag extends HTMLElement {
    }
    class X_Content extends HTMLElement {
    }
    customElements.define('x-tab', X_Tab, { extends: 'div' });
    customElements.define('x-entry', X_Entry, { extends: 'div' });
    customElements.define('x-tag', X_Tag, { extends: 'div' });
    customElements.define('x-content', X_Content, { extends: 'div' });
}
else {
    console.warn(_translations.dQUcP8ob || (_translations.dQUcP8ob = tr("Could not defied tab customElements!")));
}
var TabFunctions = {
    tabify(template, copy = true) {
        console.log("Tabify: copy=" + copy);
        console.log(template);
        let tag = $.spawn("div");
        tag.addClass("tab");
        let header = $.spawn("div");
        header.addClass("tab-header");
        let content = $.spawn("div");
        content.addClass("tab-content");
        let silentContent = $.spawn("div");
        silentContent.addClass("tab-content-invisible");
        template.find("x-entry").each((_, _entry) => {
            const entry = $(_entry);
            let tag_header = $.spawn("div").addClass("entry");
            if (copy)
                tag_header.append(entry.find("x-tag").clone(true, true));
            else
                tag_header.append(entry.find("x-tag"));
            const tag_content = copy ? entry.find("x-content").clone(true, true) : entry.find("x-content");
            content.append(tag_content.hide());
            tag_header.on("click", () => {
                if (tag_header.hasClass("selected"))
                    return;
                tag.find(".tab-header .selected").removeClass("selected");
                tag_header.addClass("selected");
                content.find("> x-content").hide();
                /* don't show many nodes at once */
                let entries = tag_content.find(".tab-show-partitional");
                entries.hide();
                const show_next = index => {
                    console.log("Show " + index);
                    if (index >= entries.length)
                        return;
                    entries.eq(index).show();
                    setTimeout(show_next.bind(undefined, index + 1), 0);
                };
                show_next(0);
                tag_content.show();
            });
            console.log(this);
            header.append(tag_header);
        });
        header.find(".entry").first().trigger("click");
        tag.append(header);
        tag.append(content);
        tag.append(silentContent);
        return tag;
    }
};
if (!$.fn.asTabWidget) {
    $.fn.asTabWidget = function (copy) {
        if ($(this).prop("tagName") == "X-TAB")
            return TabFunctions.tabify($(this), typeof (copy) === "boolean" ? copy : true);
        else {
            throw "Invalid tag! " + $(this).prop("tagName");
        }
    };
}
if (!$.fn.tabify) {
    $.fn.tabify = function (copy) {
        try {
            let self = this.asTabWidget(copy);
            this.replaceWith(self);
        }
        catch (object) { }
        this.find("x-tab").each(function () {
            $(this).replaceWith($(this).asTabWidget(copy));
        });
        return this;
    };
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["e6803af9bb0cad21119e8ea81286d945503693dd3069e1ea98d7309ff2c85f35"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["e6803af9bb0cad21119e8ea81286d945503693dd3069e1ea98d7309ff2c85f35"] = "e6803af9bb0cad21119e8ea81286d945503693dd3069e1ea98d7309ff2c85f35";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var profiles;
(function (profiles) {
    var identities;
    (function (identities) {
        let IdentitifyType;
        (function (IdentitifyType) {
            IdentitifyType[IdentitifyType["TEAFORO"] = 0] = "TEAFORO";
            IdentitifyType[IdentitifyType["TEAMSPEAK"] = 1] = "TEAMSPEAK";
            IdentitifyType[IdentitifyType["NICKNAME"] = 2] = "NICKNAME";
        })(IdentitifyType = identities.IdentitifyType || (identities.IdentitifyType = {}));
        function decode_identity(type, data) {
            let identity;
            switch (type) {
                case IdentitifyType.NICKNAME:
                    identity = new identities.NameIdentity();
                    break;
                case IdentitifyType.TEAFORO:
                    identity = new identities.TeaForumIdentity(undefined, undefined);
                    break;
                case IdentitifyType.TEAMSPEAK:
                    identity = new identities.TeamSpeakIdentity(undefined, undefined);
                    break;
            }
            if (!identity)
                return undefined;
            if (!identity.decode(data))
                return undefined;
            return identity;
        }
        identities.decode_identity = decode_identity;
        function create_identity(type) {
            let identity;
            switch (type) {
                case IdentitifyType.NICKNAME:
                    identity = new identities.NameIdentity();
                    break;
                case IdentitifyType.TEAFORO:
                    identity = new identities.TeaForumIdentity(undefined, undefined);
                    break;
                case IdentitifyType.TEAMSPEAK:
                    identity = new identities.TeamSpeakIdentity(undefined, undefined);
                    break;
            }
            return identity;
        }
        identities.create_identity = create_identity;
        class AbstractHandshakeIdentityHandler {
            constructor(connection) {
                this.callbacks = [];
                this.connection = connection;
            }
            register_callback(callback) {
                this.callbacks.push(callback);
            }
            trigger_success() {
                for (const callback of this.callbacks)
                    callback(true);
            }
            trigger_fail(message) {
                for (const callback of this.callbacks)
                    callback(false, message);
            }
        }
        identities.AbstractHandshakeIdentityHandler = AbstractHandshakeIdentityHandler;
    })(identities = profiles.identities || (profiles.identities = {}));
})(profiles || (profiles = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["d3a38d6ca23609cdde2aa590002da457263e64889da4fdceb3fab07d17740843"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["d3a38d6ca23609cdde2aa590002da457263e64889da4fdceb3fab07d17740843"] = "d3a38d6ca23609cdde2aa590002da457263e64889da4fdceb3fab07d17740843";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "fUhqZWvr", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (15,21)" }, { name: "y_BwRiUJ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (38,31)" }, { name: "SeFlTlzp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (99,39)" }, { name: "WxOAOU43", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (109,41)" }, { name: "zEL5zW1f", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (167,27)" }, { name: "kiVFO3e0", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (174,39)" }, { name: "MU3WwKqs", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (185,35)" }, { name: "mO_yWAgs", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (188,31)" }, { name: "Efq6NImc", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (202,33)" }, { name: "RXNyfnGh", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (222,31)" }, { name: "f0jkOgP0", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (225,27)" }, { name: "djFWqiUF", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (238,33)" }, { name: "enucDkCJ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (242,35)" }, { name: "natHPmkE", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (318,33)" }, { name: "uhgdMwwn", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (336,43)" }, { name: "D1Pirwax", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (359,46)" }, { name: "kY6eYjB2", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (359,67)" }, { name: "xRhF4Hwj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (385,36)" }, { name: "f5tqgjRT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (407,46)" }, { name: "JbGNSec9", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (434,46)" }, { name: "PNTt4wm6", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (443,70)" }, { name: "zX94CWXz", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (572,43)" }, { name: "Phqdhuw4", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (583,39)" }, { name: "KOTybfHC", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (584,39)" }, { name: "wtLz43Do", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (671,34)" }, { name: "F51svwft", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (671,61)" }, { name: "j8ymSHvv", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (691,32)" }, { name: "NmbmTrOV", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalSettings.ts (691,53)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
/// <reference path="../../utils/tab.ts" />
/// <reference path="../../proto.ts" />
/// <reference path="../../voice/AudioController.ts" />
/// <reference path="../../profiles/Identity.ts" />
var Modals;
(function (Modals) {
    var IdentitifyType = profiles.identities.IdentitifyType;
    function spawnSettingsModal() {
        let modal;
        modal = createModal({
            header: _translations.fUhqZWvr || (_translations.fUhqZWvr = tr("Settings")),
            body: () => {
                let template = $("#tmpl_settings").renderTag({
                    client: native_client,
                    valid_forum_identity: profiles.identities.valid_static_forum_identity(),
                    forum_path: settings.static("forum_path"),
                });
                template = $.spawn("div").append(template);
                initialiseSettingListeners(modal, template = template.tabify());
                initialise_translations(template.find(".settings-translations"));
                initialise_profiles(modal, template.find(".settings-profiles"));
                return template;
            },
            footer: () => {
                let footer = $.spawn("div");
                footer.addClass("modal-button-group");
                footer.css("margin-top", "5px");
                footer.css("margin-bottom", "5px");
                footer.css("text-align", "right");
                let buttonOk = $.spawn("button");
                buttonOk.text(_translations.y_BwRiUJ || (_translations.y_BwRiUJ = tr("Ok")));
                buttonOk.click(() => modal.close());
                footer.append(buttonOk);
                return footer;
            },
            width: 750
        });
        modal.open();
        return modal;
    }
    Modals.spawnSettingsModal = spawnSettingsModal;
    function initialiseSettingListeners(modal, tag) {
        //Voice
        initialiseVoiceListeners(modal, tag.find(".settings_audio"));
    }
    function initialiseVoiceListeners(modal, tag) {
        let currentVAD = settings.global("vad_type", "ppt");
        { //Initialized voice activation detection
            const vad_tag = tag.find(".settings-vad-container");
            vad_tag.find('input[type=radio]').on('change', event => {
                const select = event.currentTarget;
                {
                    vad_tag.find(".settings-vad-impl-entry").hide();
                    vad_tag.find(".setting-vad-" + select.value).show();
                }
                {
                    settings.changeGlobal("vad_type", select.value);
                    globalClient.voiceConnection.voiceRecorder.reinitialiseVAD();
                }
                switch (select.value) {
                    case "ppt":
                        let ppt_settings = settings.global('vad_ppt_settings', undefined);
                        ppt_settings = ppt_settings ? JSON.parse(ppt_settings) : {};
                        vad_tag.find(".vat_ppt_key").text(ppt.key_description(ppt_settings));
                        break;
                    case "vad":
                        let slider = vad_tag.find(".vad_vad_slider");
                        let vad = globalClient.voiceConnection.voiceRecorder.getVADHandler();
                        slider.val(vad.percentageThreshold);
                        slider.trigger("change");
                        globalClient.voiceConnection.voiceRecorder.update(true);
                        vad.percentage_listener = per => {
                            vad_tag.find(".vad_vad_bar_filler")
                                .css("width", per + "%");
                        };
                        break;
                }
            });
            { //Initialized push to talk
                vad_tag.find(".vat_ppt_key").click(function () {
                    let modal = createModal({
                        body: "",
                        header: () => {
                            let head = $.spawn("div");
                            head.text(_translations.SeFlTlzp || (_translations.SeFlTlzp = tr("Type the key you wish")));
                            head.css("background-color", "blue");
                            return head;
                        },
                        footer: ""
                    });
                    let listener = (event) => {
                        if (event.type == ppt.EventType.KEY_TYPED) {
                            settings.changeGlobal('vad_ppt_key', undefined); //TODO remove that because its legacy shit
                            console.log(_translations.WxOAOU43 || (_translations.WxOAOU43 = tr("Got key %o")), event);
                            let ppt_settings = settings.global('vad_ppt_settings', undefined);
                            ppt_settings = ppt_settings ? JSON.parse(ppt_settings) : {};
                            Object.assign(ppt_settings, event);
                            settings.changeGlobal('vad_ppt_settings', ppt_settings);
                            globalClient.voiceConnection.voiceRecorder.reinitialiseVAD();
                            ppt.unregister_key_listener(listener);
                            modal.close();
                            vad_tag.find(".vat_ppt_key").text(ppt.key_description(event));
                        }
                    };
                    ppt.register_key_listener(listener);
                    modal.open();
                });
            }
            { //Initialized voice activation detection
                let slider = vad_tag.find(".vad_vad_slider");
                slider.on("input change", () => {
                    settings.changeGlobal("vad_threshold", slider.val().toString());
                    let vad = globalClient.voiceConnection.voiceRecorder.getVADHandler();
                    if (vad instanceof VoiceActivityDetectorVAD)
                        vad.percentageThreshold = slider.val();
                    vad_tag.find(".vad_vad_slider_value").text(slider.val().toString());
                });
                modal.properties.registerCloseListener(() => {
                    let vad = globalClient.voiceConnection.voiceRecorder.getVADHandler();
                    if (vad instanceof VoiceActivityDetectorVAD)
                        vad.percentage_listener = undefined;
                });
            }
            let target_tag = vad_tag.find('input[type=radio][name="vad_type"][value="' + currentVAD + '"]');
            if (target_tag.length == 0) {
                //TODO tr
                console.warn("Failed to find tag for " + currentVAD + ". Using latest tag!");
                target_tag = vad_tag.find('input[type=radio][name="vad_type"]').last();
            }
            target_tag.prop("checked", true);
            setTimeout(() => target_tag.trigger('change'), 0);
        }
        { //Initialize microphone
            const setting_tag = tag.find(".settings-microphone");
            const tag_select = setting_tag.find(".audio-select-microphone");
            console.log(setting_tag);
            console.log(setting_tag.find(".settings-device-error"));
            console.log(setting_tag.find(".settings-device-error").html());
            { //List devices
                $.spawn("option")
                    .attr("device-id", "")
                    .attr("device-group", "")
                    .text(_translations.zEL5zW1f || (_translations.zEL5zW1f = tr("No device")))
                    .appendTo(tag_select);
                navigator.mediaDevices.enumerateDevices().then(devices => {
                    const active_device = globalClient.voiceConnection.voiceRecorder.device_id();
                    for (const device of devices) {
                        console.debug(_translations.kiVFO3e0 || (_translations.kiVFO3e0 = tr("Got device %s (%s): %s")), device.deviceId, device.kind, device.label);
                        if (device.kind !== 'audioinput')
                            continue;
                        $.spawn("option")
                            .attr("device-id", device.deviceId)
                            .attr("device-group", device.groupId)
                            .text(device.label)
                            .prop("selected", device.deviceId == active_device)
                            .appendTo(tag_select);
                    }
                }).catch(error => {
                    console.error(_translations.MU3WwKqs || (_translations.MU3WwKqs = tr("Could not enumerate over devices!")));
                    console.error(error);
                    setting_tag.find(".settings-device-error")
                        .text(_translations.mO_yWAgs || (_translations.mO_yWAgs = tr("Could not get device list!")))
                        .css("display", "block");
                });
                if (tag_select.find("option:selected").length == 0)
                    tag_select.find("option").prop("selected", true);
            }
            {
                tag_select.on('change', event => {
                    let selected_tag = tag_select.find("option:selected");
                    let deviceId = selected_tag.attr("device-id");
                    let groupId = selected_tag.attr("device-group");
                    console.log(_translations.Efq6NImc || (_translations.Efq6NImc = tr("Selected microphone device: id: %o group: %o")), deviceId, groupId);
                    globalClient.voiceConnection.voiceRecorder.change_device(deviceId, groupId);
                });
            }
        }
        { //Initialize speaker
            const setting_tag = tag.find(".settings-speaker");
            const tag_select = setting_tag.find(".audio-select-speaker");
            const active_device = audio.player.current_device();
            audio.player.available_devices().then(devices => {
                for (const device of devices) {
                    $.spawn("option")
                        .attr("device-id", device.device_id)
                        .text(device.name)
                        .prop("selected", device.device_id == active_device.device_id)
                        .appendTo(tag_select);
                }
            }).catch(error => {
                console.error(_translations.RXNyfnGh || (_translations.RXNyfnGh = tr("Could not enumerate over devices!")));
                console.error(error);
                setting_tag.find(".settings-device-error")
                    .text(_translations.f0jkOgP0 || (_translations.f0jkOgP0 = tr("Could not get device list!")))
                    .css("display", "block");
            });
            if (tag_select.find("option:selected").length == 0)
                tag_select.find("option").prop("selected", true);
            {
                const error_tag = setting_tag.find(".settings-device-error");
                tag_select.on('change', event => {
                    let selected_tag = tag_select.find("option:selected");
                    let deviceId = selected_tag.attr("device-id");
                    console.log(_translations.djFWqiUF || (_translations.djFWqiUF = tr("Selected speaker device: id: %o")), deviceId);
                    audio.player.set_device(deviceId).then(() => error_tag.css("display", "none")).catch(error => {
                        console.error(error);
                        error_tag
                            .text(_translations.enucDkCJ || (_translations.enucDkCJ = tr("Failed to change device!")))
                            .css("display", "block");
                    });
                });
            }
        }
        //Initialise microphones
        /*
        let select_microphone = tag.find(".voice_microphone_select");
        let select_error = tag.find(".voice_microphone_select_error");

        navigator.mediaDevices.enumerateDevices().then(devices => {
            let recoder = globalClient.voiceConnection.voiceRecorder;

            console.log("Got " + devices.length + " devices:");
            for(let device of devices) {
                console.log(" - Type: %s Name %s ID: %s Group: %s", device.kind, device.label, device.deviceId, device.groupId);
                if(device.kind == "audioinput") {
                    let dtag = $.spawn("option");
                    dtag.attr("device-id", device.deviceId);
                    dtag.attr("device-group", device.groupId);
                    dtag.text(device.label);
                    select_microphone.append(dtag);

                    if(recoder) dtag.prop("selected", device.deviceId == recoder.device_id());
                }
            }
        }).catch(error => {
            console.error("Could not enumerate over devices!");
            console.error(error);
            select_error.text("Could not get device list!").show();
        });

        select_microphone.change(event => {
            let deviceSelected = select_microphone.find("option:selected");
            let deviceId = deviceSelected.attr("device-id");
            let groupId = deviceSelected.attr("device-group");
            console.log("Selected microphone device: id: %o group: %o", deviceId, groupId);
            globalClient.voiceConnection.voiceRecorder.change_device(deviceId, groupId);
        });
        */
        //Initialise speakers
    }
    function initialise_translations(tag) {
        { //Initialize the list
            const tag_list = tag.find(".setting-list .list");
            const tag_loading = tag.find(".setting-list .loading");
            const template = $("#settings-translations-list-entry");
            const restart_hint = tag.find(".setting-list .restart-note");
            restart_hint.hide();
            const update_list = () => {
                tag_list.empty();
                const currently_selected = i18n.config.translation_config().current_translation_url;
                { //Default translation
                    const tag = template.renderTag({
                        type: "default",
                        selected: !currently_selected || currently_selected == "default"
                    });
                    tag.on('click', () => {
                        i18n.select_translation(undefined, undefined);
                        tag_list.find(".selected").removeClass("selected");
                        tag.addClass("selected");
                        restart_hint.show();
                    });
                    tag.appendTo(tag_list);
                }
                {
                    const display_repository_info = (repository) => {
                        const info_modal = createModal({
                            header: _translations.natHPmkE || (_translations.natHPmkE = tr("Repository info")),
                            body: () => {
                                return $("#settings-translations-list-entry-info").renderTag({
                                    type: "repository",
                                    name: repository.name,
                                    url: repository.url,
                                    contact: repository.contact,
                                    translations: repository.translations || []
                                });
                            },
                            footer: () => {
                                let footer = $.spawn("div");
                                footer.addClass("modal-button-group");
                                footer.css("margin-top", "5px");
                                footer.css("margin-bottom", "5px");
                                footer.css("text-align", "right");
                                let buttonOk = $.spawn("button");
                                buttonOk.text(_translations.uhgdMwwn || (_translations.uhgdMwwn = tr("Close")));
                                buttonOk.click(() => info_modal.close());
                                footer.append(buttonOk);
                                return footer;
                            }
                        });
                        info_modal.open();
                    };
                    tag_loading.show();
                    i18n.iterate_translations((repo, entry) => {
                        let repo_tag = tag_list.find("[repository=\"" + repo.unique_id + "\"]");
                        if (repo_tag.length == 0) {
                            repo_tag = template.renderTag({
                                type: "repository",
                                name: repo.name || repo.url,
                                id: repo.unique_id
                            });
                            repo_tag.find(".button-delete").on('click', e => {
                                e.preventDefault();
                                Modals.spawnYesNo(_translations.D1Pirwax || (_translations.D1Pirwax = tr("Are you sure?")), _translations.kY6eYjB2 || (_translations.kY6eYjB2 = tr("Do you really want to delete this repository?")), answer => {
                                    if (answer) {
                                        i18n.delete_repository(repo);
                                        update_list();
                                    }
                                });
                            });
                            repo_tag.find(".button-info").on('click', e => {
                                e.preventDefault();
                                display_repository_info(repo);
                            });
                            tag_list.append(repo_tag);
                        }
                        const tag = template.renderTag({
                            type: "translation",
                            name: entry.info.name || entry.url,
                            id: repo.unique_id,
                            selected: i18n.config.translation_config().current_translation_url == entry.url
                        });
                        tag.find(".button-info").on('click', e => {
                            e.preventDefault();
                            const info_modal = createModal({
                                header: _translations.xRhF4Hwj || (_translations.xRhF4Hwj = tr("Translation info")),
                                body: () => {
                                    const tag = $("#settings-translations-list-entry-info").renderTag({
                                        type: "translation",
                                        name: entry.info.name,
                                        url: entry.url,
                                        repository_name: repo.name,
                                        contributors: entry.info.contributors || []
                                    });
                                    tag.find(".button-info").on('click', () => display_repository_info(repo));
                                    return tag;
                                },
                                footer: () => {
                                    let footer = $.spawn("div");
                                    footer.addClass("modal-button-group");
                                    footer.css("margin-top", "5px");
                                    footer.css("margin-bottom", "5px");
                                    footer.css("text-align", "right");
                                    let buttonOk = $.spawn("button");
                                    buttonOk.text(_translations.f5tqgjRT || (_translations.f5tqgjRT = tr("Close")));
                                    buttonOk.click(() => info_modal.close());
                                    footer.append(buttonOk);
                                    return footer;
                                }
                            });
                            info_modal.open();
                        });
                        tag.on('click', e => {
                            if (e.isDefaultPrevented())
                                return;
                            i18n.select_translation(repo, entry);
                            tag_list.find(".selected").removeClass("selected");
                            tag.addClass("selected");
                            restart_hint.show();
                        });
                        tag.insertAfter(repo_tag);
                    }, () => {
                        tag_loading.hide();
                    });
                }
            };
            {
                tag.find(".button-add-repository").on('click', () => {
                    createInputModal("Enter URL", _translations.JbGNSec9 || (_translations.JbGNSec9 = tr("Enter repository URL:<br>")), text => true, url => {
                        if (!url)
                            return;
                        tag_loading.show();
                        i18n.load_repository(url).then(repository => {
                            i18n.register_repository(repository);
                            update_list();
                        }).catch(error => {
                            tag_loading.hide();
                            createErrorModal("Failed to load repository", (_translations.PNTt4wm6 || (_translations.PNTt4wm6 = tr("Failed to query repository.<br>Ensure that this repository is valid and reachable.<br>Error: "))) + error).open();
                        });
                    }).open();
                });
            }
            restart_hint.find(".button-reload").on('click', () => {
                location.reload();
            });
            update_list();
        }
    }
    function initialise_profiles(modal, tag) {
        const settings_tag = tag.find(".profile-settings");
        let selected_profile;
        let nickname_listener;
        let status_listener;
        const display_settings = (profile) => {
            selected_profile = profile;
            settings_tag.find(".setting-name").val(profile.profile_name);
            settings_tag.find(".setting-default-nickname").val(profile.default_username);
            settings_tag.find(".setting-default-password").val(profile.default_password);
            {
                //change listener
                const select_tag = settings_tag.find(".select-container select")[0];
                const type = profile.selected_identity_type.toLowerCase();
                select_tag.onchange = () => {
                    console.log("Selected: " + select_tag.value);
                    settings_tag.find(".identity-settings.active").removeClass("active");
                    settings_tag.find(".identity-settings-" + select_tag.value).addClass("active");
                    profile.selected_identity_type = select_tag.value.toLowerCase();
                    const selected_type = profile.selected_type();
                    const identity = profile.selected_identity();
                    profiles.mark_need_save();
                    if (selected_type == IdentitifyType.TEAFORO) {
                        const forum_tag = settings_tag.find(".identity-settings-teaforo");
                        forum_tag.find(".connected, .disconnected").hide();
                        if (identity && identity.valid()) {
                            forum_tag.find(".connected").show();
                        }
                        else {
                            forum_tag.find(".disconnected").show();
                        }
                    }
                    else if (selected_type == IdentitifyType.TEAMSPEAK) {
                        console.log("Set: " + identity);
                        const teamspeak_tag = settings_tag.find(".identity-settings-teamspeak");
                        if (identity)
                            teamspeak_tag.find(".identity_string").val(identity.exported());
                        else
                            teamspeak_tag.find(".identity_string").val("");
                    }
                    else if (selected_type == IdentitifyType.NICKNAME) {
                        const name_tag = settings_tag.find(".identity-settings-nickname");
                        if (identity)
                            name_tag.find("input").val(identity.name());
                        else
                            name_tag.find("input").val("");
                    }
                };
                select_tag.value = type;
                select_tag.onchange(undefined);
            }
        };
        const update_profile_list = () => {
            const profile_list = tag.find(".profile-list .list").empty();
            const profile_template = $("#settings-profile-list-entry");
            for (const profile of profiles.profiles()) {
                const list_tag = profile_template.renderTag({
                    profile_name: profile.profile_name,
                    id: profile.id
                });
                const profile_status_update = () => {
                    list_tag.find(".status").hide();
                    if (profile.valid())
                        list_tag.find(".status-valid").show();
                    else
                        list_tag.find(".status-invalid").show();
                };
                list_tag.on('click', event => {
                    /* update ui */
                    profile_list.find(".selected").removeClass("selected");
                    list_tag.addClass("selected");
                    if (profile == selected_profile)
                        return;
                    nickname_listener = () => list_tag.find(".name").text(profile.profile_name);
                    status_listener = profile_status_update;
                    display_settings(profile);
                });
                profile_list.append(list_tag);
                if ((!selected_profile && profile.id == "default") || selected_profile == profile)
                    setTimeout(() => list_tag.trigger('click'), 1);
                profile_status_update();
            }
        };
        /* identity settings */
        {
            { //TeamSpeak change listener
                const teamspeak_tag = settings_tag.find(".identity-settings-teamspeak");
                const display_error = (error) => {
                    if (error) {
                        teamspeak_tag.find(".error-message").show().html(error);
                    }
                    else
                        teamspeak_tag.find(".error-message").hide();
                    status_listener();
                };
                teamspeak_tag.find(".identity_file").on('change', event => {
                    if (!selected_profile)
                        return;
                    const element = event.target;
                    const file_reader = new FileReader();
                    file_reader.onload = function () {
                        const identity = profiles.identities.TSIdentityHelper.loadIdentityFromFileContains(file_reader.result);
                        if (!identity) {
                            display_error((_translations.zX94CWXz || (_translations.zX94CWXz = tr("Failed to parse identity.<br>Reason: "))) + profiles.identities.TSIdentityHelper.last_error());
                            return;
                        }
                        else {
                            teamspeak_tag.find(".identity_string").val(identity.exported());
                            selected_profile.set_identity(IdentitifyType.TEAMSPEAK, identity);
                            profiles.mark_need_save();
                            display_error(undefined);
                        }
                    };
                    file_reader.onerror = ev => {
                        console.error(_translations.Phqdhuw4 || (_translations.Phqdhuw4 = tr("Failed to read give identity file: %o")), ev);
                        display_error(_translations.KOTybfHC || (_translations.KOTybfHC = tr("Failed to read file!")));
                        return;
                    };
                    if (element.files && element.files.length > 0)
                        file_reader.readAsText(element.files[0]);
                });
                teamspeak_tag.find(".identity_string").on('change', event => {
                    if (!selected_profile)
                        return;
                    const element = event.target;
                    if (element.value.length == 0) {
                        display_error("Please provide an identity");
                        selected_profile.set_identity(IdentitifyType.TEAMSPEAK, undefined);
                        profiles.mark_need_save();
                    }
                    else {
                        const identity = profiles.identities.TSIdentityHelper.loadIdentity(element.value);
                        if (!identity) {
                            selected_profile.set_identity(IdentitifyType.TEAMSPEAK, identity);
                            profiles.mark_need_save();
                            display_error("Failed to parse identity string!");
                            return;
                        }
                        selected_profile.set_identity(IdentitifyType.TEAMSPEAK, identity);
                        profiles.mark_need_save();
                        display_error(undefined);
                    }
                });
            }
            { //The forum
                const teaforo_tag = settings_tag.find(".identity-settings-teaforo");
                if (native_client) {
                    teaforo_tag.find(".native-teaforo-login").on('click', event => {
                        setTimeout(() => {
                            const forum = require("teaforo.js");
                            const call = () => {
                                if (modal.shown) {
                                    display_settings(selected_profile);
                                    status_listener();
                                }
                            };
                            forum.register_callback(call);
                            forum.open();
                        }, 0);
                    });
                }
            }
            //TODO add the name!
        }
        /* general settings */
        {
            settings_tag.find(".setting-name").on('change', event => {
                const value = settings_tag.find(".setting-name").val();
                if (value && selected_profile) {
                    selected_profile.profile_name = value;
                    if (nickname_listener)
                        nickname_listener();
                    profiles.mark_need_save();
                    status_listener();
                }
            });
            settings_tag.find(".setting-default-nickname").on('change', event => {
                const value = settings_tag.find(".setting-default-nickname").val();
                if (value && selected_profile) {
                    selected_profile.default_username = value;
                    profiles.mark_need_save();
                    status_listener();
                }
            });
            settings_tag.find(".setting-default-password").on('change', event => {
                const value = settings_tag.find(".setting-default-password").val();
                if (value && selected_profile) {
                    selected_profile.default_username = value;
                    profiles.mark_need_save();
                    status_listener();
                }
            });
        }
        /* general buttons */
        {
            tag.find(".button-add-profile").on('click', event => {
                createInputModal(_translations.wtLz43Do || (_translations.wtLz43Do = tr("Please enter a name")), _translations.F51svwft || (_translations.F51svwft = tr("Please enter a name for the new profile:<br>")), text => text.length > 0 && !profiles.find_profile_by_name(text), value => {
                    if (value) {
                        display_settings(profiles.create_new_profile(value));
                        update_profile_list();
                        profiles.mark_need_save();
                    }
                }).open();
            });
            tag.find(".button-set-default").on('click', event => {
                if (selected_profile && selected_profile.id != 'default') {
                    profiles.set_default_profile(selected_profile);
                    update_profile_list();
                    profiles.mark_need_save();
                }
            });
            tag.find(".button-delete").on('click', event => {
                if (selected_profile && selected_profile.id != 'default') {
                    event.preventDefault();
                    Modals.spawnYesNo(_translations.j8ymSHvv || (_translations.j8ymSHvv = tr("Are you sure?")), _translations.NmbmTrOV || (_translations.NmbmTrOV = tr("Do you really want to delete this profile?")), result => {
                        if (result) {
                            profiles.delete_profile(selected_profile);
                            update_profile_list();
                        }
                    });
                }
            });
        }
        modal.close_listener.push(() => {
            if (profiles.requires_save())
                profiles.save();
        });
        update_profile_list();
    }
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["ee3ca4f29660e06f138b8e9b83d472356db47542c0665d5f5e72c99e38b4faff"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["ee3ca4f29660e06f138b8e9b83d472356db47542c0665d5f5e72c99e38b4faff"] = "ee3ca4f29660e06f138b8e9b83d472356db47542c0665d5f5e72c99e38b4faff";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "ZLmk60Fi", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (35,29)" }, { name: "GTcvEWsu", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (49,38)" }, { name: "P2pt3FtU", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (53,25)" }, { name: "VeduXW8f", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (55,29)" }, { name: "yNUMgmOI", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (71,38)" }, { name: "SYF6ntmy", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (75,25)" }, { name: "wAizPjTH", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (83,34)" }, { name: "b1IYb1nx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (89,29)" }, { name: "VXwFBSMD", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (165,26)" }, { name: "sGulobJh", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (174,26)" }, { name: "XnCflSf0", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (180,21)" }, { name: "NLSZMSSi", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanList.ts (221,25)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var Modals;
(function (Modals) {
    function openBanList(client) {
        let update;
        const modal = spawnBanListModal(() => update(), () => {
            Modals.spawnBanCreate(undefined, result => {
                if (result.server_id < 0)
                    result.server_id = undefined;
                console.log(_translations.ZLmk60Fi || (_translations.ZLmk60Fi = tr("Adding ban %o")), result);
                client.serverConnection.sendCommand("banadd", {
                    ip: result.ip,
                    name: result.name,
                    uid: result.unique_id,
                    hwid: result.hardware_id,
                    banreason: result.reason,
                    time: result.timestamp_expire.getTime() > 0 ? (result.timestamp_expire.getTime() - result.timestamp_created.getTime()) / 1000 : 0,
                    sid: result.server_id
                }).then(() => {
                    update();
                }).catch(error => {
                    //TODO tr
                    createErrorModal(_translations.GTcvEWsu || (_translations.GTcvEWsu = tr("Failed to add ban")), "Failed to add ban.<br>Reason: " + (error instanceof CommandResult ? error.extra_message || error.message : error)).open();
                });
            });
        }, ban => {
            console.log(_translations.P2pt3FtU || (_translations.P2pt3FtU = tr("Editing ban %o")), ban);
            Modals.spawnBanCreate(ban, result => {
                console.log(_translations.VeduXW8f || (_translations.VeduXW8f = tr("Apply edit changes %o")), result);
                if (result.server_id < 0)
                    result.server_id = undefined;
                client.serverConnection.sendCommand("banedit", {
                    banid: result.banid,
                    ip: result.ip,
                    name: result.name,
                    uid: result.unique_id,
                    hwid: result.hardware_id,
                    banreason: result.reason,
                    time: result.timestamp_expire.getTime() > 0 ? (result.timestamp_expire.getTime() - result.timestamp_created.getTime()) / 1000 : 0,
                    sid: result.server_id
                }).then(() => {
                    update();
                }).catch(error => {
                    //TODO tr
                    createErrorModal(_translations.yNUMgmOI || (_translations.yNUMgmOI = tr("Failed to edit ban")), "Failed to edit ban.<br>Reason: " + (error instanceof CommandResult ? error.extra_message || error.message : error)).open();
                });
            });
        }, ban => {
            console.log(_translations.SYF6ntmy || (_translations.SYF6ntmy = tr("Deleting ban %o")), ban);
            client.serverConnection.sendCommand("bandel", {
                banid: ban.banid,
                sid: ban.server_id
            }).then(() => {
                update();
            }).catch(error => {
                //TODO tr
                createErrorModal(_translations.wAizPjTH || (_translations.wAizPjTH = tr("Failed to delete ban")), "Failed to delete ban.<br>Reason: " + (error instanceof CommandResult ? error.extra_message || error.message : error)).open();
            });
        });
        update = () => {
            client.serverConnection.commandHandler["notifybanlist"] = json => {
                console.log(_translations.b1IYb1nx || (_translations.b1IYb1nx = tr("Got banlist: %o")), json);
                let bans = [];
                for (const entry of json) {
                    /*
                    notify[index]["sid"] = elm->serverId;
                    notify[index]["banid"] = elm->banId;
                    if(allow_ip)
                        notify[index]["ip"] = elm->ip;
                    else
                        notify[index]["ip"] = "hidden";
                    notify[index]["name"] = elm->name;
                    notify[index]["uid"] = elm->uid;
                    notify[index]["lastnickname"] = elm->name; //Maybe update?

                    notify[index]["created"] = chrono::duration_cast<chrono::seconds>(elm->created.time_since_epoch()).count();
                    if (elm->until.time_since_epoch().count() != 0)
                    notify[index]["duration"] = chrono::duration_cast<chrono::seconds>(elm->until - elm->created).count();
                    else
                    notify[index]["duration"] = 0;

                    notify[index]["reason"] = elm->reason;
                    notify[index]["enforcements"] = elm->triggered;

                    notify[index]["invokername"] = elm->invokerName;
                    notify[index]["invokercldbid"] = elm->invokerDbId;
                    notify[index]["invokeruid"] = elm->invokerUid;
                    */
                    bans.push({
                        server_id: parseInt(entry["sid"]),
                        banid: parseInt(entry["banid"]),
                        ip: entry["ip"],
                        name: entry["name"],
                        unique_id: entry["uid"],
                        hardware_id: entry["hwid"],
                        timestamp_created: new Date(parseInt(entry["created"]) * 1000),
                        timestamp_expire: new Date(parseInt(entry["duration"]) > 0 ? parseInt(entry["created"]) * 1000 + parseInt(entry["duration"]) * 1000 : 0),
                        invoker_name: entry["invokername"],
                        invoker_database_id: parseInt(entry["invokercldbid"]),
                        invoker_unique_id: entry["invokeruid"],
                        reason: entry["reason"],
                        enforcements: parseInt(entry["enforcements"]),
                        flag_own: entry["invokeruid"] == client.getClient().properties.client_unique_identifier
                    });
                }
                modal.addbans(bans);
            };
            //TODO test permission
            modal.clear();
            client.serverConnection.sendCommand("banlist", { sid: 0 }); //Global ban list
            client.serverConnection.sendCommand("banlist").catch(error => {
                if (error instanceof CommandResult) {
                }
                else {
                    console.error(error);
                }
            });
        };
        update();
    }
    Modals.openBanList = openBanList;
    function spawnBanListModal(callback_update, callback_add, callback_edit, callback_delete) {
        let result = {};
        let entries = [];
        const _callback_edit = ban_id => {
            for (const entry of entries)
                if (entry.banid == ban_id) {
                    callback_edit(entry);
                    return;
                }
            console.warn(_translations.VXwFBSMD || (_translations.VXwFBSMD = tr("Missing ban entry with id %d")), ban_id);
        };
        const _callback_delete = ban_id => {
            for (const entry of entries)
                if (entry.banid == ban_id) {
                    callback_delete(entry);
                    return;
                }
            console.warn(_translations.sGulobJh || (_translations.sGulobJh = tr("Missing ban entry with id %d")), ban_id);
        };
        let update_function;
        let modal;
        modal = createModal({
            header: _translations.XnCflSf0 || (_translations.XnCflSf0 = tr("Banlist")),
            body: () => {
                let template = $("#tmpl_ban_list").renderTag();
                template = $.spawn("div").append(template);
                apply_filter(template.find(".entry-filter"), template.find(".filter-flag-force-own"), template.find(".filter-flag-highlight-own"), template.find(".ban-entry-list"));
                update_function = apply_buttons(template.find(".manage-buttons"), template.find(".ban-entry-list"), callback_add, _callback_edit, _callback_delete);
                template.find(".button-close").on('click', _ => modal.close());
                template.find(".button-refresh").on('click', () => callback_update());
                return template;
            },
            footer: undefined,
            width: "80%",
            height: "80%"
        });
        modal.open();
        modal.close_listener.push(() => entries = []);
        result.addbans = (bans) => {
            for (const entry of bans) {
                entries.push(entry);
                $("#tmpl_ban_entry").renderTag(entry).appendTo(modal.htmlTag.find(".ban-entry-list"));
            }
            modal.htmlTag.find(".entry-filter").trigger("change");
            update_function();
        };
        result.clear = () => {
            entries = [];
            modal.htmlTag.find(".ban-entry-list").children().detach();
            update_function();
        };
        return result;
    }
    Modals.spawnBanListModal = spawnBanListModal;
    function apply_filter(input, show_own_bans, highlight_own_bans, elements) {
        input.on('keyup change', event => {
            const filter = input.val().trim();
            const show_own_only = show_own_bans.prop("checked");
            const highlight_own = highlight_own_bans.prop("checked");
            console.log(_translations.NLSZMSSi || (_translations.NLSZMSSi = tr("Search for filter %s")), filter);
            let shown = 0, hidden = 0;
            elements.find(".ban-entry").each((_idx, _entry) => {
                const entry = $(_entry);
                if (entry.hasClass("ban-entry-own")) {
                    if (highlight_own)
                        entry.addClass("ban-entry-own-bold");
                    else
                        entry.removeClass("ban-entry-own-bold");
                }
                else if (show_own_only) {
                    if (entry.hide().hasClass("selected"))
                        entry.trigger("click");
                    hidden++;
                    return;
                }
                if (filter.length == 0 || entry.text().indexOf(filter) > 0) {
                    entry.show();
                    shown++;
                }
                else {
                    if (entry.hide().hasClass("selected"))
                        entry.trigger("click");
                    hidden++;
                }
            });
            $(".entry-count-info").text((shown + hidden) + " entries. " + shown + " entries shown");
        });
        show_own_bans.on('click', () => input.trigger('change'));
        highlight_own_bans.on('click', () => input.trigger('change'));
    }
    function apply_buttons(tag, elements, cb_add, cb_edit, cb_delete) {
        const update = () => {
            console.log(elements.find("tr.selected").length);
            $(".button-edit, .button-remove").prop("disabled", elements.find("tr.selected").length == 0);
        };
        tag.find(".button-add").on('click', event => cb_add());
        tag.find(".button-edit").on('click', event => {
            const selected = elements.find("tr.selected");
            if (!selected)
                return;
            cb_edit(parseInt(selected.attr("ban-id")));
        });
        tag.find(".button-remove").on('click', event => {
            const selected = elements.find("tr.selected");
            if (!selected)
                return;
            cb_delete(parseInt(selected.attr("ban-id")));
        });
        const element_selected = element => {
            elements.find("tr").removeClass("selected");
            if (element.is(":visible"))
                element.addClass("selected");
            update();
        };
        const click_handler = event => element_selected($(event.currentTarget));
        const context_handler = event => {
            const element = $(event.currentTarget);
            element_selected(element);
            event.preventDefault();
            spawn_context_menu(event.pageX, event.pageY, {
                name: "Edit",
                type: MenuEntryType.ENTRY,
                callback: () => cb_edit(parseInt(element.attr("ban-id")))
            }, {
                name: "Delete",
                type: MenuEntryType.ENTRY,
                callback: () => cb_delete(parseInt(element.attr("ban-id")))
            });
        };
        return () => {
            elements.find("tr").each((_idx, _entry) => {
                _entry.addEventListener("click", click_handler);
                _entry.addEventListener("contextmenu", context_handler);
            });
            update();
        };
    }
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["4a672c2f04dd0e6190e232d45ef07d7edba57b61c1d1f161ddcd69dbb5907544"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["4a672c2f04dd0e6190e232d45ef07d7edba57b61c1d1f161ddcd69dbb5907544"] = "4a672c2f04dd0e6190e232d45ef07d7edba57b61c1d1f161ddcd69dbb5907544";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "lYYfJM3G", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (110,26)" }, { name: "V04x7lOx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (110,50)" }, { name: "z7YHjV3f", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (231,30)" }, { name: "lwTdzbHY", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (231,63)" }, { name: "CVwteySp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (272,26)" }, { name: "McyHy1xn", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (272,43)" }, { name: "QT5FKQYf", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (278,37)" }, { name: "c0Y4MEx7", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (278,54)" }, { name: "TLb_Q39b", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (281,38)" }, { name: "IQ1ndROv", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (287,26)" }, { name: "IsyJiYMU", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (287,49)" }, { name: "mQzS9W9Q", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (305,30)" }, { name: "Z6boGMbx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (305,66)" }, { name: "NNse_VqO", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (312,30)" }, { name: "W5l2e9l7", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (312,58)" }, { name: "hiEapoXT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (326,30)" }, { name: "UMStASYU", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (326,62)" }, { name: "U1mrMiXD", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (445,30)" }, { name: "RoO2LDS3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (445,66)" }, { name: "wgS5kv5C", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (454,30)" }, { name: "KudBbtot", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/frames/ControlBar.ts (454,62)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../client.ts" />
/// <reference path="../modal/ModalSettings.ts" />
/// <reference path="../modal/ModalBanList.ts" />
/*
        client_output_hardware Value: '1'
        client_output_muted Value: '0'
        client_outputonly_muted Value: '0'

        client_input_hardware Value: '1'
        client_input_muted Value: '0'

        client_away Value: '0'
        client_away_message Value: ''
 */
var openBanList = Modals.openBanList;
var spawnConnectModal = Modals.spawnConnectModal;
class ControlBar {
    constructor(handle, htmlTag) {
        this.codec_supported = false;
        this.support_playback = false;
        this.support_record = false;
        this.handle = handle;
        this.htmlTag = htmlTag;
    }
    initialise() {
        this.htmlTag.find(".btn_connect").on('click', this.onConnect.bind(this));
        this.htmlTag.find(".btn_disconnect").on('click', this.onDisconnect.bind(this));
        this.htmlTag.find(".btn_mute_input").on('click', this.onInputMute.bind(this));
        this.htmlTag.find(".btn_mute_output").on('click', this.onOutputMute.bind(this));
        this.htmlTag.find(".btn_open_settings").on('click', this.onOpenSettings.bind(this));
        this.htmlTag.find(".btn_permissions").on('click', this.onPermission.bind(this));
        this.htmlTag.find(".btn_banlist").on('click', this.onBanlist.bind(this));
        {
            let tokens = this.htmlTag.find(".btn_token");
            tokens.find(".button-dropdown").on('click', () => {
                tokens.find(".dropdown").addClass("displayed");
            });
            tokens.on('mouseleave', () => {
                tokens.find(".dropdown").removeClass("displayed");
            });
            tokens.find(".btn_token_use").on('click', this.on_token_use.bind(this));
            tokens.find(".btn_token_list").on('click', this.on_token_list.bind(this));
        }
        {
            let away = this.htmlTag.find(".btn_away");
            away.find(".button-dropdown").on('click', () => {
                away.find(".dropdown").addClass("displayed");
            });
            away.on('mouseleave', () => {
                away.find(".dropdown").removeClass("displayed");
            });
            away.find(".btn_away_toggle").on('click', this.on_away_toggle.bind(this));
            away.find(".btn_away_message").on('click', this.on_away_set_message.bind(this));
        }
        {
            let bookmark = this.htmlTag.find(".btn_bookmark");
            bookmark.find(".button-dropdown").on('click', () => {
                bookmark.find("> .dropdown").addClass("displayed");
            });
            bookmark.on('mouseleave', () => {
                bookmark.find("> .dropdown").removeClass("displayed");
            });
            bookmark.find(".btn_bookmark_list").on('click', this.on_bookmark_manage.bind(this));
            bookmark.find(".btn_bookmark_add").on('click', this.on_bookmark_server_add.bind(this));
            this.update_bookmarks();
            this.update_bookmark_status();
        }
        {
            let query = this.htmlTag.find(".btn_query");
            query.find(".button-dropdown").on('click', () => {
                query.find(".dropdown").addClass("displayed");
            });
            query.on('mouseleave', () => {
                query.find(".dropdown").removeClass("displayed");
            });
            query.find(".btn_query_toggle").on('click', this.on_query_visibility_toggle.bind(this));
            query.find(".btn_query_create").on('click', this.on_query_create.bind(this));
            query.find(".btn_query_manage").on('click', this.on_query_manage.bind(this));
        }
        //Need an initialise
        this.muteInput = settings.global("mute_input") == "1";
        this.muteOutput = settings.global("mute_output") == "1";
        this.query_visibility = settings.global("show_server_queries") == "1";
    }
    on_away_toggle() {
        this._awayMessage = "";
        this.away = !this._away;
    }
    on_away_set_message() {
        createInputModal(_translations.lYYfJM3G || (_translations.lYYfJM3G = tr("Set away message")), _translations.V04x7lOx || (_translations.V04x7lOx = tr("Please enter the away message")), message => true, message => {
            if (message)
                this.away = message;
        }).open();
    }
    onInputMute() {
        this.muteInput = !this._muteInput;
    }
    onOutputMute() {
        this.muteOutput = !this._muteOutput;
    }
    set muteInput(flag) {
        if (this._muteInput == flag)
            return;
        this._muteInput = flag;
        let tag = this.htmlTag.find(".btn_mute_input");
        if (flag) {
            if (!tag.hasClass("activated"))
                tag.addClass("activated");
            tag.find(".icon_x32").attr("class", "icon_x32 client-input_muted");
        }
        else {
            if (tag.hasClass("activated"))
                tag.removeClass("activated");
            tag.find(".icon_x32").attr("class", "icon_x32 client-capture");
        }
        if (this.handle.serverConnection.connected)
            this.handle.serverConnection.sendCommand("clientupdate", {
                client_input_muted: this._muteInput
            });
        settings.changeGlobal("mute_input", this._muteInput);
        this.updateMicrophoneRecordState();
    }
    get muteOutput() { return this._muteOutput; }
    set muteOutput(flag) {
        if (this._muteOutput == flag)
            return;
        this._muteOutput = flag;
        let tag = this.htmlTag.find(".btn_mute_output");
        if (flag) {
            if (!tag.hasClass("activated"))
                tag.addClass("activated");
            tag.find(".icon_x32").attr("class", "icon_x32 client-output_muted");
        }
        else {
            if (tag.hasClass("activated"))
                tag.removeClass("activated");
            tag.find(".icon_x32").attr("class", "icon_x32 client-volume");
        }
        if (this.handle.serverConnection.connected)
            this.handle.serverConnection.sendCommand("clientupdate", {
                client_output_muted: this._muteOutput
            });
        settings.changeGlobal("mute_output", this._muteOutput);
        this.updateMicrophoneRecordState();
    }
    set away(value) {
        if (typeof (value) == "boolean") {
            if (this._away == value)
                return;
            this._away = value;
            this._awayMessage = "";
        }
        else {
            this._awayMessage = value;
            this._away = true;
        }
        let tag = this.htmlTag.find(".btn_away_toggle");
        if (this._away) {
            tag.addClass("activated");
        }
        else {
            tag.removeClass("activated");
        }
        if (this.handle.serverConnection.connected)
            this.handle.serverConnection.sendCommand("clientupdate", {
                client_away: this._away,
                client_away_message: this._awayMessage
            });
        this.updateMicrophoneRecordState();
    }
    updateMicrophoneRecordState() {
        let enabled = !this._muteInput && !this._muteOutput && !this._away;
        this.handle.voiceConnection.voiceRecorder.update(enabled);
    }
    updateProperties() {
        if (this.handle.serverConnection.connected)
            this.handle.serverConnection.sendCommand("clientupdate", {
                client_input_muted: this._muteInput,
                client_output_muted: this._muteOutput,
                client_away: this._away,
                client_away_message: this._awayMessage,
                client_input_hardware: this.codec_supported && this.support_record,
                client_output_hardware: this.codec_supported && this.support_playback
            });
    }
    updateVoice(targetChannel) {
        if (!targetChannel)
            targetChannel = this.handle.getClient().currentChannel();
        let client = this.handle.getClient();
        this.codec_supported = targetChannel ? this.handle.voiceConnection.codecSupported(targetChannel.properties.channel_codec) : true;
        this.support_record = this.handle.voiceConnection.voice_send_support();
        this.support_playback = this.handle.voiceConnection.voice_playback_support();
        this.htmlTag.find(".btn_mute_input").prop("disabled", !this.codec_supported || !this.support_playback || !this.support_record);
        this.htmlTag.find(".btn_mute_output").prop("disabled", !this.codec_supported || !this.support_playback);
        this.handle.serverConnection.sendCommand("clientupdate", {
            client_input_hardware: this.codec_supported && this.support_record,
            client_output_hardware: this.codec_supported && this.support_playback
        });
        if (!this.codec_supported)
            createErrorModal(_translations.z7YHjV3f || (_translations.z7YHjV3f = tr("Channel codec unsupported")), _translations.lwTdzbHY || (_translations.lwTdzbHY = tr("This channel has an unsupported codec.<br>You cant speak or listen to anybody within this channel!"))).open();
        /* Update these properties anyways (for case the server fails to handle the command) */
        client.updateVariables({ key: "client_input_hardware", value: (this.codec_supported && this.support_record) + "" }, { key: "client_output_hardware", value: (this.codec_supported && this.support_playback) + "" });
    }
    onOpenSettings() {
        Modals.spawnSettingsModal();
    }
    onConnect() {
        Modals.spawnConnectModal({
            url: "ts.TeaSpeak.de",
            enforce: false
        });
    }
    update_connection_state() {
        switch (this.handle.serverConnection ? this.handle.serverConnection._connectionState : ConnectionState.UNCONNECTED) {
            case ConnectionState.CONNECTED:
            case ConnectionState.CONNECTING:
            case ConnectionState.INITIALISING:
                this.htmlTag.find(".btn_disconnect").show();
                this.htmlTag.find(".btn_connect").hide();
                break;
            default:
                this.htmlTag.find(".btn_disconnect").hide();
                this.htmlTag.find(".btn_connect").show();
        }
    }
    onDisconnect() {
        this.handle.handleDisconnect(DisconnectReason.REQUESTED); //TODO message?
        this.update_connection_state();
        sound.play(Sound.CONNECTION_DISCONNECTED);
    }
    on_token_use() {
        createInputModal(_translations.CVwteySp || (_translations.CVwteySp = tr("Use token")), _translations.McyHy1xn || (_translations.McyHy1xn = tr("Please enter your token/priviledge key")), message => message.length > 0, result => {
            if (!result)
                return;
            if (this.handle.serverConnection.connected)
                this.handle.serverConnection.sendCommand("tokenuse", {
                    token: result
                }).then(() => {
                    createInfoModal(_translations.QT5FKQYf || (_translations.QT5FKQYf = tr("Use token")), _translations.c0Y4MEx7 || (_translations.c0Y4MEx7 = tr("Toke successfully used!"))).open();
                }).catch(error => {
                    //TODO tr
                    createErrorModal(_translations.TLb_Q39b || (_translations.TLb_Q39b = tr("Use token")), "Failed to use token: " + (error instanceof CommandResult ? error.message : error)).open();
                });
        }).open();
    }
    on_token_list() {
        createErrorModal(_translations.IQ1ndROv || (_translations.IQ1ndROv = tr("Not implemented")), _translations.IsyJiYMU || (_translations.IsyJiYMU = tr("Token list is not implemented yet!"))).open();
    }
    onPermission() {
        let button = this.htmlTag.find(".btn_permissions");
        button.addClass("activated");
        setTimeout(() => {
            Modals.spawnPermissionEdit().open();
            button.removeClass("activated");
        }, 0);
    }
    onBanlist() {
        if (!this.handle.serverConnection)
            return;
        if (this.handle.permissions.neededPermission(PermissionType.B_CLIENT_BAN_LIST).granted(1)) {
            openBanList(this.handle);
        }
        else {
            createErrorModal(_translations.mQzS9W9Q || (_translations.mQzS9W9Q = tr("You dont have the permission")), _translations.Z6boGMbx || (_translations.Z6boGMbx = tr("You dont have the permission to view the ban list"))).open();
            sound.play(Sound.ERROR_INSUFFICIENT_PERMISSIONS);
        }
    }
    on_bookmark_server_add() {
        if (globalClient && globalClient.connected) {
            createInputModal(_translations.NNse_VqO || (_translations.NNse_VqO = tr("Enter bookmarks name")), _translations.W5l2e9l7 || (_translations.W5l2e9l7 = tr("Please enter the bookmarks name:<br>")), text => true, result => {
                if (result) {
                    const bookmark = bookmarks.create_bookmark(result, bookmarks.bookmarks(), {
                        server_port: globalClient.serverConnection._remote_address.port,
                        server_address: globalClient.serverConnection._remote_address.host,
                        server_password: "",
                        server_password_hash: ""
                    }, globalClient.getClient().clientNickName());
                    bookmarks.save_bookmark(bookmark);
                    this.update_bookmarks();
                }
            }).open();
        }
        else {
            createErrorModal(_translations.hiEapoXT || (_translations.hiEapoXT = tr("You have to be connected")), _translations.UMStASYU || (_translations.UMStASYU = tr("You have to be connected!"))).open();
        }
    }
    update_bookmark_status() {
        this.htmlTag.find(".btn_bookmark_add").removeClass("hidden").addClass("disabled");
        this.htmlTag.find(".btn_bookmark_remove").addClass("hidden");
    }
    update_bookmarks() {
        //<div class="btn_bookmark_connect" target="localhost"><a>Localhost</a></div>
        let tag_bookmark = this.htmlTag.find(".btn_bookmark .dropdown");
        tag_bookmark.find(".bookmark, .directory").detach();
        const build_entry = (bookmark) => {
            if (bookmark.type == bookmarks.BookmarkType.ENTRY) {
                const mark = bookmark;
                return $.spawn("div")
                    .addClass("bookmark")
                    .append($.spawn("div").addClass("icon client-server"))
                    .append($.spawn("div")
                    .addClass("name")
                    .text(bookmark.display_name)
                    .on('click', event => {
                    this.htmlTag.find(".btn_bookmark").find(".dropdown").removeClass("displayed");
                    const profile = profiles.find_profile(mark.connect_profile) || profiles.default_profile();
                    if (profile.valid()) {
                        this.handle.startConnection(mark.server_properties.server_address + ":" + mark.server_properties.server_port, profile, mark.nickname, {
                            password: mark.server_properties.server_password_hash,
                            hashed: true
                        });
                    }
                    else {
                        Modals.spawnConnectModal({
                            url: mark.server_properties.server_address + ":" + mark.server_properties.server_port,
                            enforce: true
                        }, {
                            profile: profile,
                            enforce: true
                        });
                    }
                }));
            }
            else {
                const mark = bookmark;
                const container = $.spawn("div").addClass("sub-menu dropdown");
                for (const member of mark.content)
                    container.append(build_entry(member));
                return $.spawn("div")
                    .addClass("directory")
                    .append($.spawn("div").addClass("icon client-folder"))
                    .append($.spawn("div")
                    .addClass("name")
                    .text(bookmark.display_name))
                    .append($.spawn("div").addClass("arrow right"))
                    .append($.spawn("div").addClass("sub-container")
                    .append(container));
            }
        };
        for (const bookmark of bookmarks.bookmarks().content) {
            const entry = build_entry(bookmark);
            tag_bookmark.append(entry);
        }
    }
    on_bookmark_manage() {
        Modals.spawnBookmarkModal();
    }
    get query_visibility() {
        return this._query_visible;
    }
    set query_visibility(flag) {
        if (this._query_visible == flag)
            return;
        this._query_visible = flag;
        settings.global("show_server_queries", flag);
        this.update_query_visibility_button();
        this.handle.channelTree.toggle_server_queries(flag);
    }
    on_query_visibility_toggle() {
        this.query_visibility = !this._query_visible;
        this.update_query_visibility_button();
    }
    update_query_visibility_button() {
        let tag = this.htmlTag.find(".btn_query_toggle");
        if (this._query_visible) {
            tag.addClass("activated");
        }
        else {
            tag.removeClass("activated");
        }
    }
    on_query_create() {
        if (this.handle.permissions.neededPermission(PermissionType.B_CLIENT_CREATE_MODIFY_SERVERQUERY_LOGIN).granted(1)) {
            Modals.spawnQueryCreate();
        }
        else {
            createErrorModal(_translations.U1mrMiXD || (_translations.U1mrMiXD = tr("You dont have the permission")), _translations.RoO2LDS3 || (_translations.RoO2LDS3 = tr("You dont have the permission to create a server query login"))).open();
            sound.play(Sound.ERROR_INSUFFICIENT_PERMISSIONS);
        }
    }
    on_query_manage() {
        if (globalClient && globalClient.connected) {
            Modals.spawnQueryManage(globalClient);
        }
        else {
            createErrorModal(_translations.wgS5kv5C || (_translations.wgS5kv5C = tr("You have to be connected")), _translations.KudBbtot || (_translations.KudBbtot = tr("You have to be connected!"))).open();
        }
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["f44151ba7ac6e12a56c90a45b4d94b8b1ff62e8ec05ba4a18c4ae94a926da7ec"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["f44151ba7ac6e12a56c90a45b4d94b8b1ff62e8ec05ba4a18c4ae94a926da7ec"] = "f44151ba7ac6e12a56c90a45b4d94b8b1ff62e8ec05ba4a18c4ae94a926da7ec";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "vlKbhrE0", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (95,21)" }, { name: "D6hYEMbT", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (102,34)" }, { name: "L9fAoqVl", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (102,70)" }, { name: "hra0r90e", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (137,30)" }, { name: "VErb5pY0", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (182,31)" }, { name: "O7hYZ2AS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (186,25)" }, { name: "OtJKAX30", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (187,25)" }, { name: "wtB7Aqdb", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (192,25)" }, { name: "VRlikEHi", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (202,31)" }, { name: "df92T0Ct", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (204,21)" }, { name: "fFT3f8oM", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (205,21)" }, { name: "yqTxEZkw", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (209,31)" }, { name: "FjHXM0Nj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (211,21)" }, { name: "Ro9K2wbk", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (212,21)" }, { name: "y_oZJRui", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (217,31)" }, { name: "rhVrg3zr", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (220,21)" }, { name: "CdtflbSh", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (221,21)" }, { name: "gDWO02st", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (225,47)" }, { name: "vApqSmgl", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (227,21)" }, { name: "VbCv7CWO", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (234,47)" }, { name: "WwgO2sNX", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (235,34)" }, { name: "TkL67FRg", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (235,57)" }, { name: "NMJTs6FY", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (244,47)" }, { name: "PV6dp8II", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (250,47)" }, { name: "WeUv9BhR", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (256,31)" }, { name: "cJ_owFAP", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/client.ts (257,31)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="log.ts" />
/// <reference path="voice/AudioController.ts" />
/// <reference path="proto.ts" />
/// <reference path="ui/view.ts" />
/// <reference path="connection.ts" />
/// <reference path="settings.ts" />
/// <reference path="ui/frames/SelectedItemInfo.ts" />
/// <reference path="FileManager.ts" />
/// <reference path="permission/PermissionManager.ts" />
/// <reference path="permission/GroupManager.ts" />
/// <reference path="ui/frames/ControlBar.ts" />
var DisconnectReason;
(function (DisconnectReason) {
    DisconnectReason[DisconnectReason["REQUESTED"] = 0] = "REQUESTED";
    DisconnectReason[DisconnectReason["CONNECT_FAILURE"] = 1] = "CONNECT_FAILURE";
    DisconnectReason[DisconnectReason["CONNECTION_CLOSED"] = 2] = "CONNECTION_CLOSED";
    DisconnectReason[DisconnectReason["CONNECTION_FATAL_ERROR"] = 3] = "CONNECTION_FATAL_ERROR";
    DisconnectReason[DisconnectReason["CONNECTION_PING_TIMEOUT"] = 4] = "CONNECTION_PING_TIMEOUT";
    DisconnectReason[DisconnectReason["CLIENT_KICKED"] = 5] = "CLIENT_KICKED";
    DisconnectReason[DisconnectReason["CLIENT_BANNED"] = 6] = "CLIENT_BANNED";
    DisconnectReason[DisconnectReason["HANDSHAKE_FAILED"] = 7] = "HANDSHAKE_FAILED";
    DisconnectReason[DisconnectReason["SERVER_CLOSED"] = 8] = "SERVER_CLOSED";
    DisconnectReason[DisconnectReason["SERVER_REQUIRES_PASSWORD"] = 9] = "SERVER_REQUIRES_PASSWORD";
    DisconnectReason[DisconnectReason["UNKNOWN"] = 10] = "UNKNOWN";
})(DisconnectReason || (DisconnectReason = {}));
var ConnectionState;
(function (ConnectionState) {
    ConnectionState[ConnectionState["UNCONNECTED"] = 0] = "UNCONNECTED";
    ConnectionState[ConnectionState["CONNECTING"] = 1] = "CONNECTING";
    ConnectionState[ConnectionState["INITIALISING"] = 2] = "INITIALISING";
    ConnectionState[ConnectionState["CONNECTED"] = 3] = "CONNECTED";
    ConnectionState[ConnectionState["DISCONNECTING"] = 4] = "DISCONNECTING";
})(ConnectionState || (ConnectionState = {}));
var ViewReasonId;
(function (ViewReasonId) {
    ViewReasonId[ViewReasonId["VREASON_USER_ACTION"] = 0] = "VREASON_USER_ACTION";
    ViewReasonId[ViewReasonId["VREASON_MOVED"] = 1] = "VREASON_MOVED";
    ViewReasonId[ViewReasonId["VREASON_SYSTEM"] = 2] = "VREASON_SYSTEM";
    ViewReasonId[ViewReasonId["VREASON_TIMEOUT"] = 3] = "VREASON_TIMEOUT";
    ViewReasonId[ViewReasonId["VREASON_CHANNEL_KICK"] = 4] = "VREASON_CHANNEL_KICK";
    ViewReasonId[ViewReasonId["VREASON_SERVER_KICK"] = 5] = "VREASON_SERVER_KICK";
    ViewReasonId[ViewReasonId["VREASON_BAN"] = 6] = "VREASON_BAN";
    ViewReasonId[ViewReasonId["VREASON_SERVER_STOPPED"] = 7] = "VREASON_SERVER_STOPPED";
    ViewReasonId[ViewReasonId["VREASON_SERVER_LEFT"] = 8] = "VREASON_SERVER_LEFT";
    ViewReasonId[ViewReasonId["VREASON_CHANNEL_UPDATED"] = 9] = "VREASON_CHANNEL_UPDATED";
    ViewReasonId[ViewReasonId["VREASON_EDITED"] = 10] = "VREASON_EDITED";
    ViewReasonId[ViewReasonId["VREASON_SERVER_SHUTDOWN"] = 11] = "VREASON_SERVER_SHUTDOWN";
})(ViewReasonId || (ViewReasonId = {}));
class TSClient {
    constructor() {
        this._clientId = 0;
        this.selectInfo = new InfoBar(this, $("#select_info"));
        this.channelTree = new ChannelTree(this, $("#channelTree"));
        this.serverConnection = new ServerConnection(this);
        this.fileManager = new FileManager(this);
        this.permissions = new PermissionManager(this);
        this.groups = new GroupManager(this);
        this.voiceConnection = new VoiceConnection(this);
        this._ownEntry = new LocalClientEntry(this);
        this.controlBar = new ControlBar(this, $("#control_bar"));
        this.channelTree.registerClient(this._ownEntry);
    }
    setup() {
        this.controlBar.initialise();
    }
    startConnection(addr, profile, name, password) {
        if (this.serverConnection)
            this.handleDisconnect(DisconnectReason.REQUESTED);
        let idx = addr.lastIndexOf(':');
        let port;
        let host;
        if (idx != -1) {
            port = parseInt(addr.substr(idx + 1));
            host = addr.substr(0, idx);
        }
        else {
            host = addr;
            port = 9987;
        }
        console.log(_translations.vlKbhrE0 || (_translations.vlKbhrE0 = tr("Start connection to %s:%d")), host, port);
        this.channelTree.initialiseHead(addr, { host, port });
        if (password && !password.hashed) {
            helpers.hashPassword(password.password).then(password => {
                this.serverConnection.startConnection({ host, port }, new HandshakeHandler(profile, name, password));
            }).catch(error => {
                createErrorModal(_translations.D6hYEMbT || (_translations.D6hYEMbT = tr("Error while hashing password")), (_translations.L9fAoqVl || (_translations.L9fAoqVl = tr("Failed to hash server password!<br>"))) + error).open();
            });
        }
        else
            this.serverConnection.startConnection({ host, port }, new HandshakeHandler(profile, name, password ? password.password : undefined));
    }
    getClient() { return this._ownEntry; }
    getClientId() { return this._clientId; } //TODO here
    set clientId(id) {
        this._clientId = id;
        this._ownEntry["_clientId"] = id;
    }
    get clientId() {
        return this._clientId;
    }
    getServerConnection() { return this.serverConnection; }
    /**
     * LISTENER
     */
    onConnected() {
        console.log("Client connected!");
        this.channelTree.registerClient(this._ownEntry);
        settings.setServer(this.channelTree.server);
        this.permissions.requestPermissionList();
        this.serverConnection.sendCommand("channelsubscribeall");
        if (this.groups.serverGroups.length == 0)
            this.groups.requestGroups();
        this.controlBar.updateProperties();
        if (!this.voiceConnection.current_encoding_supported())
            createErrorModal(_translations.hra0r90e || (_translations.hra0r90e = tr("Codec encode type not supported!")), tr("Codec encode type " + VoiceConnectionType[this.voiceConnection.type] + " not supported by this browser!<br>Choose another one!")).open(); //TODO tr
    }
    get connected() {
        return !!this.serverConnection && this.serverConnection.connected;
    }
    certAcceptUrl() {
        //TODO here
        const properties = {
            connect_direct: true,
            connect_profile: this.serverConnection._handshakeHandler.profile.id,
            connect_url: this.serverConnection._remote_address.host + ":" + this.serverConnection._remote_address.port
        };
        // document.URL
        let callback = document.URL;
        if (document.location.search.length == 0)
            callback += "?default_connect_url=true";
        else
            callback += "&default_connect_url=true";
        //
        //this.serverConnection._handshakeHandler.profile
        callback += "&connect_profile=" + encodeURIComponent(this.serverConnection._handshakeHandler.profile.id);
        /*
        switch (this.serverConnection._handshakeHandler.profile.type()) {
            case IdentitifyType.TEAFORO:
                callback += "&default_connect_type=teaforo";
                break;
            case IdentitifyType.TEAMSPEAK:
                callback += "&default_connect_type=teamspeak";
                break;
        }
        */
        callback += "&default_connect_url=" + encodeURIComponent(this.serverConnection._remote_address.host + ":" + this.serverConnection._remote_address.port);
        return "https://" + this.serverConnection._remote_address.host + ":" + this.serverConnection._remote_address.port + "/?forward_url=" + encodeURIComponent(callback);
    }
    handleDisconnect(type, data = {}) {
        switch (type) {
            case DisconnectReason.REQUESTED:
                break;
            case DisconnectReason.CONNECT_FAILURE:
                console.error(_translations.VErb5pY0 || (_translations.VErb5pY0 = tr("Could not connect to remote host! Exception: %o")), data);
                if (native_client) {
                    createErrorModal(_translations.O7hYZ2AS || (_translations.O7hYZ2AS = tr("Could not connect")), _translations.OtJKAX30 || (_translations.OtJKAX30 = tr("Could not connect to remote host (Connection refused)"))).open();
                }
                else {
                    //TODO tr
                    createErrorModal(_translations.wtB7Aqdb || (_translations.wtB7Aqdb = tr("Could not connect")), "Could not connect to remote host (Connection refused)<br>" +
                        "If you're sure that the remote host is up, than you may not allow unsigned certificates.<br>" +
                        "Click <a href='" + this.certAcceptUrl() + "'>here</a> to accept the remote certificate").open();
                }
                sound.play(Sound.CONNECTION_REFUSED);
                break;
            case DisconnectReason.HANDSHAKE_FAILED:
                //TODO sound
                console.error(_translations.VRlikEHi || (_translations.VRlikEHi = tr("Failed to process handshake: %o")), data);
                createErrorModal(_translations.df92T0Ct || (_translations.df92T0Ct = tr("Could not connect")), (_translations.fFT3f8oM || (_translations.fFT3f8oM = tr("Failed to process handshake: "))) + data).open();
                break;
            case DisconnectReason.CONNECTION_CLOSED:
                console.error(_translations.yqTxEZkw || (_translations.yqTxEZkw = tr("Lost connection to remote server!")));
                createErrorModal(_translations.FjHXM0Nj || (_translations.FjHXM0Nj = tr("Connection closed")), _translations.Ro9K2wbk || (_translations.Ro9K2wbk = tr("The connection was closed by remote host"))).open();
                sound.play(Sound.CONNECTION_DISCONNECTED);
                break;
            case DisconnectReason.CONNECTION_PING_TIMEOUT:
                console.error(_translations.y_oZJRui || (_translations.y_oZJRui = tr("Connection ping timeout")));
                sound.play(Sound.CONNECTION_DISCONNECTED_TIMEOUT);
                createErrorModal(_translations.rhVrg3zr || (_translations.rhVrg3zr = tr("Connection lost")), _translations.CdtflbSh || (_translations.CdtflbSh = tr("Lost connection to remote host (Ping timeout)<br>Even possible?"))).open();
                break;
            case DisconnectReason.SERVER_CLOSED:
                chat.serverChat().appendError(_translations.gDWO02st || (_translations.gDWO02st = tr("Server closed ({0})")), data.reasonmsg);
                createErrorModal(_translations.vApqSmgl || (_translations.vApqSmgl = tr("Server closed")), "The server is closed.<br>" + //TODO tr
                    "Reason: " + data.reasonmsg).open();
                sound.play(Sound.CONNECTION_DISCONNECTED);
                break;
            case DisconnectReason.SERVER_REQUIRES_PASSWORD:
                chat.serverChat().appendError(_translations.VbCv7CWO || (_translations.VbCv7CWO = tr("Server requires password")));
                createInputModal(_translations.WwgO2sNX || (_translations.WwgO2sNX = tr("Server password")), _translations.TkL67FRg || (_translations.TkL67FRg = tr("Enter server password:")), password => password.length != 0, password => {
                    if (!(typeof password === "string"))
                        return;
                    this.startConnection(this.serverConnection._remote_address.host + ":" + this.serverConnection._remote_address.port, this.serverConnection._handshakeHandler.profile, this.serverConnection._handshakeHandler.name, { password: password, hashed: false });
                }).open();
                break;
            case DisconnectReason.CLIENT_KICKED:
                chat.serverChat().appendError(_translations.NMJTs6FY || (_translations.NMJTs6FY = tr("You got kicked from the server by {0}{1}")), ClientEntry.chatTag(data["invokerid"], data["invokername"], data["invokeruid"]), data["reasonmsg"] ? " (" + data["reasonmsg"] + ")" : "");
                sound.play(Sound.SERVER_KICKED);
                break;
            case DisconnectReason.CLIENT_BANNED:
                chat.serverChat().appendError(_translations.PV6dp8II || (_translations.PV6dp8II = tr("You got banned from the server by {0}{1}")), ClientEntry.chatTag(data["invokerid"], data["invokername"], data["invokeruid"]), data["reasonmsg"] ? " (" + data["reasonmsg"] + ")" : "");
                sound.play(Sound.CONNECTION_BANNED); //TODO findout if it was a disconnect or a connect refuse
                break;
            default:
                console.error(_translations.WeUv9BhR || (_translations.WeUv9BhR = tr("Got uncaught disconnect!")));
                console.error(_translations.cJ_owFAP || (_translations.cJ_owFAP = tr("Type: %o Data:")), type);
                console.error(data);
                break;
        }
        this.channelTree.reset();
        this.voiceConnection.dropSession();
        if (this.serverConnection)
            this.serverConnection.disconnect();
        this.controlBar.update_connection_state();
        this.selectInfo.setCurrentSelected(null);
        this.selectInfo.update_banner();
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["c73029eae42f63ff93f5b959094c4d8a4be7266b5f07f9495fca519b0abb0d4f"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["c73029eae42f63ff93f5b959094c4d8a4be7266b5f07f9495fca519b0abb0d4f"] = "c73029eae42f63ff93f5b959094c4d8a4be7266b5f07f9495fca519b0abb0d4f";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "ICedjNgS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (51,23)" }, { name: "Tf5lzfQA", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (69,27)" }, { name: "CRAYy_6b", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (95,22)" }, { name: "BkuC0X9c", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (102,45)" }, { name: "E2xwPKa6", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (167,27)" }, { name: "omScprYx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (186,27)" }, { name: "R_y8e78L", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (336,35)" }, { name: "G5ycLgRN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (337,51)" }, { name: "UYge6IYj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (358,31)" }, { name: "iPfDOlFS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (359,47)" }, { name: "lylmD9uH", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (385,27)" }, { name: "J2ioI4V8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (398,31)" }, { name: "FwGpN7cx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (400,31)" }, { name: "wmuNaIj3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (409,31)" }, { name: "FVEgTQ0a", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (436,21)" }, { name: "BTPow_48", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (483,35)" }, { name: "iNm05Xqs", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (484,51)" }, { name: "ohZkbrGS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (512,31)" }, { name: "bLrd8M3s", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (513,47)" }, { name: "L6yjxKO8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (535,31)" }, { name: "o0hhDGx1", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (550,35)" }, { name: "AuFeW5k2", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (562,31)" }, { name: "el_fpoV9", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/FileManager.ts (564,68)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="client.ts" />
class FileEntry {
}
class FileListRequest {
}
class DownloadFileTransfer {
    constructor(handle, id) {
        this.currentSize = 0;
        this.on_start = () => { };
        this.on_complete = () => { };
        this.on_fail = (_) => { };
        this.on_data = (_) => { };
        this.transferId = id;
        this._handle = handle;
    }
    startTransfer() {
        if (!this.remoteHost || !this.remotePort || !this.transferKey || !this.totalSize) {
            this.on_fail("Missing data!");
            return;
        }
        console.debug(_translations.ICedjNgS || (_translations.ICedjNgS = tr("Create new file download to %s:%s (Key: %s, Expect %d bytes)")), this.remoteHost, this.remotePort, this.transferId, this.totalSize);
        this._active = true;
        this._socket = new WebSocket("wss://" + this.remoteHost + ":" + this.remotePort);
        this._socket.onopen = this.onOpen.bind(this);
        this._socket.onclose = this.onClose.bind(this);
        this._socket.onmessage = this.onMessage.bind(this);
        this._socket.onerror = this.onError.bind(this);
    }
    onOpen() {
        if (!this._active)
            return;
        this._socket.send(this.transferKey);
        this.on_start();
    }
    onMessage(data) {
        if (!this._active) {
            console.error(_translations.Tf5lzfQA || (_translations.Tf5lzfQA = tr("Got data, but socket closed?")));
            return;
        }
        this._parseActive = true;
        let fileReader = new FileReader();
        fileReader.onload = (event) => {
            this.onBinaryData(new Uint8Array(event.target.result));
            //if(this._socket.readyState != WebSocket.OPEN && !this._succeed) this.on_fail("unexpected close");
            this._parseActive = false;
        };
        fileReader.readAsArrayBuffer(data.data);
    }
    onBinaryData(data) {
        this.currentSize += data.length;
        this.on_data(data);
        if (this.currentSize == this.totalSize) {
            this._succeed = true;
            this.on_complete();
            this.disconnect();
        }
    }
    onError() {
        if (!this._active)
            return;
        this.on_fail(_translations.CRAYy_6b || (_translations.CRAYy_6b = tr("an error occurent")));
        this.disconnect();
    }
    onClose() {
        if (!this._active)
            return;
        if (!this._parseActive)
            this.on_fail(_translations.BkuC0X9c || (_translations.BkuC0X9c = tr("unexpected close (remote closed)")));
        this.disconnect();
    }
    disconnect() {
        this._active = false;
        //this._socket.close();
    }
}
class FileManager {
    constructor(client) {
        this.listRequests = [];
        this.pendingDownloadTransfers = [];
        this.downloadCounter = 0;
        this.handle = client;
        this.icons = new IconManager(this);
        this.avatars = new AvatarManager(this);
        this.handle.serverConnection.commandHandler["notifyfilelist"] = this.notifyFileList.bind(this);
        this.handle.serverConnection.commandHandler["notifyfilelistfinished"] = this.notifyFileListFinished.bind(this);
        this.handle.serverConnection.commandHandler["notifystartdownload"] = this.notifyStartDownload.bind(this);
    }
    /******************************** File list ********************************/
    //TODO multiple requests (same path)
    requestFileList(path, channel, password) {
        const _this = this;
        return new Promise((accept, reject) => {
            let req = new FileListRequest();
            req.path = path;
            req.entries = [];
            req.callback = accept;
            _this.listRequests.push(req);
            _this.handle.serverConnection.sendCommand("ftgetfilelist", { "path": path, "cid": (channel ? channel.channelId : "0"), "cpw": (password ? password : "") }).then(() => { }).catch(reason => {
                _this.listRequests.remove(req);
                if (reason instanceof CommandResult) {
                    if (reason.id == 0x0501) {
                        accept([]); //Empty result
                        return;
                    }
                }
                reject(reason);
            });
        });
    }
    notifyFileList(json) {
        let entry = undefined;
        for (let e of this.listRequests) {
            if (e.path == json[0]["path"]) {
                entry = e;
                break;
            }
        }
        if (!entry) {
            console.error(_translations.E2xwPKa6 || (_translations.E2xwPKa6 = tr("Invalid file list entry. Path: %s")), json[0]["path"]);
            return;
        }
        for (let e of json)
            entry.entries.push(e);
    }
    notifyFileListFinished(json) {
        let entry = undefined;
        for (let e of this.listRequests) {
            if (e.path == json[0]["path"]) {
                entry = e;
                this.listRequests.remove(e);
                break;
            }
        }
        if (!entry) {
            console.error(_translations.omScprYx || (_translations.omScprYx = tr("Invalid file list entry finish. Path: ")), json[0]["path"]);
            return;
        }
        entry.callback(entry.entries);
    }
    /******************************** File download ********************************/
    requestFileDownload(path, file, channel, password) {
        const _this = this;
        let transfer = new DownloadFileTransfer(this, this.downloadCounter++);
        this.pendingDownloadTransfers.push(transfer);
        return new Promise((resolve, reject) => {
            transfer["_promiseCallback"] = resolve;
            _this.handle.serverConnection.sendCommand("ftinitdownload", {
                "path": path,
                "name": file,
                "cid": (channel ? channel.channelId : "0"),
                "cpw": (password ? password : ""),
                "clientftfid": transfer.transferId
            }).catch(reason => {
                _this.pendingDownloadTransfers.remove(transfer);
                reject(reason);
            });
        });
    }
    notifyStartDownload(json) {
        json = json[0];
        let transfer;
        for (let e of this.pendingDownloadTransfers)
            if (e.transferId == json["clientftfid"]) {
                transfer = e;
                break;
            }
        transfer.serverTransferId = json["serverftfid"];
        transfer.transferKey = json["ftkey"];
        transfer.totalSize = json["size"];
        transfer.remotePort = json["port"];
        transfer.remoteHost = (json["ip"] ? json["ip"] : "").replace(/,/g, "");
        if (!transfer.remoteHost || transfer.remoteHost == '0.0.0.0' || transfer.remoteHost == '127.168.0.0')
            transfer.remoteHost = this.handle.serverConnection._remote_address.host;
        transfer["_promiseCallback"](transfer);
        this.pendingDownloadTransfers.remove(transfer);
    }
}
class Icon {
}
var ImageType;
(function (ImageType) {
    ImageType[ImageType["UNKNOWN"] = 0] = "UNKNOWN";
    ImageType[ImageType["BITMAP"] = 1] = "BITMAP";
    ImageType[ImageType["PNG"] = 2] = "PNG";
    ImageType[ImageType["GIF"] = 3] = "GIF";
    ImageType[ImageType["SVG"] = 4] = "SVG";
    ImageType[ImageType["JPEG"] = 5] = "JPEG";
})(ImageType || (ImageType = {}));
function media_image_type(type) {
    switch (type) {
        case ImageType.BITMAP:
            return "bmp";
        case ImageType.GIF:
            return "gif";
        case ImageType.SVG:
            return "svg+xml";
        case ImageType.JPEG:
            return "jpeg";
        case ImageType.UNKNOWN:
        case ImageType.PNG:
        default:
            return "png";
    }
}
function image_type(base64) {
    const bin = atob(base64);
    if (bin.length < 10)
        return ImageType.UNKNOWN;
    if (bin[0] == String.fromCharCode(66) && bin[1] == String.fromCharCode(77)) {
        return ImageType.BITMAP;
    }
    else if (bin.substr(0, 8) == "\x89\x50\x4e\x47\x0d\x0a\x1a\x0a") {
        return ImageType.PNG;
    }
    else if (bin.substr(0, 4) == "\x47\x49\x46\x38" && (bin[4] == '\x37' || bin[4] == '\x39') && bin[5] == '\x61') {
        return ImageType.GIF;
    }
    else if (bin[0] == '\x3c') {
        return ImageType.SVG;
    }
    else if (bin[0] == '\xFF' && bin[1] == '\xd8') {
        return ImageType.JPEG;
    }
    return ImageType.UNKNOWN;
}
class IconManager {
    constructor(handle) {
        this.loading_icons = [];
        this.handle = handle;
    }
    iconList() {
        return this.handle.requestFileList("/icons");
    }
    downloadIcon(id) {
        return this.handle.requestFileDownload("", "/icon_" + id);
    }
    resolveCached(id) {
        let icon = localStorage.getItem("icon_" + id);
        if (icon) {
            let i = JSON.parse(icon);
            if (i.base64.length > 0) { //TODO timestamp?
                return i;
            }
        }
        return undefined;
    }
    load_finished(id) {
        for (let entry of this.loading_icons)
            if (entry.id == id)
                this.loading_icons.remove(entry);
    }
    loadIcon(id) {
        for (let entry of this.loading_icons)
            if (entry.id == id)
                return entry.promise;
        let promise = new Promise((resolve, reject) => {
            let icon = this.resolveCached(id);
            if (icon) {
                this.load_finished(id);
                resolve(icon);
                return;
            }
            this.downloadIcon(id).then(ft => {
                let array = new Uint8Array(0);
                ft.on_fail = reason => {
                    this.load_finished(id);
                    console.error(_translations.R_y8e78L || (_translations.R_y8e78L = tr("Could not download icon %s -> %s")), id, tr(reason));
                    chat.serverChat().appendError(_translations.G5ycLgRN || (_translations.G5ycLgRN = tr("Fail to download icon {0}. ({1})")), id, JSON.stringify(reason));
                    reject(reason);
                };
                ft.on_start = () => { };
                ft.on_data = (data) => {
                    array = concatenate(Uint8Array, array, data);
                };
                ft.on_complete = () => {
                    let base64 = btoa(String.fromCharCode.apply(null, array));
                    let icon = new Icon();
                    icon.base64 = base64;
                    icon.id = id;
                    icon.name = "icon_" + id;
                    localStorage.setItem("icon_" + id, JSON.stringify(icon));
                    this.load_finished(id);
                    resolve(icon);
                };
                ft.startTransfer();
            }).catch(reason => {
                console.error(_translations.UYge6IYj || (_translations.UYge6IYj = tr("Error while downloading icon! (%s)")), tr(JSON.stringify(reason)));
                chat.serverChat().appendError(_translations.iPfDOlFS || (_translations.iPfDOlFS = tr("Failed to request download for icon {0}. ({1})")), id, tr(JSON.stringify(reason)));
                reject(reason);
            });
        });
        this.loading_icons.push({ promise: promise, id: id });
        return promise;
    }
    //$("<img width=\"16\" height=\"16\" alt=\"tick\" src=\"data:image/png;base64," + value.base64 + "\">")
    generateTag(id) {
        if (id == 0)
            return $("<div class='icon_empty'></div>");
        else if (id < 1000)
            return $("<div class='icon client-group_" + id + "'></div>");
        let tag = $.spawn("div");
        tag.addClass("icon_empty");
        let img = $.spawn("img");
        img.attr("width", 16).attr("height", 16).attr("alt", "");
        let icon = this.resolveCached(id);
        if (icon) {
            const type = image_type(icon.base64);
            const media = media_image_type(type);
            console.debug(_translations.lylmD9uH || (_translations.lylmD9uH = tr("Icon has an image type of %o (media: %o)")), type, media);
            img.attr("src", "data:image/" + media + ";base64," + icon.base64);
            tag.append(img);
        }
        else {
            img.attr("src", "file://null");
            let loader = $.spawn("div");
            loader.addClass("icon_loading");
            tag.append(loader);
            this.loadIcon(id).then(icon => {
                const type = image_type(icon.base64);
                const media = media_image_type(type);
                console.debug(_translations.J2ioI4V8 || (_translations.J2ioI4V8 = tr("Icon has an image type of %o (media: %o)")), type, media);
                img.attr("src", "data:image/" + media + ";base64," + icon.base64);
                console.debug(_translations.FwGpN7cx || (_translations.FwGpN7cx = tr("Icon %o loaded :)")), id);
                img.css("opacity", 0);
                tag.append(img);
                loader.animate({ opacity: 0 }, 50, function () {
                    $(this).detach();
                    img.animate({ opacity: 1 }, 150);
                });
            }).catch(reason => {
                console.error(_translations.wmuNaIj3 || (_translations.wmuNaIj3 = tr("Could not load icon %o. Reason: %p")), id, reason);
                loader.removeClass("icon_loading").addClass("icon client-warning").attr("tag", "Could not load icon " + id);
            });
        }
        return tag;
    }
}
class Avatar {
}
class AvatarManager {
    constructor(handle) {
        this.loading_avatars = [];
        this.loaded_urls = [];
        this.handle = handle;
    }
    downloadAvatar(client) {
        console.log(_translations.FVEgTQ0a || (_translations.FVEgTQ0a = tr("Downloading avatar %s")), client.avatarId());
        return this.handle.requestFileDownload("", "/avatar_" + client.avatarId());
    }
    resolveCached(client) {
        let avatar = localStorage.getItem("avatar_" + client.properties.client_unique_identifier);
        if (avatar) {
            let i = JSON.parse(avatar);
            //TODO timestamp?
            if (i.avatarId != client.properties.client_flag_avatar)
                return undefined;
            if (i.base64) {
                if (i.base64.length > 0)
                    return i;
                else
                    i.base64 = undefined;
            }
            if (i.url) {
                for (let url of this.loaded_urls)
                    if (url == i.url)
                        return i;
            }
        }
        return undefined;
    }
    load_finished(name) {
        for (let entry of this.loading_avatars)
            if (entry.name == name)
                this.loading_avatars.remove(entry);
    }
    loadAvatar(client) {
        let name = client.avatarId();
        for (let promise of this.loading_avatars)
            if (promise.name == name)
                return promise.promise;
        let promise = new Promise((resolve, reject) => {
            let avatar = this.resolveCached(client);
            if (avatar) {
                this.load_finished(name);
                resolve(avatar);
                return;
            }
            this.downloadAvatar(client).then(ft => {
                let array = new Uint8Array(0);
                ft.on_fail = reason => {
                    this.load_finished(name);
                    console.error(_translations.BTPow_48 || (_translations.BTPow_48 = tr("Could not download avatar %o -> %s")), client.properties.client_flag_avatar, reason);
                    chat.serverChat().appendError(_translations.iNm05Xqs || (_translations.iNm05Xqs = tr("Fail to download avatar for {0}. ({1})")), client.clientNickName(), JSON.stringify(reason));
                    reject(reason);
                };
                ft.on_start = () => { };
                ft.on_data = (data) => {
                    array = concatenate(Uint8Array, array, data);
                };
                ft.on_complete = () => {
                    let avatar = new Avatar();
                    if (array.length >= 1024 * 1024) {
                        let blob_image = new Blob([array]);
                        avatar.url = URL.createObjectURL(blob_image);
                        avatar.blob = blob_image;
                        this.loaded_urls.push(avatar.url);
                    }
                    else {
                        avatar.base64 = btoa(String.fromCharCode.apply(null, array));
                    }
                    avatar.clientUid = client.clientUid();
                    avatar.avatarId = client.properties.client_flag_avatar;
                    localStorage.setItem("avatar_" + client.properties.client_unique_identifier, JSON.stringify(avatar));
                    this.load_finished(name);
                    resolve(avatar);
                };
                ft.startTransfer();
            }).catch(reason => {
                this.load_finished(name);
                console.error(_translations.ohZkbrGS || (_translations.ohZkbrGS = tr("Error while downloading avatar! (%s)")), JSON.stringify(reason));
                chat.serverChat().appendError(_translations.bLrd8M3s || (_translations.bLrd8M3s = tr("Failed to request avatar download for {0}. ({1})")), client.clientNickName(), JSON.stringify(reason));
                reject(reason);
            });
        });
        this.loading_avatars.push({ promise: promise, name: name });
        return promise;
    }
    generateTag(client) {
        let tag = $.spawn("div");
        let img = $.spawn("img");
        img.attr("alt", "");
        let avatar = this.resolveCached(client);
        if (avatar) {
            if (avatar.url)
                img.attr("src", avatar.url);
            else {
                const type = image_type(avatar.base64);
                const media = media_image_type(type);
                console.debug(_translations.L6yjxKO8 || (_translations.L6yjxKO8 = tr("avatar has an image type of %o (media: %o)")), type, media);
                img.attr("src", "data:image/" + media + ";base64," + avatar.base64);
            }
            tag.append(img);
        }
        else {
            let loader = $.spawn("img");
            loader.attr("src", "img/loading_image.svg").css("width", "75%");
            tag.append(loader);
            this.loadAvatar(client).then(avatar => {
                if (avatar.url)
                    img.attr("src", avatar.url);
                else {
                    const type = image_type(avatar.base64);
                    const media = media_image_type(type);
                    console.debug(_translations.o0hhDGx1 || (_translations.o0hhDGx1 = tr("Avatar has an image type of %o (media: %o)")), type, media);
                    img.attr("src", "data:image/" + media + ";base64," + avatar.base64);
                }
                console.debug("Avatar " + client.clientNickName() + " loaded :)");
                img.css("opacity", 0);
                tag.append(img);
                loader.animate({ opacity: 0 }, 50, function () {
                    $(this).detach();
                    img.animate({ opacity: 1 }, 150);
                });
            }).catch(reason => {
                console.error(_translations.AuFeW5k2 || (_translations.AuFeW5k2 = tr("Could not load avatar for %s. Reason: %s")), client.clientNickName(), reason);
                //TODO Broken image
                loader.addClass("icon client-warning").attr("tag", (_translations.el_fpoV9 || (_translations.el_fpoV9 = tr("Could not load avatar "))) + client.clientNickName());
            });
        }
        return tag;
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["03ced662d07d26f789f93067fd3b29cb0ec27b7b6cf0da43d09d8e783a6bf046"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["03ced662d07d26f789f93067fd3b29cb0ec27b7b6cf0da43d09d8e783a6bf046"] = "03ced662d07d26f789f93067fd3b29cb0ec27b7b6cf0da43d09d8e783a6bf046";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "cyymSaq1", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/PPTListener.ts (41,31)" }, { name: "Hi2xT9On", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/PPTListener.ts (43,31)" }, { name: "CX_EhhZY", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/PPTListener.ts (45,31)" }, { name: "H9Ph3eMh", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/PPTListener.ts (47,31)" }, { name: "B_gziNpF", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/PPTListener.ts (49,58)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var ppt;
(function (ppt) {
    let EventType;
    (function (EventType) {
        EventType[EventType["KEY_PRESS"] = 0] = "KEY_PRESS";
        EventType[EventType["KEY_RELEASE"] = 1] = "KEY_RELEASE";
        EventType[EventType["KEY_TYPED"] = 2] = "KEY_TYPED";
    })(EventType = ppt.EventType || (ppt.EventType = {}));
    let SpecialKey;
    (function (SpecialKey) {
        SpecialKey[SpecialKey["CTRL"] = 0] = "CTRL";
        SpecialKey[SpecialKey["WINDOWS"] = 1] = "WINDOWS";
        SpecialKey[SpecialKey["SHIFT"] = 2] = "SHIFT";
        SpecialKey[SpecialKey["ALT"] = 3] = "ALT";
    })(SpecialKey = ppt.SpecialKey || (ppt.SpecialKey = {}));
    function key_description(key) {
        let result = "";
        if (key.key_shift)
            result += " + " + (_translations.cyymSaq1 || (_translations.cyymSaq1 = tr("Shift")));
        if (key.key_alt)
            result += " + " + (_translations.Hi2xT9On || (_translations.Hi2xT9On = tr("Alt")));
        if (key.key_ctrl)
            result += " + " + (_translations.CX_EhhZY || (_translations.CX_EhhZY = tr("CTRL")));
        if (key.key_windows)
            result += " + " + (_translations.H9Ph3eMh || (_translations.H9Ph3eMh = tr("Win")));
        result += " + " + (key.key_code ? key.key_code : _translations.B_gziNpF || (_translations.B_gziNpF = tr("unset")));
        return result.substr(3);
    }
    ppt.key_description = key_description;
    /*
    export declare function initialize() : Promise<void>;
    export declare function finalize(); // most the times not really required

    export declare function register_key_listener(listener: (_: KeyEvent) => any);
    export declare function unregister_key_listener(listener: (_: KeyEvent) => any);

    export declare function register_key_hook(hook: KeyHook);
    export declare function unregister_key_hook(hook: KeyHook);

    export declare function key_pressed(code: string | SpecialKey) : boolean;
    */
})(ppt || (ppt = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["0bee10207d0e8a8c6d4d1eed111da01f189f8838c4a44001d387b5336f5153e3"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["0bee10207d0e8a8c6d4d1eed111da01f189f8838c4a44001d387b5336f5153e3"] = "0bee10207d0e8a8c6d4d1eed111da01f189f8838c4a44001d387b5336f5153e3";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var bookmarks;
(function (bookmarks_1) {
    function guid() {
        function s4() {
            return Math
                .floor((1 + Math.random()) * 0x10000)
                .toString(16)
                .substring(1);
        }
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
    }
    let BookmarkType;
    (function (BookmarkType) {
        BookmarkType[BookmarkType["ENTRY"] = 0] = "ENTRY";
        BookmarkType[BookmarkType["DIRECTORY"] = 1] = "DIRECTORY";
    })(BookmarkType = bookmarks_1.BookmarkType || (bookmarks_1.BookmarkType = {}));
    let _bookmark_config;
    function bookmark_config() {
        if (_bookmark_config)
            return _bookmark_config;
        let bookmark_json = localStorage.getItem("bookmarks");
        let bookmarks = JSON.parse(bookmark_json) || {};
        _bookmark_config = bookmarks;
        _bookmark_config.root_bookmark = _bookmark_config.root_bookmark || { content: [], display_name: "root", type: BookmarkType.DIRECTORY };
        if (!_bookmark_config.default_added) {
            _bookmark_config.default_added = true;
            create_bookmark("TeaSpeak official Test-Server", _bookmark_config.root_bookmark, {
                server_address: "ts.teaspeak.de",
                server_port: 9987
            }, "Another TeaSpeak user");
            save_config();
        }
        return _bookmark_config;
    }
    function save_config() {
        localStorage.setItem("bookmarks", JSON.stringify(bookmark_config()));
    }
    function bookmarks() {
        return bookmark_config().root_bookmark;
    }
    bookmarks_1.bookmarks = bookmarks;
    function find_bookmark_recursive(parent, uuid) {
        for (const entry of parent.content) {
            if (entry.unique_id == uuid)
                return entry;
            if (entry.type == BookmarkType.DIRECTORY) {
                const result = find_bookmark_recursive(entry, uuid);
                if (result)
                    return result;
            }
        }
        return undefined;
    }
    function find_bookmark(uuid) {
        return find_bookmark_recursive(bookmarks(), uuid);
    }
    bookmarks_1.find_bookmark = find_bookmark;
    function parent_bookmark(bookmark) {
        const books = [bookmarks()];
        while (!books.length) {
            const directory = books.pop_front();
            if (directory.type == BookmarkType.DIRECTORY) {
                const cast = directory;
                if (cast.content.indexOf(bookmark) != -1)
                    return cast;
                books.push(...cast.content);
            }
        }
        return bookmarks();
    }
    bookmarks_1.parent_bookmark = parent_bookmark;
    function create_bookmark(display_name, directory, server_properties, nickname) {
        const bookmark = {
            display_name: display_name,
            server_properties: server_properties,
            nickname: nickname,
            type: BookmarkType.ENTRY,
            connect_profile: "default",
            unique_id: guid()
        };
        directory.content.push(bookmark);
        return bookmark;
    }
    bookmarks_1.create_bookmark = create_bookmark;
    function create_bookmark_directory(parent, name) {
        const bookmark = {
            type: BookmarkType.DIRECTORY,
            display_name: name,
            content: [],
            unique_id: guid()
        };
        parent.content.push(bookmark);
        return bookmark;
    }
    bookmarks_1.create_bookmark_directory = create_bookmark_directory;
    //TODO test if the new parent is within the old bookmark
    function change_directory(parent, bookmark) {
        delete_bookmark(bookmark);
        parent.content.push(bookmark);
    }
    bookmarks_1.change_directory = change_directory;
    function save_bookmark(bookmark) {
        save_config(); /* nvm we dont give a fuck... saving everything */
    }
    bookmarks_1.save_bookmark = save_bookmark;
    function delete_bookmark_recursive(parent, bookmark) {
        const index = parent.content.indexOf(bookmark);
        if (index != -1)
            parent.content.remove(bookmark);
        else
            for (const entry of parent.content)
                if (entry.type == BookmarkType.DIRECTORY)
                    delete_bookmark_recursive(entry, bookmark);
    }
    function delete_bookmark(bookmark) {
        delete_bookmark_recursive(bookmarks(), bookmark);
    }
    bookmarks_1.delete_bookmark = delete_bookmark;
})(bookmarks || (bookmarks = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["874857cffaa55f5afb763c683780694879595f9e04a9821dc2f79ba2bcd83800"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["874857cffaa55f5afb763c683780694879595f9e04a9821dc2f79ba2bcd83800"] = "874857cffaa55f5afb763c683780694879595f9e04a9821dc2f79ba2bcd83800";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "ipuBojE_", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (66,30)" }, { name: "pTG6j9yu", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (71,25)" }, { name: "Eb93EkML", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (205,23)" }, { name: "tpvPsLc_", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (215,27)" }, { name: "ZduoW6jD", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (225,23)" }, { name: "oOdzj4Tz", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (248,21)" }, { name: "Rpz2mzK3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (257,21)" }, { name: "IBdkUot2", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (322,47)" }, { name: "K4gw84ks", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (327,34)" }, { name: "VaPCIhFM", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (331,48)" }, { name: "BIoXu9fv", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/chat.ts (337,35)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var ChatType;
(function (ChatType) {
    ChatType[ChatType["GENERAL"] = 0] = "GENERAL";
    ChatType[ChatType["SERVER"] = 1] = "SERVER";
    ChatType[ChatType["CHANNEL"] = 2] = "CHANNEL";
    ChatType[ChatType["CLIENT"] = 3] = "CLIENT";
})(ChatType || (ChatType = {}));
var MessageHelper;
(function (MessageHelper) {
    function htmlEscape(message) {
        const div = document.createElement('div');
        div.innerText = message;
        message = div.innerHTML;
        return message.replace(/ /g, '&nbsp;').split(/<br>/);
    }
    MessageHelper.htmlEscape = htmlEscape;
    function formatElement(object) {
        if ($.isArray(object)) {
            let result = [];
            for (let element of object)
                result.push(...this.formatElement(element));
            return result;
        }
        else if (typeof (object) == "string") {
            if (object.length == 0)
                return [];
            return this.htmlEscape(object).map((entry, idx, array) => $.spawn("a").css("display", (idx == 0 || idx + 1 == array.length ? "inline" : "") + "block").html(entry));
        }
        else if (typeof (object) === "object") {
            if (object instanceof $)
                return [object];
            return this.formatElement("<unknwon object>");
        }
        else if (typeof (object) === "function")
            return this.formatElement(object());
        else if (typeof (object) === "undefined")
            return this.formatElement("<undefined>");
        else if (typeof (object) === "number")
            return [$.spawn("a").text(object)];
        return this.formatElement("<unknown object type " + typeof object + ">");
    }
    MessageHelper.formatElement = formatElement;
    function formatMessage(pattern, ...objects) {
        let begin = 0, found = 0;
        let result = [];
        do {
            found = pattern.indexOf('{', found);
            if (found == -1 || pattern.length <= found + 1) {
                result.push(...this.formatElement(pattern.substr(begin)));
                break;
            }
            if (found > 0 && pattern[found - 1] == '\\') {
                //TODO remove the escape!
                found++;
                continue;
            }
            result.push(...this.formatElement(pattern.substr(begin, found - begin))); //Append the text
            let number;
            let offset = 0;
            while ("0123456789".includes(pattern[found + 1 + offset]))
                offset++;
            number = parseInt(offset > 0 ? pattern.substr(found + 1, offset) : "0");
            if (pattern[found + offset + 1] != '}') {
                found++;
                continue;
            }
            if (objects.length < number)
                console.warn(_translations.ipuBojE_ || (_translations.ipuBojE_ = tr("Message to format contains invalid index (%o)")), number);
            result.push(...this.formatElement(objects[number]));
            found = found + 1 + offset;
            begin = found + 1;
            console.log(_translations.pTG6j9yu || (_translations.pTG6j9yu = tr("Offset: %d Number: %d")), offset, number);
        } while (found++);
        return result;
    }
    MessageHelper.formatMessage = formatMessage;
})(MessageHelper || (MessageHelper = {}));
class ChatMessage {
    constructor(message) {
        this.date = new Date();
        this.message = message;
    }
    num(num) {
        let str = num.toString();
        while (str.length < 2)
            str = '0' + str;
        return str;
    }
    get htmlTag() {
        if (this._htmlTag)
            return this._htmlTag;
        let tag = $.spawn("div");
        tag.addClass("message");
        let dateTag = $.spawn("div");
        dateTag.text("<" + this.num(this.date.getUTCHours()) + ":" + this.num(this.date.getUTCMinutes()) + ":" + this.num(this.date.getUTCSeconds()) + "> ");
        dateTag.css("margin-right", "4px");
        dateTag.css("color", "dodgerblue");
        this._htmlTag = tag;
        tag.append(dateTag);
        this.message.forEach(e => e.appendTo(tag));
        tag.hide();
        return tag;
    }
}
class ChatEntry {
    constructor(handle, type, key) {
        this.handle = handle;
        this.type = type;
        this.key = key;
        this._name = key;
        this.history = [];
        this.onClose = function () { return true; };
    }
    appendError(message, ...args) {
        let entries = MessageHelper.formatMessage(message, ...args);
        entries.forEach(e => e.css("color", "red"));
        this.pushChatMessage(new ChatMessage(entries));
    }
    appendMessage(message, fmt = true, ...args) {
        this.pushChatMessage(new ChatMessage(MessageHelper.formatMessage(message, ...args)));
    }
    pushChatMessage(entry) {
        this.history.push(entry);
        while (this.history.length > 100) {
            let elm = this.history.pop_front();
            elm.htmlTag.animate({ opacity: 0 }, 200, function () {
                $(this).detach();
            });
        }
        if (this.handle.activeChat === this) {
            let box = $(this.handle.htmlTag).find(".messages");
            let mbox = $(this.handle.htmlTag).find(".message_box");
            let bottom = box.scrollTop() + box.height() + 1 >= mbox.height();
            mbox.append(entry.htmlTag);
            entry.htmlTag.show().css("opacity", "0").animate({ opacity: 1 }, 100);
            if (bottom)
                box.scrollTop(mbox.height());
        }
        else {
            this.unread = true;
        }
    }
    displayHistory() {
        this.unread = false;
        let box = $(this.handle.htmlTag).find(".messages");
        let mbox = $(this.handle.htmlTag).find(".message_box");
        mbox.empty();
        for (let e of this.history) {
            mbox.append(e.htmlTag);
            if (e.htmlTag.is(":hidden"))
                e.htmlTag.show();
        }
        box.scrollTop(mbox.height());
    }
    get htmlTag() {
        if (this._htmlTag)
            return this._htmlTag;
        let tag = $.spawn("div");
        tag.addClass("chat");
        tag.append("<div class=\"chatIcon icon clicon " + this.chatIcon() + "\"></div>");
        tag.append("<a class='name'>" + this._name + "</a>");
        let closeTag = $.spawn("div");
        closeTag.addClass("btn_close icon client-tab_close_button");
        if (!this._closeable)
            closeTag.hide();
        tag.append(closeTag);
        const _this = this;
        tag.click(function () {
            _this.handle.activeChat = _this;
        });
        tag.on("contextmenu", function (e) {
            e.preventDefault();
            let actions = [];
            actions.push({
                type: MenuEntryType.ENTRY,
                icon: "",
                name: _translations.Eb93EkML || (_translations.Eb93EkML = tr("Clear")),
                callback: () => {
                    _this.history = [];
                    _this.displayHistory();
                }
            });
            if (_this.closeable) {
                actions.push({
                    type: MenuEntryType.ENTRY,
                    icon: "client-tab_close_button",
                    name: _translations.tpvPsLc_ || (_translations.tpvPsLc_ = tr("Close")),
                    callback: () => {
                        chat.deleteChat(_this);
                    }
                });
            }
            actions.push({
                type: MenuEntryType.ENTRY,
                icon: "client-tab_close_button",
                name: _translations.ZduoW6jD || (_translations.ZduoW6jD = tr("Close all private tabs")),
                callback: () => {
                    //TODO Implement this?
                }
            });
            spawn_context_menu(e.pageX, e.pageY, ...actions);
        });
        closeTag.click(function () {
            if ($.isFunction(_this.onClose) && !_this.onClose())
                return;
            _this.handle.deleteChat(_this);
        });
        this._htmlTag = tag;
        return tag;
    }
    focus() {
        this.handle.activeChat = this;
        this.handle.htmlTag.find(".input_box").focus();
    }
    set name(newName) {
        console.log(_translations.oOdzj4Tz || (_translations.oOdzj4Tz = tr("Change name!")));
        this._name = newName;
        this.htmlTag.find(".name").text(this._name);
    }
    set closeable(flag) {
        if (this._closeable == flag)
            return;
        this._closeable = flag;
        console.log((_translations.Rpz2mzK3 || (_translations.Rpz2mzK3 = tr("Set closeable: "))) + this._closeable);
        if (flag)
            this.htmlTag.find(".btn_close").show();
        else
            this.htmlTag.find(".btn_close").hide();
    }
    set unread(flag) {
        if (this._unread == flag)
            return;
        this._unread = flag;
        this.htmlTag.find(".chatIcon").attr("class", "chatIcon icon clicon " + this.chatIcon());
        if (flag) {
            this.htmlTag.find(".name").css("color", "blue");
        }
        else {
            this.htmlTag.find(".name").css("color", "black");
        }
    }
    chatIcon() {
        if (this._unread) {
            switch (this.type) {
                case ChatType.CLIENT:
                    return "client-new_chat";
            }
        }
        switch (this.type) {
            case ChatType.SERVER:
                return "client-server_log";
            case ChatType.CHANNEL:
                return "client-channel_chat";
            case ChatType.CLIENT:
                return "client-player_chat";
            case ChatType.GENERAL:
                return "client-channel_chat";
        }
        return "";
    }
}
class ChatBox {
    constructor(htmlTag) {
        this.htmlTag = htmlTag;
        this.htmlTag.find(".input button").click(this.onSend.bind(this));
        this.htmlTag.find(".input_box").keypress(event => {
            if (event.keyCode == 13 /* Enter */ && !event.shiftKey) {
                this.onSend();
                return false;
            }
        }).on('input', (event) => {
            let text = $(event.target).val().toString();
            if (this.testMessage(text))
                this.htmlTag.find(".input button").removeAttr("disabled");
            else
                this.htmlTag.find(".input button").attr("disabled", "true");
        }).trigger("input");
        this.chats = [];
        this._activeChat = undefined;
        this.createChat("chat_server", ChatType.SERVER).onMessageSend = (text) => {
            if (!globalClient.serverConnection) {
                chat.serverChat().appendError(_translations.IBdkUot2 || (_translations.IBdkUot2 = tr("Could not send chant message (Not connected)")));
                return;
            }
            globalClient.serverConnection.sendMessage(text, ChatType.SERVER);
        };
        this.serverChat().name = _translations.K4gw84ks || (_translations.K4gw84ks = tr("Server chat"));
        this.createChat("chat_channel", ChatType.CHANNEL).onMessageSend = (text) => {
            if (!globalClient.serverConnection) {
                chat.channelChat().appendError(_translations.VaPCIhFM || (_translations.VaPCIhFM = tr("Could not send chant message (Not connected)")));
                return;
            }
            globalClient.serverConnection.sendMessage(text, ChatType.CHANNEL, globalClient.getClient().currentChannel());
        };
        this.channelChat().name = _translations.BIoXu9fv || (_translations.BIoXu9fv = tr("Channel chat"));
        globalClient.permissions.initializedListener.push(flag => {
            if (flag)
                this.activeChat0(this._activeChat);
        });
    }
    createChat(key, type = ChatType.CLIENT) {
        let chat = new ChatEntry(this, type, key);
        this.chats.push(chat);
        this.htmlTag.find(".chats").append(chat.htmlTag);
        if (!this._activeChat)
            this.activeChat = chat;
        return chat;
    }
    findChat(key) {
        for (let e of this.chats)
            if (e.key == key)
                return e;
        return undefined;
    }
    deleteChat(chat) {
        this.chats.remove(chat);
        chat.htmlTag.detach();
        if (this._activeChat === chat) {
            if (this.chats.length > 0)
                this.activeChat = this.chats.last();
            else
                this.activeChat = undefined;
        }
    }
    onSend() {
        let textBox = $(this.htmlTag).find(".input_box");
        let text = textBox.val().toString();
        if (!this.testMessage(text))
            return;
        textBox.val("");
        $(this.htmlTag).find(".input_box").trigger("input");
        if (this._activeChat && $.isFunction(this._activeChat.onMessageSend))
            this._activeChat.onMessageSend(text);
    }
    set activeChat(chat) {
        if (this.chats.indexOf(chat) === -1)
            return;
        if (this._activeChat == chat)
            return;
        this.activeChat0(chat);
    }
    activeChat0(chat) {
        this._activeChat = chat;
        for (let e of this.chats)
            e.htmlTag.removeClass("active");
        let flagAllowSend = false;
        if (this._activeChat) {
            this._activeChat.htmlTag.addClass("active");
            this._activeChat.displayHistory();
            if (globalClient && globalClient.permissions && globalClient.permissions.initialized())
                switch (this._activeChat.type) {
                    case ChatType.CLIENT:
                        flagAllowSend = true;
                        break;
                    case ChatType.SERVER:
                        flagAllowSend = globalClient.permissions.neededPermission(PermissionType.B_CLIENT_SERVER_TEXTMESSAGE_SEND).granted(1);
                        break;
                    case ChatType.CHANNEL:
                        flagAllowSend = globalClient.permissions.neededPermission(PermissionType.B_CLIENT_CHANNEL_TEXTMESSAGE_SEND).granted(1);
                        break;
                }
        }
        this.htmlTag.find(".input_box").prop("disabled", !flagAllowSend);
    }
    get activeChat() { return this._activeChat; }
    channelChat() {
        return this.findChat("chat_channel");
    }
    serverChat() {
        return this.findChat("chat_server");
    }
    focus() {
        $(this.htmlTag).find(".input_box").focus();
    }
    testMessage(message) {
        message = message
            .replace(/ /gi, "")
            .replace(/<br>/gi, "")
            .replace(/\n/gi, "")
            .replace(/<br\/>/gi, "");
        return message.length > 0;
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["f0bd442b0098029c3098b4df4ae01fb0c887231bc9c12ae2614d8894a14ad23f"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["f0bd442b0098029c3098b4df4ae01fb0c887231bc9c12ae2614d8894a14ad23f"] = "f0bd442b0098029c3098b4df4ae01fb0c887231bc9c12ae2614d8894a14ad23f";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "Au_w1ruv", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalConnect.ts (9,29)" }, { name: "pZK8rjVz", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalConnect.ts (114,29)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
var Modals;
(function (Modals) {
    function spawnConnectModal(defaultHost = { url: "ts.TeaSpeak.de", enforce: false }, connect_profile) {
        let selected_profile;
        const connectModal = createModal({
            header: function () {
                let header = $.spawn("div");
                header.text(_translations.Au_w1ruv || (_translations.Au_w1ruv = tr("Create a new connection")));
                return header;
            },
            body: function () {
                let tag = $("#tmpl_connect").renderTag({
                    client: native_client,
                    forum_path: settings.static("forum_path")
                });
                let updateFields = function () {
                    if (selected_profile)
                        tag.find(".connect_nickname").attr("placeholder", selected_profile.default_username);
                    else
                        tag.find(".connect_nickname").attr("");
                    let button = tag.parents(".modal-content").find(".connect_connect_button");
                    let field_address = tag.find(".connect_address");
                    let address = field_address.val().toString();
                    settings.changeGlobal("connect_address", address);
                    let flag_address = !!address.match(Regex.IP_V4) || !!address.match(Regex.DOMAIN);
                    let field_nickname = tag.find(".connect_nickname");
                    let nickname = field_nickname.val().toString();
                    settings.changeGlobal("connect_name", nickname);
                    let flag_nickname = (nickname.length == 0 && selected_profile && selected_profile.default_username.length > 0) || nickname.length >= 3 && nickname.length <= 32;
                    if (flag_address) {
                        if (field_address.hasClass("invalid_input"))
                            field_address.removeClass("invalid_input");
                    }
                    else {
                        if (!field_address.hasClass("invalid_input"))
                            field_address.addClass("invalid_input");
                    }
                    if (flag_nickname) {
                        if (field_nickname.hasClass("invalid_input"))
                            field_nickname.removeClass("invalid_input");
                    }
                    else {
                        if (!field_nickname.hasClass("invalid_input"))
                            field_nickname.addClass("invalid_input");
                    }
                    if (!flag_nickname || !flag_address || !selected_profile || !selected_profile.valid()) {
                        button.prop("disabled", true);
                    }
                    else {
                        button.prop("disabled", false);
                    }
                };
                tag.find(".connect_nickname").val(settings.static_global("connect_name", undefined));
                tag.find(".connect_address").val(defaultHost.enforce ? defaultHost.url : settings.static_global("connect_address", defaultHost.url));
                tag.find(".connect_address")
                    .on("keyup", () => updateFields())
                    .on('keydown', event => {
                    if (event.keyCode == 13 /* Enter */ && !event.shiftKey)
                        tag.parents(".modal-content").find(".connect_connect_button").trigger('click');
                });
                tag.find(".button-manage-profiles").on('click', event => {
                    const modal = Modals.spawnSettingsModal();
                    setTimeout(() => {
                        modal.htmlTag.find(".tab-profiles").parent(".entry").trigger('click');
                    }, 100);
                    modal.close_listener.push(() => {
                        tag.find(".profile-select-container select").trigger('change');
                    });
                    return true;
                });
                {
                    const select_tag = tag.find(".profile-select-container select");
                    const select_invalid_tag = tag.find(".profile-invalid");
                    for (const profile of profiles.profiles()) {
                        select_tag.append($.spawn("option").text(profile.profile_name).val(profile.id));
                    }
                    select_tag.on('change', event => {
                        selected_profile = profiles.find_profile(select_tag.val());
                        if (!selected_profile || !selected_profile.valid())
                            select_invalid_tag.show();
                        else
                            select_invalid_tag.hide();
                        updateFields();
                    });
                    select_tag.val('default').trigger('change');
                }
                tag.find(".connect_nickname").on("keyup", () => updateFields());
                setTimeout(() => updateFields(), 100);
                //connect_address
                return tag;
            },
            footer: function () {
                let tag = $.spawn("div");
                tag.css("text-align", "right");
                tag.css("margin-top", "3px");
                tag.css("margin-bottom", "6px");
                tag.addClass("modal-button-group");
                let button = $.spawn("button");
                button.addClass("connect_connect_button");
                button.text(_translations.pZK8rjVz || (_translations.pZK8rjVz = tr("Connect")));
                button.on("click", function () {
                    connectModal.close();
                    let field_address = tag.parents(".modal-content").find(".connect_address");
                    let address = field_address.val().toString();
                    globalClient.startConnection(address, selected_profile, tag.parents(".modal-content").find(".connect_nickname").val().toString() || selected_profile.default_username, { password: tag.parents(".modal-content").find(".connect_password").val().toString(), hashed: false });
                });
                tag.append(button);
                return tag;
            },
            width: '70%',
        });
        connectModal.open();
    }
    Modals.spawnConnectModal = spawnConnectModal;
    let Regex = {
        //DOMAIN<:port>
        DOMAIN: /^(localhost|((([a-zA-Z0-9_-]{0,63}\.){0,253})?[a-zA-Z0-9_-]{0,63}\.[a-zA-Z]{2,5}))(|:(6553[0-5]|655[0-2][0-9]|65[0-4][0-9]{2}|6[0-4][0-9]{3}|[0-5]?[0-9]{1,4}))$/,
        //IP<:port>
        IP_V4: /(^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))(|:(6553[0-5]|655[0-2][0-9]|65[0-4][0-9]{2}|6[0-4][0-9]{3}|[0-5]?[0-9]{1,4}))$/,
        IP_V6: /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/,
        IP: /^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$|^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$|^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/,
    };
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["5bde1b8db0fb249c21e2adbdb131422042b45adc79554dbb3330be6821f75d15"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["5bde1b8db0fb249c21e2adbdb131422042b45adc79554dbb3330be6821f75d15"] = "5bde1b8db0fb249c21e2adbdb131422042b45adc79554dbb3330be6821f75d15";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "AcdibmW5", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanCreate.ts (8,46)" }, { name: "FKVkKpuf", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanCreate.ts (8,63)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var Modals;
(function (Modals) {
    function spawnBanCreate(base, callback) {
        let result = {};
        result.banid = base ? base.banid : 0;
        let modal;
        modal = createModal({
            header: base && base.banid > 0 ? _translations.AcdibmW5 || (_translations.AcdibmW5 = tr("Edit ban")) : _translations.FKVkKpuf || (_translations.FKVkKpuf = tr("Add ban")),
            body: () => {
                let template = $("#tmpl_ban_create").renderTag();
                template = $.spawn("div").append(template);
                const input_name = template.find(".input-name");
                const input_name_type = template.find(".input-name-type");
                const input_ip = template.find(".input-ip");
                const input_uid = template.find(".input-uid");
                const input_reason = template.find(".input-reason");
                const input_time = template.find(".input-time");
                const input_time_type = template.find(".input-time-unit");
                const input_hwid = template.find(".input-hwid");
                const input_global = template.find(".input-global");
                {
                    let maxTime = 0; //globalClient.permissions.neededPermission(PermissionType.I_CLIENT_BAN_MAX_BANTIME).value;
                    let unlimited = maxTime == 0 || maxTime == -1;
                    if (unlimited)
                        maxTime = 0;
                    input_time_type.find("option[value=\"sec\"]").prop("disabled", !unlimited && 1 > maxTime)
                        .attr("duration-scale", 1)
                        .attr("duration-max", maxTime);
                    input_time_type.find("option[value=\"min\"]").prop("disabled", !unlimited && 60 > maxTime)
                        .attr("duration-scale", 60)
                        .attr("duration-max", maxTime / 60);
                    input_time_type.find("option[value=\"hours\"]").prop("disabled", !unlimited && 60 * 60 > maxTime)
                        .attr("duration-scale", 60 * 60)
                        .attr("duration-max", maxTime / (60 * 60));
                    input_time_type.find("option[value=\"days\"]").prop("disabled", !unlimited && 60 * 60 * 24 > maxTime)
                        .attr("duration-scale", 60 * 60 * 24)
                        .attr("duration-max", maxTime / (60 * 60 * 24));
                    input_time_type.find("option[value=\"perm\"]").prop("disabled", !unlimited)
                        .attr("duration-scale", 0);
                    input_time_type.change(event => {
                        let element = $(event.target.selectedOptions.item(0));
                        if (element.val() !== "perm") {
                            input_time.prop("disabled", false);
                            let current = input_time.val();
                            let max = parseInt(element.attr("duration-max"));
                            if (max > 0 && current > max)
                                input_time.val(max);
                            else if (current <= 0)
                                input_time.val(1);
                            input_time.attr("max", max);
                        }
                        else {
                            input_time.prop("disabled", true);
                        }
                    });
                }
                template.find('input, textarea').on('keyup change', event => {
                    let valid = false;
                    if (input_name.val() || input_ip.val() || input_uid.val())
                        valid = true;
                    modal.htmlTag.find(".button-success").prop("disabled", !valid);
                });
                if (base) {
                    input_ip.val(base.ip);
                    input_uid.val(base.unique_id);
                    input_name.val(base.name);
                    input_hwid.val(base.hardware_id);
                    input_name_type[0].selectedIndex = base.name_type || 0;
                    input_reason.val(base.reason);
                    if (base.timestamp_expire.getTime() == 0) {
                        input_time_type.find("option[value=\"perm\"]").prop("selected", true);
                    }
                    else {
                        const time = (base.timestamp_expire.getTime() - base.timestamp_created.getTime()) / 1000;
                        if (time % (60 * 60 * 24) === 0) {
                            input_time_type.find("option[value=\"days\"]").prop("selected", true);
                            input_time.val(time / (60 * 60 * 24));
                        }
                        else if (time % (60 * 60) === 0) {
                            input_time_type.find("option[value=\"hours\"]").prop("selected", true);
                            input_time.val(time / (60 * 60));
                        }
                        else if (time % (60) === 0) {
                            input_time_type.find("option[value=\"min\"]").prop("selected", true);
                            input_time.val(time / (60));
                        }
                        else {
                            input_time_type.find("option[value=\"sec\"]").prop("selected", true);
                            input_time.val(time);
                        }
                    }
                    template.find(".container-global").detach(); //We cant edit this
                    input_global.prop("checked", base.server_id == 0);
                }
                if (globalClient && globalClient.permissions)
                    input_global.prop("disabled", !globalClient.permissions.neededPermission(base ? PermissionType.B_CLIENT_BAN_EDIT_GLOBAL : PermissionType.B_CLIENT_BAN_CREATE_GLOBAL));
                return template;
            },
            footer: undefined
        });
        modal.htmlTag.find(".button-close").on('click', () => modal.close());
        modal.htmlTag.find(".button-success").on('click', () => {
            {
                let length = modal.htmlTag.find(".input-time").val();
                let duration = modal.htmlTag.find(".input-time-unit option:selected");
                console.log(duration);
                console.log(length + "*" + duration.attr("duration-scale"));
                const time = length * parseInt(duration.attr("duration-scale"));
                if (!result.timestamp_created)
                    result.timestamp_created = new Date();
                if (time > 0)
                    result.timestamp_expire = new Date(result.timestamp_created.getTime() + time * 1000);
                else
                    result.timestamp_expire = new Date(0);
            }
            {
                result.name = modal.htmlTag.find(".input-name").val();
                {
                    const name_type = modal.htmlTag.find(".input-name-type");
                    result.name_type = name_type[0].selectedIndex;
                }
                result.ip = modal.htmlTag.find(".input-ip").val();
                result.unique_id = modal.htmlTag.find(".input-uid").val();
                result.reason = modal.htmlTag.find(".input-reason").val();
                result.hardware_id = modal.htmlTag.find(".input-hwid").val();
                result.server_id = modal.htmlTag.find(".input-global").prop("checked") ? 0 : -1;
            }
            modal.close();
            if (callback)
                callback(result);
        });
        modal.htmlTag.find("input").trigger("change");
        modal.open();
    }
    Modals.spawnBanCreate = spawnBanCreate;
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["26225d6a421493c1933d632d9896c171314d7478366c0c1644f9c162983636c7"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["26225d6a421493c1933d632d9896c171314d7478366c0c1644f9c162983636c7"] = "26225d6a421493c1933d632d9896c171314d7478366c0c1644f9c162983636c7";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "LjlgyLaw", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBanClient.ts (15,24)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
/// <reference path="../../proto.ts" />
/// <reference path="../../client.ts" />
var Modals;
(function (Modals) {
    function spawnBanClient(name, callback) {
        const connectModal = createModal({
            header: function () {
                return _translations.LjlgyLaw || (_translations.LjlgyLaw = tr("Ban client"));
            },
            body: function () {
                let tag = $("#tmpl_client_ban").renderTag({
                    client_name: $.isArray(name) ? '"' + name.join('", "') + '"' : name
                });
                let maxTime = 0; //globalClient.permissions.neededPermission(PermissionType.I_CLIENT_BAN_MAX_BANTIME).value;
                let unlimited = maxTime == 0 || maxTime == -1;
                if (unlimited)
                    maxTime = 0;
                let banTag = tag.find(".ban_duration_type");
                let durationTag = tag.find(".ban_duration");
                banTag.find("option[value=\"sec\"]").prop("disabled", !unlimited && 1 > maxTime)
                    .attr("duration-scale", 1)
                    .attr("duration-max", maxTime);
                banTag.find("option[value=\"min\"]").prop("disabled", !unlimited && 60 > maxTime)
                    .attr("duration-scale", 60)
                    .attr("duration-max", maxTime / 60);
                banTag.find("option[value=\"hours\"]").prop("disabled", !unlimited && 60 * 60 > maxTime)
                    .attr("duration-scale", 60 * 60)
                    .attr("duration-max", maxTime / (60 * 60));
                banTag.find("option[value=\"days\"]").prop("disabled", !unlimited && 60 * 60 * 24 > maxTime)
                    .attr("duration-scale", 60 * 60 * 24)
                    .attr("duration-max", maxTime / (60 * 60 * 24));
                banTag.find("option[value=\"perm\"]").prop("disabled", !unlimited)
                    .attr("duration-scale", 0);
                durationTag.change(() => banTag.trigger('change'));
                banTag.change(event => {
                    let element = $(event.target.selectedOptions.item(0));
                    if (element.val() !== "perm") {
                        durationTag.prop("disabled", false);
                        let current = durationTag.val();
                        let max = parseInt(element.attr("duration-max"));
                        if (max > 0 && current > max)
                            durationTag.val(max);
                        else if (current <= 0)
                            durationTag.val(1);
                        durationTag.attr("max", max);
                    }
                    else {
                        durationTag.prop("disabled", true);
                    }
                });
                return tag;
            },
            footer: function () {
                let tag = $.spawn("div");
                tag.css("text-align", "right");
                tag.css("margin-top", "3px");
                tag.css("margin-bottom", "6px");
                tag.addClass("modal-button-group");
                let buttonCancel = $.spawn("button");
                buttonCancel.text("Cancel");
                buttonCancel.on("click", () => connectModal.close());
                tag.append(buttonCancel);
                let buttonOk = $.spawn("button");
                buttonOk.text("OK").addClass("btn_success");
                tag.append(buttonOk);
                return tag;
            },
            width: 450
        });
        connectModal.open();
        connectModal.htmlTag.find(".btn_success").on('click', () => {
            connectModal.close();
            let length = connectModal.htmlTag.find(".ban_duration").val();
            let duration = connectModal.htmlTag.find(".ban_duration_type option:selected");
            console.log(duration);
            console.log(length + "*" + duration.attr("duration-scale"));
            callback({
                length: length * parseInt(duration.attr("duration-scale")),
                reason: connectModal.htmlTag.find(".ban_reason").val(),
                no_hwid: !connectModal.htmlTag.find(".ban-type-hardware-id").prop("checked"),
                no_ip: !connectModal.htmlTag.find(".ban-type-ip").prop("checked"),
                no_name: !connectModal.htmlTag.find(".ban-type-nickname").prop("checked")
            });
        });
    }
    Modals.spawnBanClient = spawnBanClient;
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["4a704dab654fb6b2c83d339937a7b8c7669dba197ea736171ea62bdc7cbe5363"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["4a704dab654fb6b2c83d339937a7b8c7669dba197ea736171ea62bdc7cbe5363"] = "4a704dab654fb6b2c83d339937a7b8c7669dba197ea736171ea62bdc7cbe5363";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "gDQJdtGS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalYesNo.ts (17,33)" }, { name: "uRnvlMN6", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalYesNo.ts (25,32)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
var Modals;
(function (Modals) {
    function spawnYesNo(header, body, callback) {
        let modal;
        modal = createModal({
            header: header,
            body: body,
            footer: () => {
                let footer = $.spawn("div");
                footer.addClass("modal-button-group");
                footer.css("margin-top", "5px");
                footer.css("margin-bottom", "5px");
                footer.css("text-align", "right");
                let button_yes = $.spawn("button");
                button_yes.text(_translations.gDQJdtGS || (_translations.gDQJdtGS = tr("Yes")));
                button_yes.click(() => {
                    modal.close();
                    callback(true);
                });
                footer.append(button_yes);
                let button_no = $.spawn("button");
                button_no.text(_translations.uRnvlMN6 || (_translations.uRnvlMN6 = tr("No")));
                button_no.click(() => {
                    modal.close();
                    callback(false);
                });
                footer.append(button_no);
                return footer;
            },
            width: 750
        });
        modal.open();
    }
    Modals.spawnYesNo = spawnYesNo;
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["fc454c4a9de91904b521c83be818a8ddc34d38907a15bb2d379f50fe2e9d0250"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["fc454c4a9de91904b521c83be818a8ddc34d38907a15bb2d379f50fe2e9d0250"] = "fc454c4a9de91904b521c83be818a8ddc34d38907a15bb2d379f50fe2e9d0250";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "NIRDKZ3W", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/main.ts (105,23)" }, { name: "bIxAbbQU", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/main.ts (114,28)" }, { name: "A6SjaTBL", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/main.ts (115,23)" }, { name: "C9X7UG7p", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/main.ts (124,28)" }, { name: "ZMdeQSBL", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/main.ts (130,23)" }, { name: "ngLOzVp_", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/main.ts (138,23)" }, { name: "mU6CyCKt", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/main.ts (139,30)" }, { name: "SzKKKmFx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/main.ts (216,45)" }, { name: "KWXL5b7R", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/main.ts (218,35)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="chat.ts" />
/// <reference path="client.ts" />
/// <reference path="utils/modal.ts" />
/// <reference path="ui/modal/ModalConnect.ts" />
/// <reference path="ui/modal/ModalCreateChannel.ts" />
/// <reference path="ui/modal/ModalBanCreate.ts" />
/// <reference path="ui/modal/ModalBanClient.ts" />
/// <reference path="ui/modal/ModalYesNo.ts" />
/// <reference path="ui/modal/ModalBanList.ts" />
/// <reference path="settings.ts" />
/// <reference path="log.ts" />
let settings;
let globalClient;
let chat;
const js_render = window.jsrender || $;
const native_client = window.require !== undefined;
function getUserMediaFunction() {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia)
        return (settings, success, fail) => { navigator.mediaDevices.getUserMedia(settings).then(success).catch(fail); };
    return navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;
}
function setup_close() {
    window.onbeforeunload = event => {
        if (profiles.requires_save())
            profiles.save();
        if (!settings.static(Settings.KEY_DISABLE_UNLOAD_DIALOG, false)) {
            if (!globalClient.serverConnection || !globalClient.serverConnection.connected)
                return;
            if (!native_client) {
                event.returnValue = "Are you really sure?<br>You're still connected!";
            }
            else {
                event.preventDefault();
                event.returnValue = "question";
                const { remote } = require('electron');
                const dialog = remote.dialog;
                dialog.showMessageBox(remote.getCurrentWindow(), {
                    type: 'question',
                    buttons: ['Yes', 'No'],
                    title: 'Confirm',
                    message: 'Are you really sure?\nYou\'re still connected!'
                }, choice => {
                    if (choice === 0) {
                        window.onbeforeunload = undefined;
                        remote.getCurrentWindow().close();
                    }
                });
            }
        }
    };
}
function setup_jsrender() {
    if (!js_render) {
        displayCriticalError("Missing jsrender extension!");
        return false;
    }
    if (!js_render.views) {
        displayCriticalError("Missing jsrender viewer extension!");
        return false;
    }
    js_render.views.settings.allowCode(true);
    js_render.views.tags("rnd", (argument) => {
        let min = parseInt(argument.substr(0, argument.indexOf('~')));
        let max = parseInt(argument.substr(argument.indexOf('~') + 1));
        return (Math.round(Math.random() * (min + max + 1) - min)).toString();
    });
    js_render.views.tags("fmt_date", (...arguments) => {
        return moment(arguments[0]).format(arguments[1]);
    });
    js_render.views.tags("tr", (...arguments) => {
        return tr(arguments[0]);
    });
    $(".jsrender-template").each((idx, _entry) => {
        if (!js_render.templates(_entry.id, _entry.innerHTML)) { //, _entry.innerHTML
            console.error("Failed to cache template " + _entry.id + " for js render!");
        }
        else
            console.debug("Successfully loaded jsrender template " + _entry.id);
    });
    return true;
}
function initialize() {
    return __awaiter(this, void 0, void 0, function* () {
        const display_load_error = message => {
            if (typeof (display_critical_load) !== "undefined")
                display_critical_load(message);
            else
                displayCriticalError(message);
        };
        try {
            yield i18n.initialize();
        }
        catch (error) {
            console.error(_translations.NIRDKZ3W || (_translations.NIRDKZ3W = tr("Failed to initialized the translation system!\nError: %o")), error);
            displayCriticalError("Failed to setup the translation system");
            return;
        }
        try {
            if (!setup_jsrender())
                throw "invalid load";
        }
        catch (error) {
            display_load_error(_translations.bIxAbbQU || (_translations.bIxAbbQU = tr("Failed to setup jsrender")));
            console.error(_translations.A6SjaTBL || (_translations.A6SjaTBL = tr("Failed to load jsrender! %o")), error);
            return;
        }
        try { //Initialize main template
            const main = $("#tmpl_main").renderTag();
            $("body").append(main);
        }
        catch (error) {
            console.error(error);
            display_load_error(_translations.C9X7UG7p || (_translations.C9X7UG7p = tr("Failed to setup main page!")));
            return;
        }
        AudioController.initializeAudioController();
        if (!profiles.identities.setup_teamspeak()) {
            console.error(_translations.ZMdeQSBL || (_translations.ZMdeQSBL = tr("Could not setup the TeamSpeak identity parser!")));
            return;
        }
        profiles.load();
        try {
            yield ppt.initialize();
        }
        catch (error) {
            console.error(_translations.ngLOzVp_ || (_translations.ngLOzVp_ = tr("Failed to initialize ppt!\nError: %o")), error);
            displayCriticalError(_translations.mU6CyCKt || (_translations.mU6CyCKt = tr("Failed to initialize ppt!")));
            return;
        }
    });
}
function main() {
    //http://localhost:63343/Web-Client/index.php?_ijt=omcpmt8b9hnjlfguh8ajgrgolr&default_connect_url=true&default_connect_type=teamspeak&default_connect_url=localhost%3A9987&disableUnloadDialog=1&loader_ignore_age=1
    settings = new Settings();
    globalClient = new TSClient();
    /** Setup the XF forum identity **/
    profiles.identities.setup_forum();
    chat = new ChatBox($("#chat"));
    globalClient.setup();
    if (!settings.static(Settings.KEY_DISABLE_UNLOAD_DIALOG, false) && !native_client) {
    }
    //Modals.spawnConnectModal();
    //Modals.spawnSettingsModal();
    //Modals.createChannelModal(undefined);
    if (settings.static("connect_default") && settings.static("connect_address", "")) {
        const profile_uuid = settings.static("connect_profile");
        const profile = profiles.find_profile(profile_uuid) || profiles.default_profile();
        const address = settings.static("connect_address", "");
        const username = settings.static("connect_username", "Another TeaSpeak user");
        if (profile.valid()) {
            globalClient.startConnection(address, profile, username);
        }
        else {
            Modals.spawnConnectModal({
                url: address,
                enforce: true
            }, {
                profile: profile,
                enforce: true
            });
        }
    }
    /*
    let tag = $("#tmpl_music_frame").renderTag({
        //thumbnail: "img/loading_image.svg"
    });



    $("#music-test").replaceWith(tag);

    Modals.spawnSettingsModal();
    /*
    Modals.spawnYesNo("Are your sure?", "Do you really want to exit?", flag => {
        console.log("Response: " + flag);
    })
    */
    setup_close();
    let _resize_timeout;
    $(window).on('resize', () => {
        if (_resize_timeout)
            clearTimeout(_resize_timeout);
        _resize_timeout = setTimeout(() => {
            globalClient.channelTree.handle_resized();
        }, 1000);
    });
}
loader.register_task(loader.Stage.LOADED, {
    name: "async main invoke",
    function: () => __awaiter(this, void 0, void 0, function* () {
        try {
            yield initialize();
            main();
            if (!audio.player.initialized()) {
                log.info(LogCategory.VOICE, _translations.SzKKKmFx || (_translations.SzKKKmFx = tr("Initialize audio controller later!")));
                if (!audio.player.initializeFromGesture) {
                    console.error(_translations.KWXL5b7R || (_translations.KWXL5b7R = tr("Missing audio.player.initializeFromGesture")));
                }
                else
                    $(document).one('click', event => audio.player.initializeFromGesture());
            }
        }
        catch (ex) {
            console.error(ex.stack);
            if (ex instanceof ReferenceError || ex instanceof TypeError)
                ex = ex.name + ": " + ex.message;
            displayCriticalError("Failed to invoke main function:<br>" + ex);
        }
    }),
    priority: 10
});
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["061aa0bfefcb4170b60204ea48c614555e680a8dfdac14a66fb351c3d6262b8b"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["061aa0bfefcb4170b60204ea48c614555e680a8dfdac14a66fb351c3d6262b8b"] = "061aa0bfefcb4170b60204ea48c614555e680a8dfdac14a66fb351c3d6262b8b";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "zQGr_osl", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/codec/BasicCodec.ts (52,74)" }, { name: "ckbPUQaR", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/codec/BasicCodec.ts (53,101)" }, { name: "sxUjsiAR", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/codec/BasicCodec.ts (77,39)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="Codec.ts"/>
class AVGCalculator {
    constructor() {
        this.history_size = 100;
        this.history = [];
    }
    push(entry) {
        while (this.history.length > this.history_size)
            this.history.pop();
        this.history.unshift(entry);
    }
    avg() {
        let count = 0;
        for (let entry of this.history)
            count += entry;
        return count / this.history.length;
    }
}
class BasicCodec {
    constructor(codecSampleRate) {
        this._latenz = new AVGCalculator();
        this.on_encoded_data = $ => { };
        this.channelCount = 1;
        this.samplesPerUnit = 960;
        this.channelCount = 1;
        this.samplesPerUnit = 960;
        this._audioContext = new (window.webkitOfflineAudioContext || window.OfflineAudioContext)(audio.player.destination().channelCount, 1024, audio.player.context().sampleRate);
        this._codecSampleRate = codecSampleRate;
        this._decodeResampler = new AudioResampler(audio.player.context().sampleRate);
        this._encodeResampler = new AudioResampler(codecSampleRate);
    }
    encodeSamples(cache, pcm) {
        this._encodeResampler.resample(pcm).catch(error => console.error(_translations.zQGr_osl || (_translations.zQGr_osl = tr("Could not resample PCM data for codec. Error: %o")), error))
            .then(buffer => this.encodeSamples0(cache, buffer)).catch(error => console.error(_translations.ckbPUQaR || (_translations.ckbPUQaR = tr("Could not encode PCM data for codec. Error: %o")), error));
    }
    encodeSamples0(cache, buffer) {
        cache._chunks.push(new BufferChunk(buffer)); //TODO multi channel!
        while (cache.bufferedSamples(this.samplesPerUnit) >= this.samplesPerUnit) {
            let buffer = this._audioContext.createBuffer(this.channelCount, this.samplesPerUnit, this._codecSampleRate);
            let index = 0;
            while (index < this.samplesPerUnit) {
                let buf = cache._chunks[0];
                let cpyBytes = buf.copyRangeTo(buffer, this.samplesPerUnit - index, index);
                index += cpyBytes;
                buf.index += cpyBytes;
                if (buf.index == buf.buffer.length)
                    cache._chunks.pop_front();
            }
            let encodeBegin = Date.now();
            this.encode(buffer).then(result => {
                if (result instanceof Uint8Array) {
                    let time = Date.now() - encodeBegin;
                    if (time > 20)
                        console.error(_translations.sxUjsiAR || (_translations.sxUjsiAR = tr("Required time: %d")), time);
                    //if(time > 20)
                    //   chat.serverChat().appendMessage("Required decode time: " + time);
                    this.on_encoded_data(result);
                }
                else
                    console.error("[Codec][" + this.name() + "] Could not encode buffer. Result: " + result); //TODO tr
            });
        }
        return true;
    }
    decodeSamples(cache, data) {
        return this.decode(data).then(buffer => this._decodeResampler.resample(buffer));
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["9a7104c0ca9159bdeb87a850e4d0b91a88482e8c991a17f5ffac526f8d318cb3"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["9a7104c0ca9159bdeb87a850e4d0b91a88482e8c991a17f5ffac526f8d318cb3"] = "9a7104c0ca9159bdeb87a850e4d0b91a88482e8c991a17f5ffac526f8d318cb3";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="BasicCodec.ts"/>
class CodecWrapperRaw extends BasicCodec {
    constructor(codecSampleRate) {
        super(codecSampleRate);
        this.bufferSize = 4096 * 4;
    }
    name() {
        return "raw";
    }
    initialise() {
        this.converterRaw = Module._malloc(this.bufferSize);
        this.converter = new Uint8Array(Module.HEAPU8.buffer, this.converterRaw, this.bufferSize);
        return new Promise(resolve => resolve());
    }
    initialized() {
        return true;
    }
    deinitialise() { }
    decode(data) {
        return new Promise((resolve, reject) => {
            this.converter.set(data);
            let buf = Module.HEAPF32.slice(this.converter.byteOffset / 4, (this.converter.byteOffset / 4) + data.length / 4);
            let audioBuf = this._audioContext.createBuffer(1, data.length / 4, this._codecSampleRate);
            audioBuf.copyToChannel(buf, 0);
            resolve(audioBuf);
        });
    }
    encode(data) {
        return new Promise(resolve => resolve(new Uint8Array(data.getChannelData(0))));
    }
    reset() { return true; }
    processLatency() {
        return 0;
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["876b55be4e38702826e98ce065784676479f036ca30573875dbb3e081052cc09"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["876b55be4e38702826e98ce065784676479f036ca30573875dbb3e081052cc09"] = "876b55be4e38702826e98ce065784676479f036ca30573875dbb3e081052cc09";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "eJCgX4T4", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/codec/CodecWrapperWorker.ts (156,26)" }, { name: "pxLg_xQs", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/codec/CodecWrapperWorker.ts (158,27)" }, { name: "PoQEbaUA", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/codec/CodecWrapperWorker.ts (164,29)" }, { name: "_4DfWuV_", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/codec/CodecWrapperWorker.ts (179,25)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="BasicCodec.ts"/>
class CodecWrapperWorker extends BasicCodec {
    constructor(type) {
        super(48000);
        this._workerListener = [];
        this._workerCallbackToken = "callback_token";
        this._workerTokeIndex = 0;
        this._initialized = false;
        this.type = type;
        switch (type) {
            case CodecType.OPUS_MUSIC:
                this.channelCount = 2;
                break;
            case CodecType.OPUS_VOICE:
                this.channelCount = 1;
                break;
            default:
                throw "invalid codec type!";
        }
    }
    name() {
        return "Worker for " + CodecType[this.type] + " Channels " + this.channelCount;
    }
    initialise() {
        if (this._initializePromise)
            return this._initializePromise;
        return this._initializePromise = this.spawnWorker().then(() => new Promise((resolve, reject) => {
            const token = this.generateToken();
            this.sendWorkerMessage({
                command: "initialise",
                type: this.type,
                channelCount: this.channelCount,
                token: token
            });
            this._workerListener.push({
                token: token,
                resolve: data => {
                    this._initialized = data["success"] == true;
                    if (data["success"] == true)
                        resolve();
                    else
                        reject(data.message);
                }
            });
        }));
    }
    initialized() {
        return this._initialized;
    }
    deinitialise() {
        this.sendWorkerMessage({
            command: "deinitialise"
        });
    }
    decode(data) {
        let token = this.generateToken();
        let result = new Promise((resolve, reject) => {
            this._workerListener.push({
                token: token,
                resolve: (data) => {
                    if (data.success) {
                        let array = new Float32Array(data.dataLength);
                        for (let index = 0; index < array.length; index++)
                            array[index] = data.data[index];
                        let audioBuf = this._audioContext.createBuffer(this.channelCount, array.length / this.channelCount, this._codecSampleRate);
                        for (let channel = 0; channel < this.channelCount; channel++) {
                            for (let offset = 0; offset < audioBuf.length; offset++) {
                                audioBuf.getChannelData(channel)[offset] = array[channel + offset * this.channelCount];
                            }
                        }
                        resolve(audioBuf);
                    }
                    else {
                        reject(data.message);
                    }
                }
            });
        });
        this.sendWorkerMessage({
            command: "decodeSamples",
            token: token,
            data: data,
            dataLength: data.length
        });
        return result;
    }
    encode(data) {
        let token = this.generateToken();
        let result = new Promise((resolve, reject) => {
            this._workerListener.push({
                token: token,
                resolve: (data) => {
                    if (data.success) {
                        let array = new Uint8Array(data.dataLength);
                        for (let index = 0; index < array.length; index++)
                            array[index] = data.data[index];
                        resolve(array);
                    }
                    else {
                        reject(data.message);
                    }
                }
            });
        });
        let buffer = new Float32Array(this.channelCount * data.length);
        for (let offset = 0; offset < data.length; offset++) {
            for (let channel = 0; channel < this.channelCount; channel++)
                buffer[offset * this.channelCount + channel] = data.getChannelData(channel)[offset];
        }
        this.sendWorkerMessage({
            command: "encodeSamples",
            token: token,
            data: buffer,
            dataLength: buffer.length
        });
        return result;
    }
    reset() {
        this.sendWorkerMessage({
            command: "reset"
        });
        return true;
    }
    generateToken() {
        return this._workerTokeIndex++ + "_token";
    }
    sendWorkerMessage(message, transfare) {
        message["timestamp"] = Date.now();
        this._worker.postMessage(message, transfare);
    }
    onWorkerMessage(message) {
        if (Date.now() - message["timestamp"] > 5)
            console.warn(_translations.eJCgX4T4 || (_translations.eJCgX4T4 = tr("Worker message stock time: %d")), Date.now() - message["timestamp"]);
        if (!message["token"]) {
            console.error(_translations.pxLg_xQs || (_translations.pxLg_xQs = tr("Invalid worker token!")));
            return;
        }
        if (message["token"] == this._workerCallbackToken) {
            if (message["type"] == "loaded") {
                console.log(_translations.PoQEbaUA || (_translations.PoQEbaUA = tr("[Codec] Got worker init response: Success: %o Message: %o")), message["success"], message["message"]);
                if (message["success"]) {
                    if (this._workerCallbackResolve)
                        this._workerCallbackResolve();
                }
                else {
                    if (this._workerCallbackReject)
                        this._workerCallbackReject(message["message"]);
                }
                this._workerCallbackReject = undefined;
                this._workerCallbackResolve = undefined;
                return;
            }
            else if (message["type"] == "chatmessage_server") {
                chat.serverChat().appendMessage(message["message"]);
                return;
            }
            console.log(_translations._4DfWuV_ || (_translations._4DfWuV_ = tr("Costume callback! (%o)")), message);
            return;
        }
        for (let entry of this._workerListener) {
            if (entry.token == message["token"]) {
                entry.resolve(message);
                this._workerListener.remove(entry);
                return;
            }
        }
        //TODO tr
        console.error("Could not find worker token entry! (" + message["token"] + ")");
    }
    spawnWorker() {
        return new Promise((resolve, reject) => {
            this._workerCallbackReject = reject;
            this._workerCallbackResolve = resolve;
            this._worker = new Worker(settings.static("worker_directory", "js/workers/") + "WorkerCodec.js");
            this._worker.onmessage = event => this.onWorkerMessage(event.data);
            this._worker.onerror = (error) => reject("Failed to load worker (" + error.message + ")"); //TODO tr
        });
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["f8402e69dcd91ec1a1f4403688f5294ced27e4af2857dcefa3ee183b34d78edc"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["f8402e69dcd91ec1a1f4403688f5294ced27e4af2857dcefa3ee183b34d78edc"] = "f8402e69dcd91ec1a1f4403688f5294ced27e4af2857dcefa3ee183b34d78edc";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of []) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var hex;
(function (hex) {
    function encode(buffer) {
        let hexCodes = [];
        let view = new DataView(buffer);
        for (let i = 0; i < view.byteLength % 4; i++) {
            let value = view.getUint32(i * 4);
            let stringValue = value.toString(16);
            let padding = '00000000';
            let paddedValue = (padding + stringValue).slice(-padding.length);
            hexCodes.push(paddedValue);
        }
        for (let i = (view.byteLength % 4) * 4; i < view.byteLength; i++) {
            let value = view.getUint8(i).toString(16);
            let padding = '00';
            hexCodes.push((padding + value).slice(-padding.length));
        }
        return hexCodes.join("");
    }
    hex.encode = encode;
})(hex || (hex = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["815a1b51b75773869aab8889aaa1b0b9dd6ea0dd8589f0068977b1f9551ee5b4"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["815a1b51b75773869aab8889aaa1b0b9dd6ea0dd8589f0068977b1f9551ee5b4"] = "815a1b51b75773869aab8889aaa1b0b9dd6ea0dd8589f0068977b1f9551ee5b4";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "ifGGnlKp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/profiles/ConnectionProfile.ts (117,35)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
var profiles;
(function (profiles_1) {
    class ConnectionProfile {
        constructor(id) {
            this.selected_identity_type = "unset";
            this.identities = {};
            this.id = id;
        }
        selected_identity() {
            const current_type = this.selected_type();
            if (current_type === undefined)
                return undefined;
            if (current_type == profiles_1.identities.IdentitifyType.TEAFORO) {
                return profiles_1.identities.static_forum_identity();
            }
            else if (current_type == profiles_1.identities.IdentitifyType.TEAMSPEAK || current_type == profiles_1.identities.IdentitifyType.NICKNAME) {
                return this.identities[this.selected_identity_type.toLowerCase()];
            }
            return undefined;
        }
        selected_type() {
            return profiles_1.identities.IdentitifyType[this.selected_identity_type.toUpperCase()];
        }
        set_identity(type, identity) {
            this.identities[profiles_1.identities.IdentitifyType[type].toLowerCase()] = identity;
        }
        spawn_identity_handshake_handler(connection) {
            const identity = this.selected_identity();
            if (!identity)
                return undefined;
            return identity.spawn_identity_handshake_handler(connection);
        }
        encode() {
            const identity_data = {};
            for (const key in this.identities)
                if (this.identities[key])
                    identity_data[key] = this.identities[key].encode();
            return JSON.stringify({
                version: 1,
                username: this.default_username,
                password: this.default_password,
                profile_name: this.profile_name,
                identity_type: this.selected_identity_type,
                identity_data: identity_data,
                id: this.id
            });
        }
        valid() {
            return this.selected_identity() !== undefined && this.default_username !== undefined;
        }
    }
    profiles_1.ConnectionProfile = ConnectionProfile;
    function decode_profile(data) {
        data = JSON.parse(data);
        if (data.version !== 1)
            return "invalid version";
        const result = new ConnectionProfile(data.id);
        result.default_username = data.username;
        result.default_password = data.password;
        result.profile_name = data.profile_name;
        result.selected_identity_type = (data.identity_type || "").toLowerCase();
        if (data.identity_data) {
            for (const key in data.identity_data) {
                const type = profiles_1.identities.IdentitifyType[key.toUpperCase()];
                const _data = data.identity_data[key];
                if (type == undefined)
                    continue;
                const identity = profiles_1.identities.decode_identity(type, _data);
                if (identity == undefined)
                    continue;
                result.identities[key.toLowerCase()] = identity;
            }
        }
        return result;
    }
    let available_profiles = [];
    function load() {
        available_profiles = [];
        const profiles_json = localStorage.getItem("profiles");
        let profiles_data = profiles_json ? JSON.parse(profiles_json) : { version: 0 };
        if (profiles_data.version === 0) {
            profiles_data = {
                version: 1,
                profiles: []
            };
        }
        if (profiles_data.version == 1) {
            for (const profile_data of profiles_data.profiles) {
                const profile = decode_profile(profile_data);
                if (typeof (profile) === 'string') {
                    console.error(_translations.ifGGnlKp || (_translations.ifGGnlKp = tr("Failed to load profile. Reason: %s, Profile data: %s")), profile, profiles_data);
                    continue;
                }
                available_profiles.push(profile);
            }
        }
        if (!find_profile("default")) { //Create a default profile
            const profile = create_new_profile("default", "default");
            profile.default_password = "";
            profile.default_username = "Another TeaSpeak user";
            profile.profile_name = "Default Profile";
            save();
        }
    }
    profiles_1.load = load;
    function create_new_profile(name, id) {
        const profile = new ConnectionProfile(id || guid());
        profile.profile_name = name;
        profile.default_username = "Another TeaSpeak user";
        available_profiles.push(profile);
        return profile;
    }
    profiles_1.create_new_profile = create_new_profile;
    let _requires_save = false;
    function save() {
        const profiles = [];
        for (const profile of available_profiles)
            profiles.push(profile.encode());
        const data = JSON.stringify({
            version: 1,
            profiles: profiles
        });
        localStorage.setItem("profiles", data);
    }
    profiles_1.save = save;
    function mark_need_save() {
        _requires_save = true;
    }
    profiles_1.mark_need_save = mark_need_save;
    function requires_save() {
        return _requires_save;
    }
    profiles_1.requires_save = requires_save;
    function profiles() {
        return available_profiles;
    }
    profiles_1.profiles = profiles;
    function find_profile(id) {
        for (const profile of profiles())
            if (profile.id == id)
                return profile;
        return undefined;
    }
    profiles_1.find_profile = find_profile;
    function find_profile_by_name(name) {
        name = name.toLowerCase();
        for (const profile of profiles())
            if ((profile.profile_name || "").toLowerCase() == name)
                return profile;
        return undefined;
    }
    profiles_1.find_profile_by_name = find_profile_by_name;
    function default_profile() {
        return find_profile("default");
    }
    profiles_1.default_profile = default_profile;
    function set_default_profile(profile) {
        const old_default = default_profile();
        if (old_default && old_default != profile) {
            old_default.id = guid();
        }
        profile.id = "default";
    }
    profiles_1.set_default_profile = set_default_profile;
    function delete_profile(profile) {
        available_profiles.remove(profile);
    }
    profiles_1.delete_profile = delete_profile;
})(profiles || (profiles = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["14fb75bdf1dfb0a8d4505bc2aa34f523a988bdca7213eb3005c8bf29e3e4c70a"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["14fb75bdf1dfb0a8d4505bc2aa34f523a988bdca7213eb3005c8bf29e3e4c70a"] = "14fb75bdf1dfb0a8d4505bc2aa34f523a988bdca7213eb3005c8bf29e3e4c70a";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "aKV_0zKB", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/profiles/identities/NameIdentity.ts (20,31)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../Identity.ts" />
var profiles;
(function (profiles) {
    var identities;
    (function (identities) {
        class NameHandshakeHandler extends identities.AbstractHandshakeIdentityHandler {
            constructor(connection, identity) {
                super(connection);
                this.identity = identity;
            }
            start_handshake() {
                this.connection.commandHandler["handshakeidentityproof"] = () => this.trigger_fail("server requested unexpected proof");
                this.connection.sendCommand("handshakebegin", {
                    intention: 0,
                    authentication_method: this.identity.type(),
                    client_nickname: this.identity.name()
                }).catch(error => {
                    console.error(_translations.aKV_0zKB || (_translations.aKV_0zKB = tr("Failed to initialize name based handshake. Error: %o")), error);
                    if (error instanceof CommandResult)
                        error = error.extra_message || error.message;
                    this.trigger_fail("failed to execute begin (" + error + ")");
                }).then(() => this.trigger_success());
            }
        }
        class NameIdentity {
            constructor(name) {
                this._name = name;
            }
            set_name(name) { this._name = name; }
            name() {
                return this._name;
            }
            uid() {
                return btoa(this._name); //FIXME hash!
            }
            type() {
                return identities.IdentitifyType.NICKNAME;
            }
            valid() {
                return this._name != undefined && this._name != "";
            }
            decode(data) {
                data = JSON.parse(data);
                if (data.version !== 1)
                    return false;
                this._name = data["name"];
                return true;
            }
            encode() {
                return JSON.stringify({
                    version: 1,
                    name: this._name
                });
            }
            spawn_identity_handshake_handler(connection) {
                return new NameHandshakeHandler(connection, this);
            }
        }
        identities.NameIdentity = NameIdentity;
    })(identities = profiles.identities || (profiles.identities = {}));
})(profiles || (profiles = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["a317b6dde259bfa6427aa2f1e9f2ea832f8c5947437ccaf28dad7e2ad26fe5cd"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["a317b6dde259bfa6427aa2f1e9f2ea832f8c5947437ccaf28dad7e2ad26fe5cd"] = "a317b6dde259bfa6427aa2f1e9f2ea832f8c5947437ccaf28dad7e2ad26fe5cd";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "uQVmBMic", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/profiles/identities/TeaForumIdentity.ts (20,31)" }, { name: "ChCGJLRF", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/profiles/identities/TeaForumIdentity.ts (33,31)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../Identity.ts" />
var profiles;
(function (profiles) {
    var identities;
    (function (identities) {
        class TeaForumHandshakeHandler extends identities.AbstractHandshakeIdentityHandler {
            constructor(connection, identity) {
                super(connection);
                this.identity = identity;
            }
            start_handshake() {
                this.connection.commandHandler["handshakeidentityproof"] = this.handle_proof.bind(this);
                this.connection.sendCommand("handshakebegin", {
                    intention: 0,
                    authentication_method: this.identity.type(),
                    data: this.identity.data_json()
                }).catch(error => {
                    console.error(_translations.uQVmBMic || (_translations.uQVmBMic = tr("Failed to initialize TeaForum based handshake. Error: %o")), error);
                    if (error instanceof CommandResult)
                        error = error.extra_message || error.message;
                    this.trigger_fail("failed to execute begin (" + error + ")");
                });
            }
            handle_proof(json) {
                this.connection.sendCommand("handshakeindentityproof", {
                    proof: this.identity.data_sign()
                }).catch(error => {
                    console.error(_translations.ChCGJLRF || (_translations.ChCGJLRF = tr("Failed to proof the identity. Error: %o")), error);
                    if (error instanceof CommandResult)
                        error = error.extra_message || error.message;
                    this.trigger_fail("failed to execute proof (" + error + ")");
                }).then(() => this.trigger_success());
            }
        }
        class TeaForumIdentity {
            constructor(data, sign) {
                this.identityDataJson = data;
                this.identityData = data ? JSON.parse(this.identityDataJson) : undefined;
                this.identitySign = sign;
            }
            valid() {
                return this.identityDataJson.length > 0 && this.identityDataJson.length > 0 && this.identitySign.length > 0;
            }
            data_json() { return this.identityDataJson; }
            data_sign() { return this.identitySign; }
            name() { return this.identityData["user_name"]; }
            uid() { return "TeaForo#" + this.identityData["user_id"]; }
            type() { return identities.IdentitifyType.TEAFORO; }
            decode(data) {
                data = JSON.parse(data);
                if (data.version !== 1)
                    return false;
                this.identityDataJson = data["identity_data"];
                this.identitySign = data["identity_sign"];
                this.identityData = JSON.parse(this.identityData);
                return true;
            }
            encode() {
                return JSON.stringify({
                    version: 1,
                    identity_data: this.identityDataJson,
                    identity_sign: this.identitySign
                });
            }
            spawn_identity_handshake_handler(connection) {
                return new TeaForumHandshakeHandler(connection, this);
            }
        }
        identities.TeaForumIdentity = TeaForumIdentity;
        let static_identity;
        function setup_forum() {
            const user_data = settings.static("forum_user_data");
            const user_sign = settings.static("forum_user_sign");
            if (user_data && user_sign)
                static_identity = new TeaForumIdentity(user_data, user_sign);
        }
        identities.setup_forum = setup_forum;
        function valid_static_forum_identity() {
            return static_identity && static_identity.valid();
        }
        identities.valid_static_forum_identity = valid_static_forum_identity;
        function static_forum_identity() {
            return static_identity;
        }
        identities.static_forum_identity = static_forum_identity;
    })(identities = profiles.identities || (profiles.identities = {}));
})(profiles || (profiles = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["dd60f3e9040cbb5b20dd612d126dbb001a8b00200c1ea19bd4a2851ab84f7ae4"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["dd60f3e9040cbb5b20dd612d126dbb001a8b00200c1ea19bd4a2851ab84f7ae4"] = "dd60f3e9040cbb5b20dd612d126dbb001a8b00200c1ea19bd4a2851ab84f7ae4";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "q_TZRUpS", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/profiles/identities/TeamSpeakIdentity.ts (43,42)" }, { name: "bGvwoclG", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/profiles/identities/TeamSpeakIdentity.ts (96,31)" }, { name: "wNtboV81", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/profiles/identities/TeamSpeakIdentity.ts (108,31)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../Identity.ts" />
var profiles;
(function (profiles) {
    var identities;
    (function (identities) {
        let TSIdentityHelper;
        (function (TSIdentityHelper) {
            let functionLastError;
            let functionClearLastError;
            let functionDestroyString;
            let functionDestroyIdentity;
            function setup() {
                functionDestroyString = Module.cwrap("destroy_string", "pointer", []);
                functionLastError = Module.cwrap("last_error_message", null, ["string"]);
                TSIdentityHelper.funcationParseIdentity = Module.cwrap("parse_identity", "pointer", ["string"]);
                TSIdentityHelper.funcationParseIdentityByFile = Module.cwrap("parse_identity_file", "pointer", ["string"]);
                functionDestroyIdentity = Module.cwrap("delete_identity", null, ["pointer"]);
                TSIdentityHelper.funcationCalculateSecurityLevel = Module.cwrap("identity_security_level", "pointer", ["pointer"]);
                TSIdentityHelper.funcationExportIdentity = Module.cwrap("identity_export", "pointer", ["pointer"]);
                TSIdentityHelper.funcationPublicKey = Module.cwrap("identity_key_public", "pointer", ["pointer"]);
                TSIdentityHelper.funcationSignMessage = Module.cwrap("identity_sign", "pointer", ["pointer", "string", "number"]);
                TSIdentityHelper.functionUid = Module.cwrap("identity_uid", "pointer", ["pointer"]);
                return Module.cwrap("tomcrypt_initialize", "number", [])() == 0;
            }
            TSIdentityHelper.setup = setup;
            function last_error() {
                return unwarpString(functionLastError());
            }
            TSIdentityHelper.last_error = last_error;
            function unwarpString(str) {
                if (str == "")
                    return "";
                try {
                    if (!$.isFunction(window.Pointer_stringify)) {
                        displayCriticalError(_translations.q_TZRUpS || (_translations.q_TZRUpS = tr("Missing required wasm function!<br>Please reload the page!")));
                    }
                    let message = window.Pointer_stringify(str);
                    functionDestroyString(str);
                    return message;
                }
                catch (error) {
                    console.error(error);
                    return "";
                }
            }
            TSIdentityHelper.unwarpString = unwarpString;
            function loadIdentity(key) {
                try {
                    let handle = TSIdentityHelper.funcationParseIdentity(key);
                    if (!handle)
                        return undefined;
                    return new TeamSpeakIdentity(handle, "TeaWeb user");
                }
                catch (error) {
                    console.error(error);
                }
                return undefined;
            }
            TSIdentityHelper.loadIdentity = loadIdentity;
            function loadIdentityFromFileContains(contains) {
                let handle = TSIdentityHelper.funcationParseIdentityByFile(contains);
                if (!handle)
                    return undefined;
                return new TeamSpeakIdentity(handle, "TeaWeb user");
            }
            TSIdentityHelper.loadIdentityFromFileContains = loadIdentityFromFileContains;
            function load_identity(handle, key) {
                let native_handle = TSIdentityHelper.funcationParseIdentity(key);
                if (!native_handle)
                    return false;
                handle["handle"] = native_handle;
                return true;
            }
            TSIdentityHelper.load_identity = load_identity;
        })(TSIdentityHelper = identities.TSIdentityHelper || (identities.TSIdentityHelper = {}));
        class TeamSpeakHandshakeHandler extends identities.AbstractHandshakeIdentityHandler {
            constructor(connection, identity) {
                super(connection);
                this.identity = identity;
            }
            start_handshake() {
                this.connection.commandHandler["handshakeidentityproof"] = this.handle_proof.bind(this);
                this.connection.sendCommand("handshakebegin", {
                    intention: 0,
                    authentication_method: this.identity.type(),
                    publicKey: this.identity.publicKey()
                }).catch(error => {
                    console.error(_translations.bGvwoclG || (_translations.bGvwoclG = tr("Failed to initialize TeamSpeak based handshake. Error: %o")), error);
                    if (error instanceof CommandResult)
                        error = error.extra_message || error.message;
                    this.trigger_fail("failed to execute begin (" + error + ")");
                });
            }
            handle_proof(json) {
                const proof = this.identity.signMessage(json[0]["message"]);
                this.connection.sendCommand("handshakeindentityproof", { proof: proof }).catch(error => {
                    console.error(_translations.wNtboV81 || (_translations.wNtboV81 = tr("Failed to proof the identity. Error: %o")), error);
                    if (error instanceof CommandResult)
                        error = error.extra_message || error.message;
                    this.trigger_fail("failed to execute proof (" + error + ")");
                }).then(() => this.trigger_success());
            }
        }
        class TeamSpeakIdentity {
            constructor(handle, name) {
                this.handle = handle;
                this._name = name;
            }
            securityLevel() {
                return parseInt(TSIdentityHelper.unwarpString(TSIdentityHelper.funcationCalculateSecurityLevel(this.handle)));
            }
            name() { return this._name; }
            uid() {
                return TSIdentityHelper.unwarpString(TSIdentityHelper.functionUid(this.handle));
            }
            type() { return identities.IdentitifyType.TEAMSPEAK; }
            signMessage(message) {
                return TSIdentityHelper.unwarpString(TSIdentityHelper.funcationSignMessage(this.handle, message, message.length));
            }
            exported() {
                return TSIdentityHelper.unwarpString(TSIdentityHelper.funcationExportIdentity(this.handle));
            }
            publicKey() {
                return TSIdentityHelper.unwarpString(TSIdentityHelper.funcationPublicKey(this.handle));
            }
            valid() { return this.handle !== undefined; }
            decode(data) {
                data = JSON.parse(data);
                if (data.version != 1)
                    return false;
                if (!TSIdentityHelper.load_identity(this, data["key"]))
                    return false;
                this._name = data["name"];
                return true;
            }
            encode() {
                if (!this.handle)
                    return undefined;
                const key = this.exported();
                if (!key)
                    return undefined;
                return JSON.stringify({
                    key: key,
                    name: this._name,
                    version: 1
                });
            }
            spawn_identity_handshake_handler(connection) {
                return new TeamSpeakHandshakeHandler(connection, this);
            }
        }
        identities.TeamSpeakIdentity = TeamSpeakIdentity;
        function setup_teamspeak() {
            return TSIdentityHelper.setup();
        }
        identities.setup_teamspeak = setup_teamspeak;
    })(identities = profiles.identities || (profiles.identities = {}));
})(profiles || (profiles = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["b79405f886a1dfd86a7c46cbbde63ff347abc6ce6baa7b85acb182b8a2d67a02"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["b79405f886a1dfd86a7c46cbbde63ff347abc6ce6baa7b85acb182b8a2d67a02"] = "b79405f886a1dfd86a7c46cbbde63ff347abc6ce6baa7b85acb182b8a2d67a02";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "mSGlrm1N", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalServerEdit.ts (7,21)" }, { name: "xI9p7QCV", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalServerEdit.ts (19,35)" }, { name: "F4PCoFis", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalServerEdit.ts (22,31)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
var Modals;
(function (Modals) {
    function createServerModal(server, callback) {
        let properties = {}; //The changes properties
        const modal = createModal({
            header: _translations.mSGlrm1N || (_translations.mSGlrm1N = tr("Manager the  Virtual Server")),
            body: () => {
                let template = $("#tmpl_server_edit").renderTag(server.properties);
                template = $.spawn("div").append(template);
                return template.tabify();
            },
            footer: () => {
                let footer = $.spawn("div");
                footer.addClass("modal-button-group");
                footer.css("margin", "5px");
                let buttonCancel = $.spawn("button");
                buttonCancel.text(_translations.xI9p7QCV || (_translations.xI9p7QCV = tr("Cancel"))).addClass("button_cancel");
                let buttonOk = $.spawn("button");
                buttonOk.text(_translations.F4PCoFis || (_translations.F4PCoFis = tr("Ok"))).addClass("button_ok");
                footer.append(buttonCancel);
                footer.append(buttonOk);
                return footer;
            },
            width: 750
        });
        server_applyGeneralListener(properties, modal.htmlTag.find(".properties_general"), modal.htmlTag.find(".button_ok"));
        server_applyTransferListener(properties, server, modal.htmlTag.find('.container-file-transfer'));
        server_applyHostListener(properties, server.properties, modal.htmlTag.find(".properties_host"), modal.htmlTag.find(".button_ok"));
        server_applyMessages(properties, server, modal.htmlTag.find(".properties_messages"));
        server_applyFlood(properties, server, modal.htmlTag.find(".properties_flood"));
        server_applySecurity(properties, server, modal.htmlTag.find(".properties_security"));
        server_applyMisc(properties, server, modal.htmlTag.find(".properties_misc"));
        modal.htmlTag.find(".button_ok").click(() => {
            modal.close();
            callback(properties); //First may create the channel
        });
        modal.htmlTag.find(".button_cancel").click(() => {
            modal.close();
            callback();
        });
        modal.open();
    }
    Modals.createServerModal = createServerModal;
    function server_applyGeneralListener(properties, tag, button) {
        let updateButton = () => {
            if (tag.find(".input_error").length == 0)
                button.removeAttr("disabled");
            else
                button.attr("disabled", "true");
        };
        tag.find(".virtualserver_name").change(function () {
            properties.virtualserver_name = this.value;
            $(this).removeClass("input_error");
            if (this.value.length < 1 || this.value.length > 70)
                $(this).addClass("input_error");
            updateButton();
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_NAME).granted(1));
        tag.find(".virtualserver_name_phonetic").change(function () {
            properties.virtualserver_name_phonetic = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_NAME).granted(1));
        tag.find(".virtualserver_password").change(function () {
            properties.virtualserver_flag_password = this.value.length != 0;
            if (properties.virtualserver_flag_password)
                helpers.hashPassword(this.value).then(pass => properties.virtualserver_password = pass);
            $(this).removeClass("input_error");
            if (!properties.virtualserver_flag_password)
                if (globalClient.permissions.neededPermission(PermissionType.B_CHANNEL_CREATE_MODIFY_WITH_FORCE_PASSWORD).granted(1))
                    $(this).addClass("input_error");
            updateButton();
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_PASSWORD).granted(1));
        tag.find(".virtualserver_maxclients").change(function () {
            properties.virtualserver_maxclients = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_MAXCLIENTS).granted(1));
        tag.find(".virtualserver_reserved_slots").change(function () {
            properties.virtualserver_reserved_slots = this.valueAsNumber;
            $(this).removeClass("input_error");
            if (this.valueAsNumber > properties.virtualserver_maxclients)
                $(this).addClass("input_error");
            updateButton();
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_RESERVED_SLOTS).granted(1));
        tag.find(".virtualserver_welcomemessage").change(function () {
            properties.virtualserver_welcomemessage = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_WELCOMEMESSAGE).granted(1));
    }
    function server_applyHostListener(properties, original_properties, tag, button) {
        tag.find(".virtualserver_host").change(function () {
            properties.virtualserver_host = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOST).granted(1));
        tag.find(".virtualserver_port").change(function () {
            properties.virtualserver_port = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_PORT).granted(1));
        tag.find(".virtualserver_hostmessage").change(function () {
            properties.virtualserver_hostmessage = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOSTMESSAGE).granted(1));
        tag.find(".virtualserver_hostmessage_mode").change(function () {
            properties.virtualserver_hostmessage_mode = this.selectedIndex;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOSTMESSAGE).granted(1))
            .find("option").eq(original_properties.virtualserver_hostmessage_mode).prop('selected', true);
        tag.find(".virtualserver_hostbanner_url").change(function () {
            properties.virtualserver_hostbanner_url = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOSTBANNER).granted(1));
        tag.find(".virtualserver_hostbanner_gfx_url").change(function () {
            properties.virtualserver_hostbanner_gfx_url = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOSTBANNER).granted(1));
        tag.find(".virtualserver_hostbanner_gfx_interval").change(function () {
            properties.virtualserver_hostbanner_gfx_interval = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOSTBANNER).granted(1));
        tag.find(".virtualserver_hostbanner_mode").change(function () {
            properties.virtualserver_hostbanner_mode = this.selectedIndex;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOSTMESSAGE).granted(1))
            .find("option").eq(original_properties.virtualserver_hostbanner_mode).prop('selected', true);
        tag.find(".virtualserver_hostbutton_tooltip").change(function () {
            properties.virtualserver_hostbutton_tooltip = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOSTBUTTON).granted(1));
        tag.find(".virtualserver_hostbutton_url").change(function () {
            properties.virtualserver_hostbutton_url = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOSTBUTTON).granted(1));
        tag.find(".virtualserver_hostbutton_gfx_url").change(function () {
            properties.virtualserver_hostbutton_gfx_url = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_HOSTBUTTON).granted(1));
    }
    function server_applyMessages(properties, server, tag) {
        server.updateProperties().then(() => {
            tag.find(".virtualserver_default_client_description").val(server.properties.virtualserver_default_client_description);
            tag.find(".virtualserver_default_channel_description").val(server.properties.virtualserver_default_channel_description);
            tag.find(".virtualserver_default_channel_topic").val(server.properties.virtualserver_default_channel_topic);
        });
        tag.find(".virtualserver_default_client_description").change(function () {
            properties.virtualserver_default_client_description = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_DEFAULT_MESSAGES).granted(1));
        tag.find(".virtualserver_default_channel_description").change(function () {
            properties.virtualserver_default_channel_description = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_DEFAULT_MESSAGES).granted(1));
        tag.find(".virtualserver_default_channel_topic").change(function () {
            properties.virtualserver_default_channel_topic = this.value;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_DEFAULT_MESSAGES).granted(1));
    }
    function server_applyFlood(properties, server, tag) {
        server.updateProperties().then(() => {
            tag.find(".virtualserver_antiflood_points_tick_reduce").val(server.properties.virtualserver_antiflood_points_tick_reduce);
            tag.find(".virtualserver_antiflood_points_needed_command_block").val(server.properties.virtualserver_antiflood_points_needed_command_block);
            tag.find(".virtualserver_antiflood_points_needed_ip_block").val(server.properties.virtualserver_antiflood_points_needed_ip_block);
        });
        tag.find(".virtualserver_antiflood_points_tick_reduce").change(function () {
            properties.virtualserver_antiflood_points_tick_reduce = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_ANTIFLOOD).granted(1));
        tag.find(".virtualserver_antiflood_points_needed_command_block").change(function () {
            properties.virtualserver_antiflood_points_needed_command_block = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_ANTIFLOOD).granted(1));
        tag.find(".virtualserver_antiflood_points_needed_ip_block").change(function () {
            properties.virtualserver_antiflood_points_needed_ip_block = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_ANTIFLOOD).granted(1));
    }
    function server_applySecurity(properties, server, tag) {
        server.updateProperties().then(() => {
            tag.find(".virtualserver_needed_identity_security_level").val(server.properties.virtualserver_needed_identity_security_level);
        });
        tag.find(".virtualserver_needed_identity_security_level").change(function () {
            properties.virtualserver_needed_identity_security_level = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_NEEDED_IDENTITY_SECURITY_LEVEL).granted(1));
        tag.find(".virtualserver_codec_encryption_mode").change(function () {
            properties.virtualserver_codec_encryption_mode = this.selectedIndex;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_ANTIFLOOD).granted(1))
            .find("option").eq(server.properties.virtualserver_codec_encryption_mode).prop('selected', true);
    }
    function server_applyMisc(properties, server, tag) {
        { //TODO notify on tmp channeladmin group and vice versa
            {
                let groups_tag = tag.find(".default_server_group");
                groups_tag.change(function () {
                    properties.virtualserver_default_server_group = parseInt($(this.item(this.selectedIndex)).attr("group-id"));
                });
                for (let group of server.channelTree.client.groups.serverGroups.sort(GroupManager.sorter())) {
                    if (group.type != 2)
                        continue;
                    let group_tag = $.spawn("option").text(group.name + " [" + (group.properties.savedb ? "perm" : "tmp") + "]").attr("group-id", group.id);
                    if (group.id == server.properties.virtualserver_default_server_group)
                        group_tag.prop("selected", true);
                    group_tag.appendTo(groups_tag);
                }
            }
            {
                let groups_tag = tag.find(".default_music_group");
                groups_tag.change(function () {
                    properties.virtualserver_default_music_group = parseInt($(this.item(this.selectedIndex)).attr("group-id"));
                });
                for (let group of server.channelTree.client.groups.serverGroups.sort(GroupManager.sorter())) {
                    if (group.type != 2)
                        continue;
                    let group_tag = $.spawn("option").text(group.name + " [" + (group.properties.savedb ? "perm" : "tmp") + "]").attr("group-id", group.id);
                    if (group.id == server.properties.virtualserver_default_music_group)
                        group_tag.prop("selected", true);
                    group_tag.appendTo(groups_tag);
                }
            }
            {
                let groups_tag = tag.find(".default_channel_group");
                groups_tag.change(function () {
                    properties.virtualserver_default_channel_group = parseInt($(this.item(this.selectedIndex)).attr("group-id"));
                });
                for (let group of server.channelTree.client.groups.channelGroups.sort(GroupManager.sorter())) {
                    if (group.type != 2)
                        continue;
                    let group_tag = $.spawn("option").text(group.name + " [" + (group.properties.savedb ? "perm" : "tmp") + "]").attr("group-id", group.id);
                    if (group.id == server.properties.virtualserver_default_channel_group)
                        group_tag.prop("selected", true);
                    group_tag.appendTo(groups_tag);
                }
            }
            {
                let groups_tag = tag.find(".default_channel_admin_group");
                groups_tag.change(function () {
                    properties.virtualserver_default_channel_admin_group = parseInt($(this.item(this.selectedIndex)).attr("group-id"));
                });
                for (let group of server.channelTree.client.groups.channelGroups.sort(GroupManager.sorter())) {
                    if (group.type != 2)
                        continue;
                    let group_tag = $.spawn("option").text(group.name + " [" + (group.properties.savedb ? "perm" : "tmp") + "]").attr("group-id", group.id);
                    if (group.id == server.properties.virtualserver_default_channel_admin_group)
                        group_tag.prop("selected", true);
                    group_tag.appendTo(groups_tag);
                }
            }
        }
        server.updateProperties().then(() => {
            //virtualserver_antiflood_points_needed_ip_block
            //virtualserver_antiflood_points_needed_command_block
            //virtualserver_antiflood_points_tick_reduce
            //virtualserver_complain_autoban_count
            //virtualserver_complain_autoban_time
            //virtualserver_complain_remove_time
            tag.find(".virtualserver_antiflood_points_needed_ip_block").val(server.properties.virtualserver_antiflood_points_needed_ip_block);
            tag.find(".virtualserver_antiflood_points_needed_command_block").val(server.properties.virtualserver_antiflood_points_needed_command_block);
            tag.find(".virtualserver_antiflood_points_tick_reduce").val(server.properties.virtualserver_antiflood_points_tick_reduce);
            tag.find(".virtualserver_complain_autoban_count").val(server.properties.virtualserver_complain_autoban_count);
            tag.find(".virtualserver_complain_autoban_time").val(server.properties.virtualserver_complain_autoban_time);
            tag.find(".virtualserver_complain_remove_time").val(server.properties.virtualserver_complain_remove_time);
            tag.find(".virtualserver_weblist_enabled").prop("checked", server.properties.virtualserver_weblist_enabled);
        });
        tag.find(".virtualserver_antiflood_points_needed_ip_block").change(function () {
            properties.virtualserver_antiflood_points_needed_ip_block = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_ANTIFLOOD).granted(1));
        tag.find(".virtualserver_antiflood_points_needed_command_block").change(function () {
            properties.virtualserver_antiflood_points_needed_command_block = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_ANTIFLOOD).granted(1));
        tag.find(".virtualserver_antiflood_points_tick_reduce").change(function () {
            properties.virtualserver_antiflood_points_tick_reduce = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_ANTIFLOOD).granted(1));
        tag.find(".virtualserver_complain_autoban_count").change(function () {
            properties.virtualserver_complain_autoban_count = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_COMPLAIN).granted(1));
        tag.find(".virtualserver_complain_autoban_time").change(function () {
            properties.virtualserver_complain_autoban_time = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_COMPLAIN).granted(1));
        tag.find(".virtualserver_complain_remove_time").change(function () {
            properties.virtualserver_complain_remove_time = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_COMPLAIN).granted(1));
        tag.find(".virtualserver_weblist_enabled").change(function () {
            properties.virtualserver_weblist_enabled = $(this).prop("checked");
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_WEBLIST).granted(1));
    }
    function server_applyTransferListener(properties, server, tag) {
        server.updateProperties().then(() => {
            //virtualserver_max_upload_total_bandwidth
            //virtualserver_upload_quota
            //virtualserver_max_download_total_bandwidth
            //virtualserver_download_quota
            tag.find(".virtualserver_max_upload_total_bandwidth").val(server.properties.virtualserver_max_upload_total_bandwidth);
            tag.find(".virtualserver_upload_quota").val(server.properties.virtualserver_upload_quota);
            tag.find(".virtualserver_max_download_total_bandwidth").val(server.properties.virtualserver_max_download_total_bandwidth);
            tag.find(".virtualserver_download_quota").val(server.properties.virtualserver_download_quota);
        });
        tag.find(".virtualserver_max_upload_total_bandwidth").change(function () {
            properties.virtualserver_max_upload_total_bandwidth = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_FT_SETTINGS).granted(1));
        tag.find(".virtualserver_max_download_total_bandwidth").change(function () {
            properties.virtualserver_max_download_total_bandwidth = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_FT_SETTINGS).granted(1));
        tag.find(".virtualserver_upload_quota").change(function () {
            properties.virtualserver_upload_quota = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_FT_QUOTAS).granted(1));
        tag.find(".virtualserver_download_quota").change(function () {
            properties.virtualserver_download_quota = this.valueAsNumber;
        }).prop("disabled", !globalClient.permissions.neededPermission(PermissionType.B_VIRTUALSERVER_MODIFY_FT_QUOTAS).granted(1));
    }
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["2290697df51ca6046a5879c32bf1b1b6020353bc3ea573c3cb79cfa7963a0e73"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["2290697df51ca6046a5879c32bf1b1b6020353bc3ea573c3cb79cfa7963a0e73"] = "2290697df51ca6046a5879c32bf1b1b6020353bc3ea573c3cb79cfa7963a0e73";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "aT8AGYBD", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/server.ts (135,23)" }, { name: "aaFtw15X", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/server.ts (138,54)" }, { name: "gzlqWAWy", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/server.ts (139,37)" }, { name: "KslrTlF0", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/server.ts (152,70)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="channel.ts" />
/// <reference path="modal/ModalServerEdit.ts" />
class ServerProperties {
    constructor() {
        this.virtualserver_host = "";
        this.virtualserver_port = 0;
        this.virtualserver_name = "";
        this.virtualserver_name_phonetic = "";
        this.virtualserver_icon_id = 0;
        this.virtualserver_version = "unknown";
        this.virtualserver_platform = "unknown";
        this.virtualserver_unique_identifier = "";
        this.virtualserver_clientsonline = 0;
        this.virtualserver_queryclientsonline = 0;
        this.virtualserver_channelsonline = 0;
        this.virtualserver_uptime = 0;
        this.virtualserver_maxclients = 0;
        this.virtualserver_reserved_slots = 0;
        this.virtualserver_password = "";
        this.virtualserver_flag_password = false;
        this.virtualserver_welcomemessage = "";
        this.virtualserver_hostmessage = "";
        this.virtualserver_hostmessage_mode = 0;
        this.virtualserver_hostbanner_url = "";
        this.virtualserver_hostbanner_gfx_url = "";
        this.virtualserver_hostbanner_gfx_interval = 0;
        this.virtualserver_hostbanner_mode = 0;
        this.virtualserver_hostbutton_tooltip = "";
        this.virtualserver_hostbutton_url = "";
        this.virtualserver_hostbutton_gfx_url = "";
        this.virtualserver_codec_encryption_mode = 0;
        this.virtualserver_default_music_group = 0;
        this.virtualserver_default_server_group = 0;
        this.virtualserver_default_channel_group = 0;
        this.virtualserver_default_channel_admin_group = 0;
        //Special requested properties
        this.virtualserver_default_client_description = "";
        this.virtualserver_default_channel_description = "";
        this.virtualserver_default_channel_topic = "";
        this.virtualserver_antiflood_points_tick_reduce = 0;
        this.virtualserver_antiflood_points_needed_command_block = 0;
        this.virtualserver_antiflood_points_needed_ip_block = 0;
        this.virtualserver_complain_autoban_count = 0;
        this.virtualserver_complain_autoban_time = 0;
        this.virtualserver_complain_remove_time = 0;
        this.virtualserver_needed_identity_security_level = 8;
        this.virtualserver_weblist_enabled = false;
        this.virtualserver_min_clients_in_channel_before_forced_silence = 0;
        this.virtualserver_max_upload_total_bandwidth = 0;
        this.virtualserver_upload_quota = 0;
        this.virtualserver_max_download_total_bandwidth = 0;
        this.virtualserver_download_quota = 0;
    }
}
class ServerEntry {
    constructor(tree, name, address) {
        this.info_request_promise = undefined;
        this.info_request_promise_resolve = undefined;
        this.info_request_promise_reject = undefined;
        this.lastInfoRequest = 0;
        this.nextInfoRequest = 0;
        this.properties = new ServerProperties();
        this.channelTree = tree;
        this.remote_address = address;
        this.properties.virtualserver_name = name;
    }
    get htmlTag() {
        if (this._htmlTag)
            return this._htmlTag;
        let tag = $.spawn("div");
        tag.attr("id", "server");
        tag.addClass("server");
        tag.append($.spawn("div").addClass("server_type icon client-server_green"));
        tag.append($.spawn("a").addClass("name").text(this.properties.virtualserver_name));
        const serverIcon = $("<span/>");
        //we cant spawn an icon on creation :)
        serverIcon.append($.spawn("div").addClass("icon_property icon_empty"));
        tag.append(serverIcon);
        return this._htmlTag = tag;
    }
    initializeListener() {
        this._htmlTag.click(() => {
            this.channelTree.onSelect(this);
        });
        if (!settings.static(Settings.KEY_DISABLE_CONTEXT_MENU, false)) {
            this.htmlTag.on("contextmenu", (event) => {
                event.preventDefault();
                if ($.isArray(this.channelTree.currently_selected)) { //Multiselect
                    (this.channelTree.currently_selected_context_callback || ((_) => null))(event);
                    return;
                }
                this.channelTree.onSelect(this, true);
                this.spawnContextMenu(event.pageX, event.pageY, () => { this.channelTree.onSelect(undefined, true); });
            });
        }
    }
    spawnContextMenu(x, y, on_close = () => { }) {
        spawn_context_menu(x, y, {
            type: MenuEntryType.ENTRY,
            icon: "client-virtualserver_edit",
            name: _translations.aT8AGYBD || (_translations.aT8AGYBD = tr("Edit")),
            callback: () => {
                Modals.createServerModal(this, properties => {
                    log.info(LogCategory.SERVER, _translations.aaFtw15X || (_translations.aaFtw15X = tr("Changing server properties %o")), properties);
                    console.log(_translations.gzlqWAWy || (_translations.gzlqWAWy = tr("Changed properties: %o")), properties);
                    if (properties)
                        this.channelTree.client.serverConnection.sendCommand("serveredit", properties).then(() => {
                            sound.play(Sound.SERVER_EDITED_SELF);
                        });
                });
            }
        }, MenuEntry.CLOSE(on_close));
    }
    updateVariables(is_self_notify, ...variables) {
        let group = log.group(log.LogType.DEBUG, LogCategory.SERVER, _translations.KslrTlF0 || (_translations.KslrTlF0 = tr("Update properties (%i)")), variables.length);
        let update_bannner = false;
        for (let variable of variables) {
            JSON.map_field_to(this.properties, variable.value, variable.key);
            //TODO tr
            group.log("Updating server " + this.properties.virtualserver_name + ". Key " + variable.key + " Value: '" + variable.value + "' (" + typeof (this.properties[variable.key]) + ")");
            if (variable.key == "virtualserver_name") {
                this.htmlTag.find(".name").text(variable.value);
            }
            else if (variable.key == "virtualserver_icon_id") {
                if (this.channelTree.client.fileManager && this.channelTree.client.fileManager.icons)
                    this.htmlTag.find(".icon_property").replaceWith(this.channelTree.client.fileManager.icons.generateTag(this.properties.virtualserver_icon_id).addClass("icon_property"));
            }
            else if (variable.key.indexOf('hostbanner') != -1) {
                update_bannner = true;
            }
        }
        if (update_bannner)
            this.channelTree.client.selectInfo.update_banner();
        group.end();
        if (is_self_notify && this.info_request_promise_resolve) {
            this.info_request_promise_resolve();
            this.info_request_promise = undefined;
            this.info_request_promise_reject = undefined;
            this.info_request_promise_resolve = undefined;
        }
    }
    updateProperties() {
        if (this.info_request_promise && Date.now() - this.lastInfoRequest < 1000)
            return this.info_request_promise;
        this.lastInfoRequest = Date.now();
        this.nextInfoRequest = this.lastInfoRequest + 10 * 1000;
        this.channelTree.client.serverConnection.sendCommand("servergetvariables").catch(error => {
            this.info_request_promise_reject(error);
            this.info_request_promise = undefined;
            this.info_request_promise_reject = undefined;
            this.info_request_promise_resolve = undefined;
        });
        return this.info_request_promise = new Promise((resolve, reject) => {
            this.info_request_promise_reject = reject;
            this.info_request_promise_resolve = resolve;
        });
    }
    shouldUpdateProperties() {
        return this.nextInfoRequest < Date.now();
    }
    calculateUptime() {
        if (this.properties.virtualserver_uptime == 0 || this.lastInfoRequest == 0)
            return this.properties.virtualserver_uptime;
        return this.properties.virtualserver_uptime + (new Date().getTime() - this.lastInfoRequest) / 1000;
    }
}
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["0935a43df938bbe53586ffe15b6ebbda35fb93bea9cc689e2aaf2584a4d56d1c"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["0935a43df938bbe53586ffe15b6ebbda35fb93bea9cc689e2aaf2584a4d56d1c"] = "0935a43df938bbe53586ffe15b6ebbda35fb93bea9cc689e2aaf2584a4d56d1c";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "sqNU_8JD", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBookmarks.ts (42,21)" }, { name: "OzRAl05Y", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBookmarks.ts (92,37)" }, { name: "Q1X_eQ5n", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBookmarks.ts (143,36)" }, { name: "oBuY4t36", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalBookmarks.ts (143,57)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
/// <reference path="../../proto.ts" />
var Modals;
(function (Modals) {
    function bookmark_tag(callback_select, bookmark) {
        const tag = $("#tmpl_manage_bookmarks-list_entry").renderTag({
            name: bookmark.display_name,
            type: bookmark.type == bookmarks.BookmarkType.DIRECTORY ? "directory" : "bookmark"
        });
        tag.find(".name").on('click', () => {
            callback_select(bookmark, tag);
            tag.addClass("selected");
        });
        if (bookmark.type == bookmarks.BookmarkType.DIRECTORY) {
            const casted = bookmark;
            for (const member of casted.content)
                tag.find("> .members").append(bookmark_tag(callback_select, member));
        }
        return tag;
    }
    function parent_tag(select_tag, prefix, bookmark) {
        if (bookmark.type == bookmarks.BookmarkType.DIRECTORY) {
            const casted = bookmark;
            select_tag.append($.spawn("option")
                .val(casted.unique_id)
                .text(prefix + casted.display_name));
            for (const member of casted.content)
                parent_tag(select_tag, prefix + "  ", member);
        }
    }
    function spawnBookmarkModal() {
        let modal;
        modal = createModal({
            header: _translations.sqNU_8JD || (_translations.sqNU_8JD = tr("Manage bookmarks")),
            body: () => {
                let template = $("#tmpl_manage_bookmarks").renderTag({});
                template = $.spawn("div").append(template);
                let selected_bookmark;
                let update_name;
                const update_bookmarks = () => {
                    template.find(".list").empty();
                    const callback_selected = (entry, tag) => {
                        template.find(".selected").removeClass("selected");
                        if (selected_bookmark == entry)
                            return;
                        selected_bookmark = entry;
                        update_name = () => tag.find("> .name").text(entry.display_name);
                        template.find(".bookmark-setting").hide();
                        template.find(".setting-bookmark-name").val(selected_bookmark.display_name);
                        if (selected_bookmark.type == bookmarks.BookmarkType.ENTRY) {
                            template.find(".bookmark-setting-bookmark").show();
                            const casted = selected_bookmark;
                            const profile = profiles.find_profile(casted.connect_profile) || profiles.default_profile();
                            template.find(".setting-bookmark-profile").val(profile.id);
                            template.find(".setting-server-host").val(casted.server_properties.server_address);
                            template.find(".setting-server-port").val(casted.server_properties.server_port);
                            template.find(".setting-server-password").val(casted.server_properties.server_password_hash || casted.server_properties.server_password);
                            template.find(".setting-username").val(casted.nickname);
                            template.find(".setting-channel").val(casted.default_channel);
                            template.find(".setting-channel-password").val(casted.default_channel_password_hash || casted.default_channel_password);
                        }
                        else {
                            template.find(".bookmark-setting-directory").show();
                        }
                    };
                    for (const bookmark of bookmarks.bookmarks().content) {
                        template.find(".list").append(bookmark_tag(callback_selected, bookmark));
                    }
                    console.log(template.find(".list").find(".bookmark, .directory"));
                    template.find(".list").find(".bookmark, .directory").eq(0).find("> .name").trigger('click');
                };
                { //General buttons
                    template.find(".button-create").on('click', event => {
                        let create_modal;
                        create_modal = createModal({
                            header: _translations.OzRAl05Y || (_translations.OzRAl05Y = tr("Create a new entry")),
                            body: () => {
                                let template = $("#tmpl_manage_bookmarks-create").renderTag({});
                                template = $.spawn("div").append(template);
                                for (const bookmark of bookmarks.bookmarks().content)
                                    parent_tag(template.find(".bookmark-parent"), "", bookmark);
                                if (selected_bookmark) {
                                    const parent = selected_bookmark.type == bookmarks.BookmarkType.ENTRY ?
                                        bookmarks.parent_bookmark(selected_bookmark) :
                                        selected_bookmark;
                                    if (parent)
                                        template.find(".bookmark-parent").val(parent.unique_id);
                                }
                                template.find(".bookmark-name").on('change, keyup', event => {
                                    template.find(".button-create").prop("disabled", event.target.value.length < 3);
                                });
                                template.find(".button-create").prop("disabled", true).on('click', event => {
                                    const name = template.find(".bookmark-name").val();
                                    const parent_uuid = template.find(".bookmark-parent").val();
                                    const parent = bookmarks.find_bookmark(parent_uuid);
                                    let bookmark;
                                    if (template.find(".bookmark-type").val() == "directory") {
                                        bookmark = bookmarks.create_bookmark_directory(parent || bookmarks.bookmarks(), name);
                                    }
                                    else {
                                        bookmark = bookmarks.create_bookmark(name, parent || bookmarks.bookmarks(), {
                                            server_port: 9987,
                                            server_address: "ts.teaspeak.de"
                                        }, "Another TeaSpeak user");
                                    }
                                    bookmarks.save_bookmark(bookmark);
                                    create_modal.close();
                                    update_bookmarks();
                                });
                                return template;
                            },
                            footer: 400
                        });
                        create_modal.open();
                    });
                    template.find(".button-delete").on('click', event => {
                        if (!selected_bookmark)
                            return;
                        Modals.spawnYesNo(_translations.Q1X_eQ5n || (_translations.Q1X_eQ5n = tr("Are you sure?")), _translations.oBuY4t36 || (_translations.oBuY4t36 = tr("Do you really want to delete this entry?")), result => {
                            if (result) {
                                bookmarks.delete_bookmark(selected_bookmark);
                                bookmarks.save_bookmark(selected_bookmark); /* save the deleted state */
                                update_bookmarks();
                            }
                        });
                    });
                    /* bookmark listener */
                    {
                        template.find(".setting-bookmark-profile").on('change', event => {
                            if (!selected_bookmark || selected_bookmark.type != bookmarks.BookmarkType.ENTRY)
                                return;
                            const casted = selected_bookmark;
                            const element = event.target;
                            casted.connect_profile = element.value;
                            bookmarks.save_bookmark(selected_bookmark);
                        });
                        template.find(".setting-server-host").on('change', event => {
                            if (!selected_bookmark || selected_bookmark.type != bookmarks.BookmarkType.ENTRY)
                                return;
                            const casted = selected_bookmark;
                            const element = event.target;
                            casted.server_properties.server_address = element.value;
                            bookmarks.save_bookmark(selected_bookmark);
                        });
                        template.find(".setting-server-port").on('change', event => {
                            if (!selected_bookmark || selected_bookmark.type != bookmarks.BookmarkType.ENTRY)
                                return;
                            const casted = selected_bookmark;
                            const element = event.target;
                            casted.server_properties.server_port = parseInt(element.value);
                            bookmarks.save_bookmark(selected_bookmark);
                        });
                        template.find(".setting-server-password").on('change', event => {
                            if (!selected_bookmark || selected_bookmark.type != bookmarks.BookmarkType.ENTRY)
                                return;
                            const casted = selected_bookmark;
                            const element = event.target;
                            casted.server_properties.server_password = element.value;
                            bookmarks.save_bookmark(selected_bookmark);
                        });
                        template.find(".setting-username").on('change', event => {
                            if (!selected_bookmark || selected_bookmark.type != bookmarks.BookmarkType.ENTRY)
                                return;
                            const casted = selected_bookmark;
                            const element = event.target;
                            casted.nickname = element.value;
                            bookmarks.save_bookmark(selected_bookmark);
                        });
                        template.find(".setting-channel").on('change', event => {
                            if (!selected_bookmark || selected_bookmark.type != bookmarks.BookmarkType.ENTRY)
                                return;
                            const casted = selected_bookmark;
                            const element = event.target;
                            casted.default_channel = element.value;
                            bookmarks.save_bookmark(selected_bookmark);
                        });
                        template.find(".setting-channel-password").on('change', event => {
                            if (!selected_bookmark || selected_bookmark.type != bookmarks.BookmarkType.ENTRY)
                                return;
                            const casted = selected_bookmark;
                            const element = event.target;
                            casted.default_channel_password = element.value;
                            bookmarks.save_bookmark(selected_bookmark);
                        });
                    }
                    /* listener for both */
                    {
                        template.find(".setting-bookmark-name").on('change', event => {
                            if (!selected_bookmark)
                                return;
                            const element = event.target;
                            if (element.value.length >= 3) {
                                selected_bookmark.display_name = element.value;
                                bookmarks.save_bookmark(selected_bookmark);
                                if (update_name)
                                    update_name();
                            }
                        });
                    }
                }
                /* connect profile initialisation */
                {
                    const list = template.find(".setting-bookmark-profile");
                    for (const profile of profiles.profiles()) {
                        const tag = $.spawn("option").val(profile.id).text(profile.profile_name);
                        if (profile.id == "default")
                            tag.css("font-weight", "bold");
                        list.append(tag);
                    }
                }
                update_bookmarks();
                template.find(".button-close").on('click', event => modal.close());
                return template;
            },
            footer: undefined,
            width: 750
        });
        modal.close_listener.push(() => globalClient.controlBar.update_bookmarks());
        modal.open();
    }
    Modals.spawnBookmarkModal = spawnBookmarkModal;
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["5d7f9293212a427c8d353722b8a25bc20ab7cc218186090ee1d81d33c9f8575c"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["5d7f9293212a427c8d353722b8a25bc20ab7cc218186090ee1d81d33c9f8575c"] = "5d7f9293212a427c8d353722b8a25bc20ab7cc218186090ee1d81d33c9f8575c";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "JGlaTze0", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (62,24)" }, { name: "Wy2mRCo7", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (113,31)" }, { name: "utTxjraY", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (271,31)" }, { name: "NqdHUP6f", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (276,31)" }, { name: "CklMIKui", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (281,31)" }, { name: "NxkUHDMn", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (286,31)" }, { name: "CVU8Jn3o", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (324,35)" }, { name: "h276NrRo", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (331,35)" }, { name: "hqrWTJ7m", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (342,35)" }, { name: "RBRgbjou", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (352,35)" }, { name: "sslDbvn6", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (362,31)" }, { name: "UUBrMhoP", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (368,31)" }, { name: "fwbphYcY", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (375,31)" }, { name: "XHnTM8Sw", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (377,46)" }, { name: "pIL7tJ_j", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (377,70)" }, { name: "oMMLs0MJ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (383,31)" }, { name: "dRr_01gQ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (395,39)" }, { name: "FSK4im74", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (420,39)" }, { name: "_MR6YHpq", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (472,30)" }, { name: "MLJNtLkp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (473,39)" }, { name: "Uu2H_NLN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (477,29)" }, { name: "hMeSpZPJ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (489,29)" }, { name: "BstQ42uq", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (505,30)" }, { name: "nKsazDAt", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (506,39)" }, { name: "Q438E9Tj", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (510,29)" }, { name: "tNm7HDj1", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (522,29)" }, { name: "hynI11qH", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (547,34)" }, { name: "nKCQu4bQ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (570,29)" }, { name: "UGHgWYsX", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (581,29)" }, { name: "EAA7Bi38", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (594,29)" }, { name: "DZMrEAAL", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (605,29)" }, { name: "vpCGeaXH", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (645,30)" }, { name: "FPd3ziQZ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (650,29)" }, { name: "MiYGm328", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (661,29)" }, { name: "TOkOS6IN", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (673,30)" }, { name: "UjjUvmxp", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (678,29)" }, { name: "nQPtaPnb", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (689,29)" }, { name: "xd6AO_ou", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (704,30)" }, { name: "j6mkLZTZ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (722,30)" }, { name: "SiVLtPpa", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (727,29)" }, { name: "RSihGZNx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (738,29)" }, { name: "y3w8q5Zk", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (750,30)" }, { name: "RIsMNuIW", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (755,29)" }, { name: "dERkw_Zi", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (767,29)" }, { name: "o4o26nS3", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (804,30)" }, { name: "bVd0CiJn", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (823,30)" }, { name: "bijdK5Al", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (828,29)" }, { name: "F8osl3jn", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (839,29)" }, { name: "OKmVjg4U", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (851,30)" }, { name: "PUzZXizf", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (856,29)" }, { name: "Um5usZI_", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalPermissionEdit.ts (905,30)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
/// <reference path="../../proto.ts" />
/// <reference path="../../client.ts" />
var Modals;
(function (Modals) {
    function build_permission_editor() {
        return __awaiter(this, void 0, void 0, function* () {
            let root_entry = {};
            root_entry.entries = [];
            { /* lets build the stuff (~5ms) */
                let groups = globalClient.permissions.groupedPermissions();
                let entry_stack = [root_entry];
                let insert_group = (group) => {
                    let group_entry = {};
                    group_entry.type = "group";
                    group_entry.name = group.group.name;
                    group_entry.entries = [];
                    entry_stack.last().entries.push(group_entry);
                    entry_stack.push(group_entry);
                    for (let child of group.children)
                        insert_group(child);
                    entry_stack.pop();
                    for (let perm of group.permissions) {
                        let entry = {};
                        entry.type = "entry";
                        entry.permission_name = perm.name;
                        entry.unset = true;
                        group_entry.entries.push(entry);
                    }
                };
                groups.forEach(entry => insert_group(entry));
            }
            root_entry.permissions = root_entry.entries;
            const start = Date.now();
            console.log("begin render");
            const rendered = $("#tmpl_permission_explorer").renderTag(root_entry);
            console.log("end (%o)", Date.now() - start);
            const result = [];
            for (let i = 0; i < 4; i++)
                yield new Promise(resolve => setTimeout(() => {
                    const start = Date.now();
                    console.log("begin");
                    result.push(rendered.clone());
                    console.log("end (%o)", Date.now() - start);
                    resolve();
                }, 5));
            result.push(rendered);
            return result;
        });
    }
    function spawnPermissionEdit() {
        const connectModal = createModal({
            header: function () {
                return _translations.JGlaTze0 || (_translations.JGlaTze0 = tr("Server Permissions"));
            },
            body: function () {
                let properties = {};
                const tags = [$.spawn("div"), $.spawn("div"), $.spawn("div"), $.spawn("div"), $.spawn("div")];
                properties["permissions_group_server"] = tags[0];
                properties["permissions_group_channel"] = tags[1];
                properties["permissions_channel"] = tags[2];
                properties["permissions_client"] = tags[3];
                properties["permissions_client_channel"] = tags[4];
                let tag = $.spawn("div").append($("#tmpl_server_permissions").renderTag(properties)).tabify(false);
                setTimeout(() => {
                    console.log("HEAVY 1");
                    build_permission_editor().then(result => {
                        console.log("Result!");
                        for (let i = 0; i < 5; i++)
                            tags[i].replaceWith(result[i]);
                        setTimeout(() => {
                            console.log("HEAVY 2");
                            const task_queue = [];
                            task_queue.push(apply_server_groups.bind(undefined, tag.find(".layout-group-server")));
                            task_queue.push(apply_channel_groups.bind(undefined, tag.find(".layout-group-channel")));
                            task_queue.push(apply_channel_permission.bind(undefined, tag.find(".layout-channel")));
                            task_queue.push(apply_client_permission.bind(undefined, tag.find(".layout-client")));
                            task_queue.push(apply_client_channel_permission.bind(undefined, tag.find(".layout-client-channel")));
                            const task_invokder = () => {
                                if (task_queue.length == 0)
                                    return;
                                task_queue.pop_front()().then(() => setTimeout(task_invokder, 0));
                            };
                            setTimeout(task_invokder, 5);
                        }, 5);
                    });
                }, 5);
                return tag;
            },
            footer: function () {
                let tag = $.spawn("div");
                tag.css("text-align", "right");
                tag.css("margin-top", "3px");
                tag.css("margin-bottom", "6px");
                tag.addClass("modal-button-group");
                let buttonOk = $.spawn("button");
                buttonOk.text(_translations.Wy2mRCo7 || (_translations.Wy2mRCo7 = tr("Close"))).addClass("btn_close");
                tag.append(buttonOk);
                return tag;
            },
            width: "90%",
            height: "80%"
        });
        connectModal.htmlTag.find(".btn_close").on('click', () => {
            connectModal.close();
        });
        return connectModal;
    }
    Modals.spawnPermissionEdit = spawnPermissionEdit;
    function display_permissions(permission_tag, permissions) {
        return __awaiter(this, void 0, void 0, function* () {
            permission_tag.find(".permission").addClass("unset").find(".permission-grant input").val("");
            const permission_chunks = [];
            while (permissions.length > 0) {
                permission_chunks.push(permissions.slice(0, 20));
                permissions = permissions.slice(20);
            }
            yield new Promise(resolve => {
                const process_chunk = () => {
                    if (permission_chunks.length == 0) {
                        resolve();
                        return;
                    }
                    for (let perm of permission_chunks.pop_front()) {
                        let tag = permission_tag.find("." + perm.type.name);
                        if (perm.value != undefined) {
                            tag.removeClass("unset");
                            {
                                let value = tag.find(".permission-value input");
                                if (value.attr("type") == "checkbox")
                                    value.prop("checked", perm.value == 1);
                                else
                                    value.val(perm.value);
                            }
                            tag.find(".permission-skip input").prop("checked", perm.flag_skip);
                            tag.find(".permission-negate input").prop("checked", perm.flag_negate);
                        }
                        if (perm.granted_value != undefined) {
                            tag.find(".permission-grant input").val(perm.granted_value);
                        }
                    }
                    setTimeout(process_chunk, 0);
                };
                setTimeout(process_chunk, 0);
            });
            permission_tag.find(".filter-input").trigger('change');
        });
    }
    function make_permission_editor(tag, default_number, cb_edit, cb_grant_edit) {
        return __awaiter(this, void 0, void 0, function* () {
            tag = tag.hasClass("permission-explorer") ? tag : tag.find(".permission-explorer");
            const list = tag.find(".list");
            //list.css("max-height", document.body.clientHeight * .7)
            yield new Promise(resolve => setTimeout(() => {
                list.find(".arrow").each((idx, _entry) => {
                    let entry = $(_entry);
                    let entries = entry.parentsUntil(".group").first().parent().find("> .group-entries");
                    entry.on('click', () => {
                        if (entry.hasClass("right")) {
                            entries.show();
                        }
                        else {
                            entries.hide();
                        }
                        entry.toggleClass("right down");
                    });
                });
                resolve();
            }, 0));
            yield new Promise(resolve => setTimeout(() => {
                tag.find(".filter-input, .filter-granted").on('keyup change', event => {
                    let filter_mask = tag.find(".filter-input").val();
                    let req_granted = tag.find('.filter-granted').prop("checked");
                    tag.find(".permission").each((idx, _entry) => {
                        let entry = $(_entry);
                        let key = entry.find("> .filter-key");
                        let should_hide = filter_mask.length != 0 && key.text().indexOf(filter_mask) == -1;
                        if (req_granted) {
                            if (entry.hasClass("unset") && entry.find(".permission-grant input").val() == "")
                                should_hide = true;
                        }
                        entry.attr("match", should_hide ? 0 : 1);
                        if (should_hide)
                            entry.hide();
                        else
                            entry.show();
                    });
                    tag.find(".group").each((idx, _entry) => {
                        let entry = $(_entry);
                        let target = entry.find(".entry:not(.group)[match=\"1\"]").length > 0;
                        if (target)
                            entry.show();
                        else
                            entry.hide();
                    });
                });
                resolve();
            }, 0));
            const expend_all = (parent) => {
                (parent || list).find(".arrow").addClass("right").removeClass("down").trigger('click');
            };
            const collapse_all = (parent) => {
                (parent || list).find(".arrow").removeClass("right").addClass("down").trigger('click');
            };
            yield new Promise(resolve => setTimeout(() => {
                list.on('contextmenu', event => {
                    if (event.isDefaultPrevented())
                        return;
                    event.preventDefault();
                    spawn_context_menu(event.pageX, event.pageY, {
                        type: MenuEntryType.ENTRY,
                        icon: "",
                        name: "Expend all",
                        callback: () => expend_all.bind(this, [undefined])
                    }, {
                        type: MenuEntryType.ENTRY,
                        icon: "",
                        name: "Collapse all",
                        callback: collapse_all.bind(this, [undefined])
                    });
                });
                resolve();
            }, 0));
            yield new Promise(resolve => setTimeout(() => {
                tag.find(".title").each((idx, _entry) => {
                    let entry = $(_entry);
                    entry.on('click', () => {
                        tag.find(".selected").removeClass("selected");
                        $(_entry).addClass("selected");
                    });
                    entry.on('contextmenu', event => {
                        if (event.isDefaultPrevented())
                            return;
                        event.preventDefault();
                        spawn_context_menu(event.pageX, event.pageY, {
                            type: MenuEntryType.ENTRY,
                            icon: "",
                            name: _translations.utTxjraY || (_translations.utTxjraY = tr("Expend group")),
                            callback: () => expend_all.bind(this, entry)
                        }, {
                            type: MenuEntryType.ENTRY,
                            icon: "",
                            name: _translations.NqdHUP6f || (_translations.NqdHUP6f = tr("Expend all")),
                            callback: () => expend_all.bind(this, undefined)
                        }, {
                            type: MenuEntryType.ENTRY,
                            icon: "",
                            name: _translations.CklMIKui || (_translations.CklMIKui = tr("Collapse group")),
                            callback: collapse_all.bind(this, entry)
                        }, {
                            type: MenuEntryType.ENTRY,
                            icon: "",
                            name: _translations.NxkUHDMn || (_translations.NxkUHDMn = tr("Collapse all")),
                            callback: () => expend_all.bind(this, undefined)
                        });
                    });
                });
                resolve();
            }, 0));
            yield new Promise(resolve => setTimeout(() => {
                tag.find(".permission").each((idx, _entry) => {
                    let entry = $(_entry);
                    entry.on('click', () => {
                        tag.find(".selected").removeClass("selected");
                        $(_entry).addClass("selected");
                    });
                    entry.on('dblclick', event => {
                        entry.removeClass("unset");
                        let value = entry.find("> .permission-value input");
                        if (value.attr("type") == "number")
                            value.focus().val(default_number).trigger('change');
                        else
                            value.prop("checked", true).trigger('change');
                    });
                    entry.on('contextmenu', event => {
                        if (event.isDefaultPrevented())
                            return;
                        event.preventDefault();
                        let entries = [];
                        if (entry.hasClass("unset")) {
                            entries.push({
                                type: MenuEntryType.ENTRY,
                                icon: "",
                                name: _translations.CVU8Jn3o || (_translations.CVU8Jn3o = tr("Add permission")),
                                callback: () => entry.trigger('dblclick')
                            });
                        }
                        else {
                            entries.push({
                                type: MenuEntryType.ENTRY,
                                icon: "",
                                name: _translations.h276NrRo || (_translations.h276NrRo = tr("Remove permission")),
                                callback: () => {
                                    entry.addClass("unset");
                                    entry.find(".permission-value input").val("").trigger('change');
                                }
                            });
                        }
                        if (entry.find("> .permission-grant input").val() == "") {
                            entries.push({
                                type: MenuEntryType.ENTRY,
                                icon: "",
                                name: _translations.hqrWTJ7m || (_translations.hqrWTJ7m = tr("Add grant permission")),
                                callback: () => {
                                    let value = entry.find("> .permission-grant input");
                                    value.focus().val(default_number).trigger('change');
                                }
                            });
                        }
                        else {
                            entries.push({
                                type: MenuEntryType.ENTRY,
                                icon: "",
                                name: _translations.RBRgbjou || (_translations.RBRgbjou = tr("Remove permission")),
                                callback: () => {
                                    entry.find("> .permission-grant input").val("").trigger('change');
                                }
                            });
                        }
                        entries.push(MenuEntry.HR());
                        entries.push({
                            type: MenuEntryType.ENTRY,
                            icon: "",
                            name: _translations.sslDbvn6 || (_translations.sslDbvn6 = tr("Expend all")),
                            callback: () => expend_all.bind(this, undefined)
                        });
                        entries.push({
                            type: MenuEntryType.ENTRY,
                            icon: "",
                            name: _translations.UUBrMhoP || (_translations.UUBrMhoP = tr("Collapse all")),
                            callback: collapse_all.bind(this, undefined)
                        });
                        entries.push(MenuEntry.HR());
                        entries.push({
                            type: MenuEntryType.ENTRY,
                            icon: "",
                            name: _translations.fwbphYcY || (_translations.fwbphYcY = tr("Show permission description")),
                            callback: () => {
                                createErrorModal(_translations.XHnTM8Sw || (_translations.XHnTM8Sw = tr("Not implemented!")), _translations.pIL7tJ_j || (_translations.pIL7tJ_j = tr("This function isnt implemented yet!"))).open();
                            }
                        });
                        entries.push({
                            type: MenuEntryType.ENTRY,
                            icon: "",
                            name: _translations.oMMLs0MJ || (_translations.oMMLs0MJ = tr("Copy permission name")),
                            callback: () => {
                                copy_to_clipboard(entry.find(".permission-name").text());
                            }
                        });
                        spawn_context_menu(event.pageX, event.pageY, ...entries);
                    });
                    entry.find(".permission-value input, .permission-negate input, .permission-skip input").on('change', event => {
                        let permission = globalClient.permissions.resolveInfo(entry.find(".permission-name").text());
                        if (!permission) {
                            console.error(_translations.dRr_01gQ || (_translations.dRr_01gQ = tr("Attempted to edit a not known permission! (%s)")), entry.find(".permission-name").text());
                            return;
                        }
                        if (entry.hasClass("unset")) {
                            cb_edit(permission, undefined, undefined, undefined).catch(error => {
                                tag.find(".button-update").trigger('click');
                            });
                        }
                        else {
                            let input = entry.find(".permission-value input");
                            let value = input.attr("type") == "number" ? input.val() : (input.prop("checked") ? "1" : "0");
                            if (value == "" || isNaN(value))
                                value = 0;
                            else
                                value = parseInt(value);
                            let negate = entry.find(".permission-negate input").prop("checked");
                            let skip = entry.find(".permission-skip input").prop("checked");
                            cb_edit(permission, value, skip, negate).catch(error => {
                                tag.find(".button-update").trigger('click');
                            });
                        }
                    });
                    entry.find(".permission-grant input").on('change', event => {
                        let permission = globalClient.permissions.resolveInfo(entry.find(".permission-name").text());
                        if (!permission) {
                            console.error(_translations.FSK4im74 || (_translations.FSK4im74 = tr("Attempted to edit a not known permission! (%s)")), entry.find(".permission-name").text());
                            return;
                        }
                        let value = entry.find(".permission-grant input").val();
                        if (value && value != "" && !isNaN(value)) {
                            cb_grant_edit(permission, parseInt(value)).catch(error => {
                                tag.find(".button-update").trigger('click');
                            });
                        }
                        else
                            cb_grant_edit(permission, undefined).catch(error => {
                                tag.find(".button-update").trigger('click');
                            });
                    });
                });
                resolve();
            }, 0));
        });
    }
    function build_channel_tree(channel_list, update_button) {
        for (let channel of globalClient.channelTree.channels) {
            let tag = $.spawn("div").addClass("channel").attr("channel-id", channel.channelId);
            globalClient.fileManager.icons.generateTag(channel.properties.channel_icon_id).appendTo(tag);
            {
                let name = $.spawn("a").text(channel.channelName() + " (" + channel.channelId + ")").addClass("name");
                //if(globalClient.channelTree.server.properties. == group.id)
                //    name.addClass("default");
                name.appendTo(tag);
            }
            tag.appendTo(channel_list);
            tag.on('click', event => {
                channel_list.find(".selected").removeClass("selected");
                tag.addClass("selected");
                update_button.trigger('click');
            });
        }
        setTimeout(() => channel_list.find('.channel').first().trigger('click'), 0);
    }
    function apply_client_channel_permission(tag) {
        return __awaiter(this, void 0, void 0, function* () {
            let permission_tag = tag.find(".permission-explorer");
            let channel_list = tag.find(".list-channel .entries");
            permission_tag.addClass("disabled");
            yield make_permission_editor(permission_tag, 75, (type, value, skip, negate) => {
                let cldbid = parseInt(tag.find(".client-dbid").val());
                if (isNaN(cldbid))
                    return Promise.reject("invalid cldbid");
                let channel_id = parseInt(channel_list.find(".selected").attr("channel-id"));
                let channel = globalClient.channelTree.findChannel(channel_id);
                if (!channel) {
                    console.warn(_translations._MR6YHpq || (_translations._MR6YHpq = tr("Missing selected channel id for permission editor action!")));
                    return Promise.reject(_translations.MLJNtLkp || (_translations.MLJNtLkp = tr("invalid channel")));
                }
                if (value != undefined) {
                    console.log(_translations.Uu2H_NLN || (_translations.Uu2H_NLN = tr("Added permission %s with properties: %o %o %o")), type.name, value, skip, negate);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("channelclientaddperm", {
                            cldbid: cldbid,
                            cid: channel.channelId,
                            permid: type.id,
                            permvalue: value,
                            permskip: skip,
                            permnegate: negate
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log(_translations.hMeSpZPJ || (_translations.hMeSpZPJ = tr("Removed permission %s")), type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("channelclientdelperm", {
                            cldbid: cldbid,
                            cid: channel.channelId,
                            permid: type.id
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            }, (type, value) => {
                let cldbid = parseInt(tag.find(".client-dbid").val());
                if (isNaN(cldbid))
                    return Promise.reject("invalid cldbid");
                let channel_id = parseInt(channel_list.find(".selected").attr("channel-id"));
                let channel = globalClient.channelTree.findChannel(channel_id);
                if (!channel) {
                    console.warn(_translations.BstQ42uq || (_translations.BstQ42uq = tr("Missing selected channel id for permission editor action!")));
                    return Promise.reject(_translations.nKsazDAt || (_translations.nKsazDAt = tr("invalid channel")));
                }
                if (value != undefined) {
                    console.log(_translations.Q438E9Tj || (_translations.Q438E9Tj = tr("Added grant of %o for %s")), type.name, value);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("channelclientaddperm", {
                            cldbid: cldbid,
                            cid: channel.channelId,
                            permid: type.id | (1 << 15),
                            permvalue: value,
                            permskip: false,
                            permnegate: false
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log(_translations.tNm7HDj1 || (_translations.tNm7HDj1 = tr("Removed grant permission for %s")), type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("channelclientdelperm", {
                            cldbid: cldbid,
                            cid: channel.channelId,
                            permid: type.id | (1 << 15)
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            });
            build_channel_tree(channel_list, permission_tag.find(".button-update"));
            permission_tag.find(".button-update").on('click', event => {
                let val = tag.find('.client-select-uid').val();
                globalClient.serverConnection.helper.info_from_uid(val).then(result => {
                    if (!result || result.length == 0)
                        return Promise.reject("invalid data");
                    permission_tag.removeClass("disabled");
                    tag.find(".client-name").val(result[0].client_nickname);
                    tag.find(".client-uid").val(result[0].client_unique_id);
                    tag.find(".client-dbid").val(result[0].client_database_id);
                    let channel_id = parseInt(channel_list.find(".selected").attr("channel-id"));
                    let channel = globalClient.channelTree.findChannel(channel_id);
                    if (!channel) {
                        console.warn(_translations.hynI11qH || (_translations.hynI11qH = tr("Missing selected channel id for permission editor action!")));
                        return Promise.reject();
                    }
                    return globalClient.permissions.requestClientChannelPermissions(channel.channelId, result[0].client_database_id).then(result => display_permissions(permission_tag, result));
                }).catch(error => {
                    console.log(error); //TODO error handling?
                    permission_tag.addClass("disabled");
                });
            });
            tag.find(".client-select-uid").on('change', event => {
                tag.find(".button-update").trigger('click');
            });
        });
    }
    function apply_client_permission(tag) {
        return __awaiter(this, void 0, void 0, function* () {
            let permission_tag = tag.find(".permission-explorer");
            permission_tag.addClass("disabled");
            yield make_permission_editor(permission_tag, 75, (type, value, skip, negate) => {
                let cldbid = parseInt(tag.find(".client-dbid").val());
                if (isNaN(cldbid))
                    return Promise.reject("invalid cldbid");
                if (value != undefined) {
                    console.log(_translations.nKCQu4bQ || (_translations.nKCQu4bQ = tr("Added permission %s with properties: %o %o %o")), type.name, value, skip, negate);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("clientaddperm", {
                            cldbid: cldbid,
                            permid: type.id,
                            permvalue: value,
                            permskip: skip,
                            permnegate: negate
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log(_translations.UGHgWYsX || (_translations.UGHgWYsX = tr("Removed permission %s")), type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("clientdelperm", {
                            cldbid: cldbid,
                            permid: type.id
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            }, (type, value) => {
                let cldbid = parseInt(tag.find(".client-dbid").val());
                if (isNaN(cldbid))
                    return Promise.reject("invalid cldbid");
                if (value != undefined) {
                    console.log(_translations.EAA7Bi38 || (_translations.EAA7Bi38 = tr("Added grant of %o for %s")), type.name, value);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("clientaddperm", {
                            cldbid: cldbid,
                            permid: type.id | (1 << 15),
                            permvalue: value,
                            permskip: false,
                            permnegate: false
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log(_translations.DZMrEAAL || (_translations.DZMrEAAL = tr("Removed grant permission for %s")), type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("clientdelperm", {
                            cldbid: cldbid,
                            permid: type.id | (1 << 15)
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            });
            tag.find(".client-select-uid").on('change', event => {
                tag.find(".button-update").trigger('click');
            });
            permission_tag.find(".button-update").on('click', event => {
                let val = tag.find('.client-select-uid').val();
                globalClient.serverConnection.helper.info_from_uid(val).then(result => {
                    if (!result || result.length == 0)
                        return Promise.reject("invalid data");
                    permission_tag.removeClass("disabled");
                    tag.find(".client-name").val(result[0].client_nickname);
                    tag.find(".client-uid").val(result[0].client_unique_id);
                    tag.find(".client-dbid").val(result[0].client_database_id);
                    return globalClient.permissions.requestClientPermissions(result[0].client_database_id).then(result => display_permissions(permission_tag, result));
                }).catch(error => {
                    console.log(error); //TODO error handling?
                    permission_tag.addClass("disabled");
                });
            });
        });
    }
    function apply_channel_permission(tag) {
        return __awaiter(this, void 0, void 0, function* () {
            let channel_list = tag.find(".list-channel .entries");
            let permission_tag = tag.find(".permission-explorer");
            yield make_permission_editor(tag, 75, (type, value, skip, negate) => {
                let channel_id = parseInt(channel_list.find(".selected").attr("channel-id"));
                let channel = globalClient.channelTree.findChannel(channel_id);
                if (!channel) {
                    console.warn(_translations.vpCGeaXH || (_translations.vpCGeaXH = tr("Missing selected channel id for permission editor action!")));
                    return;
                }
                if (value != undefined) {
                    console.log(_translations.FPd3ziQZ || (_translations.FPd3ziQZ = tr("Added permission %o with properties: %o %o %o")), type.name, value, skip, negate);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("channeladdperm", {
                            cid: channel.channelId,
                            permid: type.id,
                            permvalue: value,
                            permskip: skip,
                            permnegate: negate
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log(_translations.MiYGm328 || (_translations.MiYGm328 = tr("Removed permission %s")), type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("channeldelperm", {
                            cid: channel.channelId,
                            permid: type.id
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            }, (type, value) => {
                let channel_id = parseInt(channel_list.find(".selected").attr("channel-id"));
                let channel = globalClient.channelTree.findChannel(channel_id);
                if (!channel) {
                    console.warn(_translations.TOkOS6IN || (_translations.TOkOS6IN = tr("Missing selected channel id for permission editor action!")));
                    return;
                }
                if (value != undefined) {
                    console.log(_translations.UjjUvmxp || (_translations.UjjUvmxp = tr("Added grant of %o for %s")), type.name, value);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("channeladdperm", {
                            cid: channel.channelId,
                            permid: type.id | (1 << 15),
                            permvalue: value,
                            permskip: false,
                            permnegate: false
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log(_translations.nQPtaPnb || (_translations.nQPtaPnb = tr("Removed grant permission for %s")), type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("channeldelperm", {
                            cid: channel.channelId,
                            permid: type.id | (1 << 15)
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            });
            build_channel_tree(channel_list, permission_tag.find(".button-update"));
            permission_tag.find(".button-update").on('click', event => {
                let channel_id = parseInt(channel_list.find(".selected").attr("channel-id"));
                let channel = globalClient.channelTree.findChannel(channel_id);
                if (!channel) {
                    console.warn(_translations.xd6AO_ou || (_translations.xd6AO_ou = tr("Missing selected channel id for permission editor action!")));
                    return;
                }
                globalClient.permissions.requestChannelPermissions(channel.channelId).then(result => display_permissions(permission_tag, result)).catch(error => {
                    console.log(error); //TODO handling?
                });
            });
        });
    }
    function apply_channel_groups(tag) {
        return __awaiter(this, void 0, void 0, function* () {
            let group_list = tag.find(".list-group-channel .entries");
            let permission_tag = tag.find(".permission-explorer");
            yield make_permission_editor(tag, 75, (type, value, skip, negate) => {
                let group_id = parseInt(group_list.find(".selected").attr("group-id"));
                let group = globalClient.groups.channelGroup(group_id);
                if (!group) {
                    console.warn(_translations.j6mkLZTZ || (_translations.j6mkLZTZ = tr("Missing selected group id for permission editor action!")));
                    return;
                }
                if (value != undefined) {
                    console.log(_translations.SiVLtPpa || (_translations.SiVLtPpa = tr("Added permission %s with properties: %o %o %o")), type.name, value, skip, negate);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("channelgroupaddperm", {
                            cgid: group.id,
                            permid: type.id,
                            permvalue: value,
                            permskip: skip,
                            permnegate: negate
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log(_translations.RSihGZNx || (_translations.RSihGZNx = tr("Removed permission %s")), type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("channelgroupdelperm", {
                            cgid: group.id,
                            permid: type.id
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            }, (type, value) => {
                let group_id = parseInt(group_list.find(".selected").attr("group-id"));
                let group = globalClient.groups.channelGroup(group_id);
                if (!group) {
                    console.warn(_translations.y3w8q5Zk || (_translations.y3w8q5Zk = tr("Missing selected group id for permission editor action!")));
                    return;
                }
                if (value != undefined) {
                    console.log(_translations.RIsMNuIW || (_translations.RIsMNuIW = tr("Added grant of %o for %s")), type.name, value);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("channelgroupaddperm", {
                            cgid: group.id,
                            permid: type.id | (1 << 15),
                            permvalue: value,
                            permskip: false,
                            permnegate: false
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log(_translations.dERkw_Zi || (_translations.dERkw_Zi = tr("Removed grant permission for %s")), type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("channelgroupdelperm", {
                            cgid: group.id,
                            permid: type.id | (1 << 15)
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            });
            {
                for (let group of globalClient.groups.channelGroups.sort(GroupManager.sorter())) {
                    let tag = $.spawn("div").addClass("group").attr("group-id", group.id);
                    globalClient.fileManager.icons.generateTag(group.properties.iconid).appendTo(tag);
                    {
                        let name = $.spawn("a").text(group.name + " (" + group.id + ")").addClass("name");
                        if (group.properties.savedb)
                            name.addClass("savedb");
                        if (globalClient.channelTree.server.properties.virtualserver_default_channel_group == group.id)
                            name.addClass("default");
                        name.appendTo(tag);
                    }
                    tag.appendTo(group_list);
                    tag.on('click', event => {
                        group_list.find(".selected").removeClass("selected");
                        tag.addClass("selected");
                        permission_tag.find(".button-update").trigger('click');
                    });
                }
            }
            //button-update
            permission_tag.find(".button-update").on('click', event => {
                let group_id = parseInt(group_list.find(".selected").attr("group-id"));
                let group = globalClient.groups.channelGroup(group_id);
                if (!group) {
                    console.warn(_translations.o4o26nS3 || (_translations.o4o26nS3 = tr("Missing selected group id for permission editor!")));
                    return;
                }
                globalClient.groups.request_permissions(group).then(result => display_permissions(permission_tag, result)).catch(error => {
                    console.log(error); //TODO handling?
                });
            });
            setTimeout(() => group_list.find('.group').first().trigger('click'), 0);
        });
    }
    function apply_server_groups(tag) {
        return __awaiter(this, void 0, void 0, function* () {
            let group_list = tag.find(".list-group-server .entries");
            let permission_tag = tag.find(".permission-explorer");
            yield make_permission_editor(tag, 75, (type, value, skip, negate) => {
                let group_id = parseInt(group_list.find(".selected").attr("group-id"));
                let group = globalClient.groups.serverGroup(group_id);
                if (!group) {
                    console.warn(_translations.bVd0CiJn || (_translations.bVd0CiJn = tr("Missing selected group id for permission editor action!")));
                    return;
                }
                if (value != undefined) {
                    console.log(_translations.bijdK5Al || (_translations.bijdK5Al = tr("Added permission %s with properties: %o %o %o")), type.name, value, skip, negate);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("servergroupaddperm", {
                            sgid: group.id,
                            permid: type.id,
                            permvalue: value,
                            permskip: skip,
                            permnegate: negate
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log(_translations.F8osl3jn || (_translations.F8osl3jn = tr("Removed permission %s")), type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("servergroupdelperm", {
                            sgid: group.id,
                            permid: type.id
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            }, (type, value) => {
                let group_id = parseInt(group_list.find(".selected").attr("group-id"));
                let group = globalClient.groups.serverGroup(group_id);
                if (!group) {
                    console.warn(_translations.OKmVjg4U || (_translations.OKmVjg4U = tr("Missing selected group id for permission editor action!")));
                    return;
                }
                if (value != undefined) {
                    console.log(_translations.PUzZXizf || (_translations.PUzZXizf = tr("Added grant of %o for %s")), value, type.name);
                    return new Promise((resolve, reject) => {
                        globalClient.serverConnection.sendCommand("servergroupaddperm", {
                            sgid: group.id,
                            permid: type.id | (1 << 15),
                            permvalue: value,
                            permskip: false,
                            permnegate: false
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
                else {
                    console.log("Removed grant permission for %s", type.name);
                    return new Promise((resolve, reject) => {
                        return globalClient.serverConnection.sendCommand("servergroupdelperm", {
                            sgid: group.id,
                            permid: type.id | (1 << 15)
                        }).then(resolve.bind(undefined, true)).catch(reject);
                    });
                }
            });
            {
                for (let group of globalClient.groups.serverGroups.sort(GroupManager.sorter())) {
                    let tag = $.spawn("div").addClass("group").attr("group-id", group.id);
                    globalClient.fileManager.icons.generateTag(group.properties.iconid).appendTo(tag);
                    {
                        let name = $.spawn("a").text(group.name + " (" + group.id + ")").addClass("name");
                        if (group.properties.savedb)
                            name.addClass("savedb");
                        if (globalClient.channelTree.server.properties.virtualserver_default_server_group == group.id)
                            name.addClass("default");
                        name.appendTo(tag);
                    }
                    tag.appendTo(group_list);
                    tag.on('click', event => {
                        group_list.find(".selected").removeClass("selected");
                        tag.addClass("selected");
                        permission_tag.find(".button-update").trigger('click');
                    });
                }
            }
            //button-update
            permission_tag.find(".button-update").on('click', event => {
                let group_id = parseInt(group_list.find(".selected").attr("group-id"));
                let group = globalClient.groups.serverGroup(group_id);
                if (!group) {
                    console.warn(_translations.Um5usZI_ || (_translations.Um5usZI_ = tr("Missing selected group id for permission editor!")));
                    return;
                }
                globalClient.groups.request_permissions(group).then(result => display_permissions(permission_tag, result)).catch(error => {
                    console.log(error); //TODO handling?
                });
            });
            setTimeout(() => group_list.find('.group').first().trigger('click'), 0);
        });
    }
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["3d3e5dddc1263c6f32a5b76c2547fda07e41045f130fd27e9ae23188fe58783e"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["3d3e5dddc1263c6f32a5b76c2547fda07e41045f130fd27e9ae23188fe58783e"] = "3d3e5dddc1263c6f32a5b76c2547fda07e41045f130fd27e9ae23188fe58783e";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "LfkG9X0A", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQuery.ts (9,21)" }, { name: "y9LNsRxg", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQuery.ts (18,42)" }, { name: "uI7IMMlr", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQuery.ts (18,66)" }, { name: "gfy4RfBd", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQuery.ts (40,42)" }, { name: "pWJhQQ7e", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQuery.ts (40,74)" }, { name: "WRCSAxNZ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQuery.ts (60,36)" }, { name: "XAHEdCDD", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQuery.ts (60,69)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
/// <reference path="../../proto.ts" />
/// <reference path="../../client.ts" />
var Modals;
(function (Modals) {
    function spawnQueryCreate(callback_created) {
        let modal;
        modal = createModal({
            header: _translations.LfkG9X0A || (_translations.LfkG9X0A = tr("Create a server query login")),
            body: () => {
                let template = $("#tmpl_query_create").renderTag();
                template = $.spawn("div").append(template);
                template.find(".button-close").on('click', event => modal.close());
                template.find(".button-create").on('click', event => {
                    const name = template.find(".input-name").val();
                    if (name.length < 3 || name.length > 64) {
                        createErrorModal(_translations.y9LNsRxg || (_translations.y9LNsRxg = tr("Invalid username")), _translations.uI7IMMlr || (_translations.uI7IMMlr = tr("Please enter a valid name!"))).open();
                        return;
                    }
                    //client_login_password
                    globalClient.serverConnection.commandHandler["notifyquerycreated"] = json => {
                        json = json[0];
                        spawnQueryCreated({
                            username: name,
                            password: json.client_login_password
                        }, true);
                        if (callback_created)
                            callback_created(name, json.client_login_password);
                    };
                    globalClient.serverConnection.sendCommand("querycreate", {
                        client_login_name: name
                    }).catch(error => {
                        if (error instanceof CommandResult)
                            error = error.extra_message || error.message;
                        createErrorModal(_translations.gfy4RfBd || (_translations.gfy4RfBd = tr("Unable to create account")), (_translations.pWJhQQ7e || (_translations.pWJhQQ7e = tr("Failed to create account<br>Message: "))) + error).open();
                    });
                    modal.close();
                    //TODO create account
                });
                return template;
            },
            footer: undefined,
            width: 750
        });
        modal.open();
    }
    Modals.spawnQueryCreate = spawnQueryCreate;
    function spawnQueryCreated(credentials, yust_created) {
        let modal;
        modal = createModal({
            header: yust_created ? _translations.WRCSAxNZ || (_translations.WRCSAxNZ = tr("Server query credentials")) : _translations.XAHEdCDD || (_translations.XAHEdCDD = tr("New server query credentials")),
            body: () => {
                let template = $("#tmpl_query_created").renderTag(credentials);
                template = $.spawn("div").append(template);
                template.find(".button-close").on('click', event => modal.close());
                template.find(".query_name").text(credentials.username);
                template.find(".query_password").text(credentials.password);
                template.find(".btn_copy_name").on('click', () => {
                    template.find(".query_name").select();
                    document.execCommand("copy");
                });
                template.find(".btn_copy_password").on('click', () => {
                    template.find(".query_password").select();
                    document.execCommand("copy");
                });
                return template;
            },
            footer: undefined,
            width: 750
        });
        modal.open();
    }
    Modals.spawnQueryCreated = spawnQueryCreated;
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["6943f403778ad81dbc0335a1d8e221480c6763b33318f92137205bfe28e02825"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["6943f403778ad81dbc0335a1d8e221480c6763b33318f92137205bfe28e02825"] = "6943f403778ad81dbc0335a1d8e221480c6763b33318f92137205bfe28e02825";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "pzph2vgx", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (55,21)" }, { name: "Ci17ODse", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (74,38)" }, { name: "erYzQ71U", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (74,65)" }, { name: "VX78z1Nv", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (82,50)" }, { name: "VdywCir8", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (82,82)" }, { name: "Urr9JNah", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (84,49)" }, { name: "BO57MDxE", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (84,85)" }, { name: "r6o25EvZ", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (93,38)" }, { name: "L8fK7jb4", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (93,71)" }, { name: "b3igwPC1", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (101,50)" }, { name: "CH74bdAH", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (101,83)" }, { name: "_2b9_nPt", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (118,39)" }, { name: "PyjJvuQM", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (118,60)" }, { name: "HbTx0T_P", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (125,50)" }, { name: "QD8UJ8M7", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (125,82)" }, { name: "OgfzUZD5", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (127,49)" }, { name: "zPegUCmH", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/ui/modal/ModalQueryManage.ts (127,85)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
/// <reference path="../../utils/modal.ts" />
/// <reference path="../../proto.ts" />
/// <reference path="../../client.ts" />
var Modals;
(function (Modals) {
    function spawnQueryManage(client) {
        let modal;
        let selected_query;
        const update_selected = () => {
            const buttons = modal.htmlTag.find(".header .buttons");
            //TODO gray out if no permissions (Server needs to send that... :D)
            buttons.find(".button-query-delete").prop("disabled", selected_query === undefined);
            buttons.find(".button-query-rename").prop("disabled", selected_query === undefined);
            buttons.find(".button-query-change-password").prop("disabled", selected_query === undefined);
        };
        const update_list = () => {
            const info_tag = modal.htmlTag.find(".footer .info a");
            info_tag.text("loading...");
            client.serverConnection.helper.current_virtual_server_id().then(server_id => {
                client.serverConnection.helper.request_query_list(server_id).then(result => {
                    selected_query = undefined;
                    const entries_tag = modal.htmlTag.find(".query-list-entries");
                    const entry_template = $("#tmpl_query_manager-list_entry");
                    entries_tag.empty();
                    for (const query of result.queries || []) {
                        entries_tag.append(entry_template.renderTag(query).on('click', event => {
                            entries_tag.find(".entry.selected").removeClass("selected");
                            $(event.target).parent(".entry").addClass("selected");
                            selected_query = query;
                            update_selected();
                        }));
                    }
                    const entry_container = modal.htmlTag.find(".query-list-entries-container");
                    if (entry_container.hasScrollBar())
                        entry_container.addClass("scrollbar");
                    if (!result || result.flag_all) {
                        info_tag.text("Showing all server queries");
                    }
                    else {
                        info_tag.text("Showing your server queries");
                    }
                    update_selected();
                });
            });
            //TODO error handling
        };
        modal = createModal({
            header: _translations.pzph2vgx || (_translations.pzph2vgx = tr("Manage query accounts")),
            body: () => {
                let template = $("#tmpl_query_manager").renderTag();
                template = $.spawn("div").append(template);
                /* first open the modal */
                setTimeout(() => {
                    const entry_container = template.find(".query-list-entries-container");
                    if (entry_container.hasScrollBar())
                        entry_container.addClass("scrollbar");
                }, 100);
                template.find(".footer .buttons .button-refresh").on('click', update_list);
                template.find(".button-query-create").on('click', () => {
                    Modals.spawnQueryCreate((user, pass) => update_list());
                });
                template.find(".button-query-rename").on('click', () => {
                    if (!selected_query)
                        return;
                    createInputModal(_translations.Ci17ODse || (_translations.Ci17ODse = tr("Change account name")), _translations.erYzQ71U || (_translations.erYzQ71U = tr("Enter the new name for the login:<br>")), text => text.length >= 3, result => {
                        if (result) {
                            client.serverConnection.sendCommand("queryrename", {
                                client_login_name: selected_query.username,
                                client_new_login_name: result
                            }).catch(error => {
                                if (error instanceof CommandResult)
                                    error = error.extra_message || error.message;
                                createErrorModal(_translations.VX78z1Nv || (_translations.VX78z1Nv = tr("Unable to rename account")), (_translations.VdywCir8 || (_translations.VdywCir8 = tr("Failed to rename account<br>Message: "))) + error).open();
                            }).then(() => {
                                createInfoModal(_translations.Urr9JNah || (_translations.Urr9JNah = tr("Account successfully renamed")), _translations.BO57MDxE || (_translations.BO57MDxE = tr("The query account has been renamed!"))).open();
                                update_list();
                            });
                        }
                    }).open();
                });
                template.find(".button-query-change-password").on('click', () => {
                    if (!selected_query)
                        return;
                    createInputModal(_translations.r6o25EvZ || (_translations.r6o25EvZ = tr("Change account's password")), _translations.L8fK7jb4 || (_translations.L8fK7jb4 = tr("Enter a new password (leave blank for auto generation):<br>")), text => true, result => {
                        if (result !== false) {
                            client.serverConnection.sendCommand("querychangepassword", {
                                client_login_name: selected_query.username,
                                client_login_password: result
                            }).catch(error => {
                                if (error instanceof CommandResult)
                                    error = error.extra_message || error.message;
                                createErrorModal(_translations.b3igwPC1 || (_translations.b3igwPC1 = tr("Unable to change password")), (_translations.CH74bdAH || (_translations.CH74bdAH = tr("Failed to change password<br>Message: "))) + error).open();
                            });
                            client.serverConnection.commandHandler["notifyquerypasswordchanges"] = json => {
                                Modals.spawnQueryCreated({
                                    username: json[0]["client_login_name"],
                                    password: json[0]["client_login_password"]
                                }, false);
                                client.serverConnection.commandHandler["notifyquerypasswordchanges"] = undefined;
                            };
                        }
                    }).open();
                });
                template.find(".button-query-delete").on('click', () => {
                    if (!selected_query)
                        return;
                    Modals.spawnYesNo(_translations._2b9_nPt || (_translations._2b9_nPt = tr("Are you sure?")), _translations.PyjJvuQM || (_translations.PyjJvuQM = tr("Do you really want to delete this account?")), result => {
                        if (result) {
                            client.serverConnection.sendCommand("querydelete", {
                                client_login_name: selected_query.username
                            }).catch(error => {
                                if (error instanceof CommandResult)
                                    error = error.extra_message || error.message;
                                createErrorModal(_translations.HbTx0T_P || (_translations.HbTx0T_P = tr("Unable to delete account")), (_translations.QD8UJ8M7 || (_translations.QD8UJ8M7 = tr("Failed to delete account<br>Message: "))) + error).open();
                            }).then(() => {
                                createInfoModal(_translations.OgfzUZD5 || (_translations.OgfzUZD5 = tr("Account successfully deleted")), _translations.zPegUCmH || (_translations.zPegUCmH = tr("The query account has been successfully deleted!"))).open();
                                update_list();
                            });
                        }
                    });
                });
                template.find(".input-search").on('change keyup', () => {
                    const text = (template.find(".input-search").val() || "").toLowerCase();
                    if (text.length == 0) {
                        template.find(".query-list-entries .entry").show();
                    }
                    else {
                        template.find(".query-list-entries .entry").each((_, e) => {
                            const element = $(e);
                            if (element.text().toLowerCase().indexOf(text) == -1)
                                element.hide();
                            else
                                element.show();
                        });
                    }
                });
                return template;
            },
            footer: undefined,
            width: 750
        });
        update_list();
        modal.open();
    }
    Modals.spawnQueryManage = spawnQueryManage;
})(Modals || (Modals = {}));
typeof _translations !== "undefined" || (_translations = {});
_translations["declared"] = _translations["declared"] || (_translations["declared"] = {});
_translations["declared_files"] = _translations["declared_files"] || (_translations["declared_files"] = {});
unique_translation_check: {
    if (_translations["declared_files"]["ef2bb86f6cbe058ac944909dab3b5feec8750ce50f8271dadd57dd6b6786731d"] !== undefined) {
        console.warn("This file has already been loaded!\nAre you executing scripts twice?");
        break unique_translation_check;
    }
    else
        _translations["declared_files"]["ef2bb86f6cbe058ac944909dab3b5feec8750ce50f8271dadd57dd6b6786731d"] = "ef2bb86f6cbe058ac944909dab3b5feec8750ce50f8271dadd57dd6b6786731d";
    /*Auto generated helper for testing if the translation keys are unique*/
    for (var { name: _i, path: _a } of [{ name: "kpm9CSis", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioResampler.ts (7,82)" }, { name: "HBQTg3Sc", path: "/home/wolverindev/TeaSpeak/TeaSpeak/Web-Client/shared/js/voice/AudioResampler.ts (12,26)" }]) {
        if (_translations["declared"][_i] !== undefined)
            throw "Translation with generated name \"" + _i + "\" already exists!\nIt has been already defined here: " + _translations["declared"][_i] + "\nAttempted to redefine here: " + _a + "\nRegenerate and/or fix your program!";
        else
            _translations["declared"][_i] = _a;
    }
}
class AudioResampler {
    constructor(targetSampleRate) {
        this.targetSampleRate = targetSampleRate;
        if (this.targetSampleRate < 3000 || this.targetSampleRate > 384000)
            throw _translations.kpm9CSis || (_translations.kpm9CSis = tr("The target sample rate is outside the range [3000, 384000]."));
    }
    resample(buffer) {
        if (!buffer) {
            console.warn(_translations.HBQTg3Sc || (_translations.HBQTg3Sc = tr("Received empty buffer as input! Returning empty output!")));
            return Promise.resolve(buffer);
        }
        //console.log("Encode from %i to %i", buffer.sampleRate, this.targetSampleRate);
        if (buffer.sampleRate == this.targetSampleRate)
            return Promise.resolve(buffer);
        let context;
        context = new (window.webkitOfflineAudioContext || window.OfflineAudioContext)(buffer.numberOfChannels, Math.ceil(buffer.length * this.targetSampleRate / buffer.sampleRate), this.targetSampleRate);
        let source = context.createBufferSource();
        source.buffer = buffer;
        source.start(0);
        source.connect(context.destination);
        if (typeof (this._use_promise) === "undefined") {
            this._use_promise = navigator.browserSpecs.name != 'Safari';
        }
        if (this._use_promise)
            return context.startRendering();
        else {
            return new Promise((resolve, reject) => {
                context.oncomplete = event => resolve(event.renderedBuffer);
                try {
                    context.startRendering();
                }
                catch (ex) {
                    reject(ex);
                }
            });
        }
    }
}
//# sourceMappingURL=shared.js.map
//# sourceMappingURL=client.js.map